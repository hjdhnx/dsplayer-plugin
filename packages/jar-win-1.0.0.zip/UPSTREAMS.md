# UPSTREAMS — jar-win 包内第三方件归属与许可

本包（jar-win）内含来自下列上游的第三方制品。本包与 DsPlayer 主程序构成聚合分发；
主程序源码不包含这些内容。改动或再分发本包时须保留本文件与 `licenses/` 目录。

| 件 | 来源 | 许可 |
|---|---|---|
| `shims/stubs.jar` `shims/native-bridge.jar` `shims/spider-host.jar` `shims/shell-shim.jar` `shims/aowu-shim.jar` `shims/go-proxy-shim.jar` `shims/prefs-shim.jar` `shims/okhttp4-compat.jar` `shims/proxy-bridge.jar` | [Win-box](https://github.com/yagami-hue/Win-box)（原作）→ [MisaTV](https://github.com/tinyhan9/MisaTV) @ commit `f91cc41`（Flutter 重写版内置资产 `assets/jvm/*.jar`） | GPL-3.0（全文见 `licenses/GPL-3.0.txt`） |
| `jre/` | Eclipse Temurin JRE 17（构建机 jlink 裁剪自 Oracle JDK 17.0.12 / Temurin 17 等价物） | GPL-2.0 with Classpath Exception（模块级） |
| `d2j/*.jar` | [dex2jar](https://github.com/pxb1988/dex2jar) v2.4 | Apache-2.0 |
| `libs/okhttp-3.14.9.jar` `libs/okio-1.17.5.jar` | Square（Maven Central） | Apache-2.0 |
| `libs/gson-2.10.1.jar` | Google（Maven Central） | Apache-2.0 |
| `libs/jsoup-1.17.2.jar` | Jonathan Hedley（Maven Central） | MIT |
| `libs/json-20180813.jar` | JSON.org（Maven Central） | JSON License（可自由使用，禁止用于恶意用途） |
| `libs/slf4j-api-2.0.16.jar` `libs/slf4j-simple-2.0.16.jar` | SLF4J（Maven Central） | MIT |
| `libs/bcprov-jdk18on-1.78.1.jar` | Bouncy Castle（Maven Central） | MIT 变体（Bouncy Castle License） |
| `libs/sqlite-jdbc-3.46.1.0.jar` | Xerial（Maven Central） | Apache-2.0 |

钉版说明：兼容层 9 jar 从 MisaTV 仓 commit `f91cc41`（「沉浸式界面重做 + 直播收藏与布局 +
播放器按键提示」）的 `assets/jvm/` 原样取件，构建脚本只拼装不改内容。若需修改兼容层源码，
改动发生在对应 GPL 仓，本仓不收 GPL 源文件。

包内**不含** `shell-real`（第三方壳的解包/改写产物，版权归各壳权利人，上游亦不随仓分发）——
加固壳一律走 unidbg 首次解包路径（配合 jar-guard 插件）。

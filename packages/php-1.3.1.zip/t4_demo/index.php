<?php
/**
 * PHP 服务控制台（1.3.1）
 * - 状态卡：PHP 版本/平台/时间/扩展（展开显示具体扩展名单）
 * - php/ 服务脚本区：扫描 t4_demo/php/ 下的 web 服务脚本（解析、IPTV
 *   转发等），逐个列出完整服务地址——它们不是站点源，不进 config.php
 * - 机器可读探针兼容：?format=json 保持原 JSON 输出
 */
$isHttps = (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on' || $_SERVER['HTTPS'] == 1))
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
$scheme = $isHttps ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';
$dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$base = $scheme . $host . $dir;
$configUrl = $base . '/config.php';

if (isset($_GET['format']) && $_GET['format'] === 'json') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'ok',
        'message' => 'PHP 服务运行正常',
        'version' => PHP_VERSION,
        'platform' => 'Android',
        'time' => date('Y-m-d H:i:s'),
        'extensions' => get_loaded_extensions(),
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
header('Content-Type: text/html; charset=utf-8');
$extensions = get_loaded_extensions();
sort($extensions);

// 扫描 php/ 服务脚本目录（web 服务端点：解析/IPTV 转发等）。
// _ 开头视为内部依赖不成端点；README 等非 php 天然排除
$serviceScripts = [];
$svcDir = __DIR__ . '/php';
if (is_dir($svcDir)) {
    foreach (scandir($svcDir) as $f) {
        if (pathinfo($f, PATHINFO_EXTENSION) !== 'php') continue;
        if (strpos($f, '_') === 0) continue;
        $serviceScripts[] = $f;
    }
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PHP 服务状态</title>
<style>
  body { font-family: -apple-system, "Segoe UI", Roboto, sans-serif; background: #f6f7f9;
         color: #22262b; margin: 0; padding: 24px 16px; }
  .card { max-width: 560px; margin: 0 auto 14px; background: #fff; border: 1px solid #e6e8eb;
          border-radius: 14px; padding: 18px 20px; }
  h1 { font-size: 17px; margin: 0 0 12px; }
  h2 { font-size: 15px; margin: 0 0 10px; }
  .ok { color: #0d9463; font-weight: 600; }
  .kv { display: flex; justify-content: space-between; gap: 12px; padding: 5px 0;
        font-size: 13.5px; border-bottom: 1px dashed #eef0f2; }
  .kv:last-child { border-bottom: 0; }
  .kv b { font-weight: 500; color: #6a7178; }
  code { font-family: Menlo, Consolas, monospace; font-size: 12px; word-break: break-all; }
  .btn { display: inline-block; border: 0; border-radius: 9px; padding: 9px 16px; font-size: 14px;
         text-decoration: none; cursor: pointer; }
  .btn.primary { background: #e23e2b; color: #fff; }
  .btn.ghost { background: #f1f2f4; color: #22262b; }
  .row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 12px; }
  .hint { font-size: 12.5px; color: #6a7178; line-height: 1.7; margin: 8px 0 0; }
  .exts { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
  .exts span { font-size: 11.5px; background: #f1f2f4; border-radius: 6px; padding: 3px 8px;
               color: #454b52; }
  .svc { padding: 8px 0; border-bottom: 1px dashed #eef0f2; font-size: 13px; }
  .svc:last-child { border-bottom: 0; }
  .svc .name { font-weight: 600; }
  .svc .u { display: flex; justify-content: space-between; gap: 10px; align-items: center;
            margin-top: 3px; }
  .svc a { color: #e23e2b; text-decoration: none; font-size: 12px; white-space: nowrap; }
</style>
</head>
<body>
  <div class="card">
    <h1>PHP 服务状态 <span class="ok">● 运行中</span></h1>
    <div class="kv"><b>PHP 版本</b><span><?= htmlspecialchars(PHP_VERSION) ?></span></div>
    <div class="kv"><b>平台</b><span>Android</span></div>
    <div class="kv"><b>服务器时间</b><span><?= date('Y-m-d H:i:s') ?></span></div>
    <div class="kv"><b>已加载扩展</b><span><?= count($extensions) ?> 个（下方展开）</span></div>
    <div class="exts">
      <?php foreach ($extensions as $e): ?>
        <span><?= htmlspecialchars($e) ?></span>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="card">
    <h1>T4 源列表（config.php）</h1>
    <p class="hint">以下地址可直接挂为 DsPlayer 的接口配置（生成的 sites 含 t4_demo 内全部站点源）：</p>
    <div class="kv"><b>地址</b><code id="cfgUrl"><?= htmlspecialchars($configUrl) ?></code></div>
    <div class="row">
      <a class="btn primary" href="config.php">打开 /config.php</a>
      <button class="btn ghost" onclick="copyCfg()">复制 config.php 完整地址</button>
    </div>
  </div>
  <div class="card">
    <h1>php/ 服务脚本（<?= count($serviceScripts) ?>）</h1>
    <p class="hint">t4_demo/php/ 目录下的 web 服务脚本（自定义解析、IPTV 转发等）——
       它们不是站点源，不进 config.php 源列表，服务地址如下：</p>
    <?php if (empty($serviceScripts)): ?>
      <p class="hint">暂无服务脚本。把 php 脚本放进 <code>t4_demo/php/</code> 即会列出在此。</p>
    <?php else: ?>
      <?php foreach ($serviceScripts as $f): $u = $base . '/php/' . rawurlencode($f); ?>
        <div class="svc">
          <div class="name"><?= htmlspecialchars(pathinfo($f, PATHINFO_FILENAME)) ?></div>
          <div class="u">
            <code><?= htmlspecialchars($u) ?></code>
            <a href="<?= htmlspecialchars($u) ?>">打开</a>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
<script>
function copyCfg() {
  var url = document.getElementById('cfgUrl').textContent;
  function done() { alert('已复制：' + url); }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(done, function () { fallback(); });
  } else { fallback(); }
  function fallback() {
    var t = document.createElement('textarea');
    t.value = url; document.body.appendChild(t); t.select();
    document.execCommand('copy'); document.body.removeChild(t); done();
  }
}
</script>
</body>
</html>

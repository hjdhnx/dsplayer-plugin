/* 页面增强器：歪比巴卜 wbbb1.com（MacCMS V10 模板通用提取器）
 * 形态：api=web://https://wbbb1.com/ + ext=本文件（wbbb1.web.json 同名挂载）
 * 能力：详情页注入「用 DsPlayer 播放」按钮 → 提取全部线路/选集推壳子
 *       详情页；点集时 __dsResolver 在页面会话内 fetch 播放页提流
 *       （站有 JS cookie 挑战，Dart 侧无会话 cookie——必须页内 fetch）。
 * 契约：幂等（__dsBooster 守卫）；ds/fm 桥由壳子先行注入；只动 DOM 不
 *       劫持站内行为。适配其它 MacCMS V10 站：改 TOP_ORIGIN + 选择器微调。
 */
(function () {
  'use strict';
  if (window.__dsBooster) return;
  window.__dsBooster = 1;

  var TOP_ORIGIN = location.origin;

  function log(m) { try { console.log('[wbbb1-booster] ' + m); } catch (e) {} }

  /* ---------- DOM 提取（MacCMS V10） ---------- */

  function absUrl(u) {
    if (!u) return '';
    if (u.indexOf('//') === 0) return 'https:' + u;
    if (u.charAt(0) === '/') return TOP_ORIGIN + u;
    return u;
  }

  function picOf(el) {
    if (!el) return '';
    var img = el.querySelector('img');
    if (!img) return '';
    return absUrl(img.getAttribute('data-original') ||
        img.getAttribute('data-src') || img.src || '');
  }

  // 线路名（同块配对，2026-10-11 修正：全局 tab 序会把筛选区「排序」当
  // 线路名——data-id 配对 > 播放块内 tab 序 > 线路N 兜底）
  function lineNameOf(listEl, idx) {
    var p = listEl;
    for (var i = 0; i < 4 && p; i++) {
      var id = p.getAttribute && p.getAttribute('data-id');
      if (id) {
        var t = document.querySelector(
          '.module-tab-item[data-id="' + id + '"],' +
          '.module-tab-small[data-id="' + id + '"],' +
          'a[data-id="' + id + '"],li[data-id="' + id + '"]');
        var n = (t ? t.textContent : '').trim();
        if (n) return n;
      }
      p = p.parentElement;
    }
    var blk = listEl.closest('.module-box, .module, .playlist');
    if (blk) {
      var NON_LINE = ['排序', '正序', '倒序', '最新', '最热', '筛选', '展开', '收起', '更多', '推荐', '全部'];
      var tabs = blk.querySelectorAll('.module-tab-item, .module-tab-small');
      var names = [];
      for (var i = 0; i < tabs.length; i++) {
        var t2 = (tabs[i].textContent || '').trim();
        if (!t2) continue;
        var bad = false;
        for (var j = 0; j < NON_LINE.length; j++) {
          if (t2.indexOf(NON_LINE[j]) >= 0) { bad = true; break; }
        }
        if (!bad) names.push(t2);
      }
      if (names[idx]) return names[idx];
    }
    return '线路' + (idx + 1);
  }

  // 详情页数据：{ vid, title, pic, lines:[{name, episodes:[{name,url}]}] }
  function extractDetail() {
    var lists = document.querySelectorAll('.module-play-list');
    if (!lists.length) return null;
    var vid = (location.pathname.match(/\/(?:detail|vplay)\/(\d+)/) || [])[1] ||
        String(Date.now());
    var h1 = document.querySelector('h1, .page-title, .module-info-content h1');
    var title = h1 ? (h1.textContent || '').trim() : document.title;
    var pic = picOf(document.querySelector('.module-info-poster')) ||
        picOf(document.querySelector('.module-item-pic'));
    var lines = [];
    for (var i = 0; i < lists.length; i++) {
      var eps = [];
      var as = lists[i].querySelectorAll('.module-play-list-link, a[href]');
      for (var j = 0; j < as.length; j++) {
        var a = as[j];
        var href = absUrl(a.getAttribute('href'));
        if (href.indexOf('/vplay/') < 0 && href.indexOf('/play/') < 0) continue;
        var name = (a.textContent || '').trim().replace(/\s+/g, ' ');
        if (!name || !href) continue;
        eps.push({ name: name, url: href, resolve: true });
      }
      if (eps.length) {
        lines.push({ name: lineNameOf(lists[i], i), episodes: eps });
      }
    }
    if (!lines.length) return null;
    return { vid: vid, title: title, pic: pic, lines: lines, meta: metaOf() };
  }

  // CMS 元信息（label 行式扫描，与通用提取器同构）
  function metaOf() {
    function txtOf(el) {
      return el ? (el.textContent || '').trim().replace(/\s+/g, ' ') : '';
    }
    function byLabel(keys) {
      var rows = document.querySelectorAll('.module-info-item, .stui-content__detail p');
      for (var i = 0; i < rows.length; i++) {
        var label = txtOf(rows[i].querySelector('.module-info-item-title, dt, span:first-child')) || txtOf(rows[i]);
        for (var k = 0; k < keys.length; k++) {
          if (label.indexOf(keys[k]) >= 0) {
            var val = txtOf(rows[i].querySelector('.module-info-item-content, dd, a, span:last-child'));
            if (val && val !== label) return val.slice(0, 300);
          }
        }
      }
      return '';
    }
    var intro = txtOf(document.querySelector(
        '.module-info-introduction p, .stui-content__desc, [class*=introduction] p, [class*=desc] p'));
    return {
      actor: byLabel(['主演', '演员']), director: byLabel(['导演']),
      area: byLabel(['地区', '国家']), year: byLabel(['年份', '年代', '上映']),
      vodClass: byLabel(['类型', '题材']),
      score: txtOf(document.querySelector('.module-info-douban-score, [class*=score]')),
      content: intro.slice(0, 500)
    };
  }

  /* ---------- 播放页提流（__dsResolver，页面会话内 fetch） ---------- */

  function extractPlayUrl(html) {
    // 优先级：player_aaaa.url（MacCMS 标准页内变量）> player_data > url1/2
    // > iframe src > 页内裸 m3u8
    var m = html.match(/var\s+player_aaaa\s*=\s*(\{[\s\S]*?\});/);
    if (m) {
      try {
        var pa = JSON.parse(m[1].replace(/'/g, '"'));
        if (pa.url && /^https?:|^\/\//.test(pa.url)) return absUrl(pa.url);
      } catch (e) {}
    }
    m = html.match(/var\s+player_data\s*=\s*(\{[\s\S]*?\});/);
    if (m) {
      try {
        var pd = JSON.parse(m[1].replace(/'/g, '"'));
        if (pd.url) return absUrl(pd.url);
      } catch (e) {}
    }
    m = html.match(/(?:url1|url2)\s*[:=]\s*['"]([^'"]+)['"]/);
    if (m) return absUrl(m[1]);
    m = html.match(/<iframe[^>]+src=["']([^"']+)["']/i);
    if (m) return absUrl(m[1]);
    m = html.match(/https?:\/\/[^"'\s]+\.m3u8[^"'\s]*/);
    if (m) return m[0];
    return '';
  }

  window.__dsResolver = async function (ep) {
    var pageUrl = ep && ep.url;
    if (!pageUrl) return null;
    if (/\.(m3u8|mp4)(\?|$)/i.test(pageUrl)) {
      return { url: pageUrl, headers: { 'User-Agent': navigator.userAgent, 'Referer': TOP_ORIGIN + '/' } };
    }
    // 快路径：页内 fetch（无挑战站）；不中即 webview:// 交给壳子嗅探链
    try {
      var r = await fetch(pageUrl, { credentials: 'include' });
      if (r.ok) {
        var html = await r.text();
        var url = extractPlayUrl(html);
        if (url) {
          log('resolved(fetch) ' + url.slice(0, 80));
          return { url: url, headers: { 'User-Agent': navigator.userAgent, 'Referer': TOP_ORIGIN + '/' } };
        }
      }
    } catch (e) {}
    log('fallback to sniff: ' + pageUrl);
    return { url: 'webview://' + pageUrl, headers: { 'User-Agent': navigator.userAgent, 'Referer': TOP_ORIGIN + '/' } };
  };

  /* ---------- 注入按钮 ---------- */

  function pushToShell() {
    try {
      var d = extractDetail();
      log('extract: ' + (d ? (d.title + ' / ' + d.lines.length + ' lines / ' +
          d.lines.map(function (l) { return l.episodes.length; }).join('+') + ' eps')
          : 'null'));
      if (!d) {
        ds.toast('未提取到选集数据（选集列表选择器未命中）');
        return;
      }
      // 首集名（线路 1 第 1 集）作 mark：详情页预选
      var first = d.lines[0].episodes[0];
      fm.vodInline({
        vod_id: 'wbbb1_' + d.vid,
        vod_name: d.title,
        vod_pic: d.pic,
        vod_remarks: 'wbbb1 · 共 ' + d.lines[0].episodes.length + ' 集 · ' +
            d.lines.length + ' 条线路',
        vod_actor: (d.meta && d.meta.actor) || '', vod_director: (d.meta && d.meta.director) || '',
        vod_area: (d.meta && d.meta.area) || '', vod_year: (d.meta && d.meta.year) || '',
        vod_class: (d.meta && d.meta.vodClass) || '', vod_score: (d.meta && d.meta.score) || '',
        vod_content: (d.meta && d.meta.content) || '',
        mark: first ? first.name : '',
        lines: d.lines
      }).then(function () {
        ds.toast('已推送到 DsPlayer（' + d.lines.length + ' 线路）');
      }).catch(function (e) {
        log('push failed: ' + (e && e.message));
        ds.toast('推送失败：' + (e && e.message));
      });
    } catch (e) {
      log('push error: ' + (e && e.stack || e));
      ds.toast('提取异常：' + (e && e.message));
    }
  }

  // 自动化/调试入口（automation: webeval 'window.__dsBoosterPush()'）
  window.__dsBoosterPush = pushToShell;

  function injectButton() {
    // 仅详情/播放页出按钮（首页也含 play-list 组件，纯 DOM 判会误出）
    if (!/\/(detail|vplay|play)\//.test(location.pathname)) return;
    if (!extractDetail()) return;
    if (document.getElementById('__dsPlayFab')) return;
    var b = document.createElement('div');
    b.id = '__dsPlayFab';
    b.textContent = '▶ DsPlayer';
    b.style.cssText =
        'position:fixed;right:14px;bottom:96px;z-index:2147483647;' +
        'padding:10px 16px;border-radius:99px;cursor:pointer;' +
        'background:linear-gradient(135deg,#FF512F,#FF9A3D);color:#fff;' +
        'font:700 13px/1 -apple-system,"PingFang SC",sans-serif;' +
        'box-shadow:0 6px 18px rgba(255,81,47,.45);' +
        '-webkit-tap-highlight-color:transparent;user-select:none;';
    b.onclick = pushToShell;
    (document.body || document.documentElement).appendChild(b);
    log('button injected @ ' + location.pathname);
  }

  function boot() {
    try { injectButton(); } catch (e) { log('inject failed: ' + e); }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  // SPA 路由兜底（本站 MPA，挑战跳转会重注——幂等守卫兜住）
  var lastPath = location.pathname;
  setInterval(function () {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      boot();
    }
  }, 800);
})();

// bundle 版包装器：模块求值即自启（原 server.js 顶层 startServer，无主模块判断）
import './server.bundle.mjs';

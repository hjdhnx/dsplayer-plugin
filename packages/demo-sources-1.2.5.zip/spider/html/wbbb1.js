/* 页面增强器：歪比巴卜 wbbb1.com（MacCMS V10 模板通用提取器）
 * 形态：api=web://https://wbbb1.com/ + ext=本文件（wbbb1.web.json 同名挂载）
 * 能力：详情页注入「用 DsPlayer 播放」按钮 → 提取全部线路/选集推壳子
 *       详情页；点集时 __dsResolver 在页面会话内 fetch 播放页提流
 *       （站有 JS cookie 挑战，Dart 侧无会话 cookie——必须页内 fetch）。
 * 契约：幂等（__dsBooster 守卫）；ds/fm 桥由壳子先行注入；只动 DOM 不
 *       劫持站内行为。适配其它 MacCMS V10 站：改 TOP_ORIGIN + 选择器微调。
 */
(function () {
  'use strict';
  if (window.__dsBooster) return;
  window.__dsBooster = 1;

  var TOP_ORIGIN = location.origin;
  // UA 勿用 navigator.userAgent——WebView UA 含 '; wv' 标记被挑战站 WAF
  // 拒（py 源同款嗅探器能通/我们不能的唯二差异之一）；标准移动 Chrome
  var CHROME_UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36';

  function log(m) { try { console.log('[wbbb1-booster] ' + m); } catch (e) {} }

  /* ---------- DOM 提取（MacCMS V10） ---------- */

  function absUrl(u) {
    if (!u) return '';
    if (u.indexOf('//') === 0) return 'https:' + u;
    if (u.charAt(0) === '/') return TOP_ORIGIN + u;
    return u;
  }

  function picOf(el) {
    if (!el) return '';
    var img = el.querySelector('img');
    if (!img) return '';
    return absUrl(img.getAttribute('data-original') ||
        img.getAttribute('data-src') || img.src || '');
  }

  // 线路名（同块配对，2026-10-11 修正：全局 tab 序会把筛选区「排序」当
  // 线路名——data-id 配对 > 播放块内 tab 序 > 线路N 兜底）
  function lineNameOf(listEl, idx) {
    var p = listEl;
    for (var i = 0; i < 4 && p; i++) {
      var id = p.getAttribute && p.getAttribute('data-id');
      if (id) {
        var t = document.querySelector(
          '.module-tab-item[data-id="' + id + '"],' +
          '.module-tab-small[data-id="' + id + '"],' +
          'a[data-id="' + id + '"],li[data-id="' + id + '"]');
        var n = (t ? t.textContent : '').trim();
        if (n) return n;
      }
      p = p.parentElement;
    }
    var blk = listEl.closest('.module-box, .module, .playlist');
    if (blk) {
      var NON_LINE = ['排序', '正序', '倒序', '最新', '最热', '筛选', '展开', '收起', '更多', '推荐', '全部'];
      var tabs = blk.querySelectorAll('.module-tab-item, .module-tab-small');
      var names = [];
      for (var i = 0; i < tabs.length; i++) {
        var t2 = (tabs[i].textContent || '').trim();
        if (!t2) continue;
        var bad = false;
        for (var j = 0; j < NON_LINE.length; j++) {
          if (t2.indexOf(NON_LINE[j]) >= 0) { bad = true; break; }
        }
        if (!bad) names.push(t2);
      }
      if (names[idx]) return names[idx];
    }
    return '线路' + (idx + 1);
  }

  // 详情页数据：{ vid, title, pic, lines:[{name, episodes:[{name,url}]}] }
  function extractDetail() {
    var lists = document.querySelectorAll('.module-play-list');
    if (!lists.length) return null;
    var vid = (location.pathname.match(/\/(?:detail|vplay)\/(\d+)/) || [])[1] ||
        String(Date.now());
    var h1 = document.querySelector('h1, .page-title, .module-info-content h1');
    var title = h1 ? (h1.textContent || '').trim() : document.title;
    var pic = picOf(document.querySelector('.module-info-poster')) ||
        picOf(document.querySelector('.module-item-pic'));
    var lines = [];
    for (var i = 0; i < lists.length; i++) {
      var eps = [];
      var as = lists[i].querySelectorAll('.module-play-list-link, a[href]');
      for (var j = 0; j < as.length; j++) {
        var a = as[j];
        var href = absUrl(a.getAttribute('href'));
        if (href.indexOf('/vplay/') < 0 && href.indexOf('/play/') < 0) continue;
        var name = (a.textContent || '').trim().replace(/\s+/g, ' ');
        if (!name || !href) continue;
        eps.push({ name: name, url: href, resolve: true });
      }
      if (eps.length) {
        lines.push({ name: lineNameOf(lists[i], i), episodes: eps });
      }
    }
    if (!lines.length) return null;
    return { vid: vid, title: title, pic: pic, lines: lines, meta: metaOf() };
  }

  // CMS 元信息（label 行式扫描，与通用提取器同构）
  function metaOf() {
    function txtOf(el) {
      return el ? (el.textContent || '').trim().replace(/\s+/g, ' ') : '';
    }
    function byLabel(keys) {
      var rows = document.querySelectorAll('.module-info-item, .stui-content__detail p');
      for (var i = 0; i < rows.length; i++) {
        var label = txtOf(rows[i].querySelector('.module-info-item-title, dt, span:first-child')) || txtOf(rows[i]);
        for (var k = 0; k < keys.length; k++) {
          if (label.indexOf(keys[k]) >= 0) {
            var val = txtOf(rows[i].querySelector('.module-info-item-content, dd, a, span:last-child'));
            if (val && val !== label) return val.slice(0, 300);
          }
        }
      }
      return '';
    }
    var intro = txtOf(document.querySelector(
        '.module-info-introduction p, .stui-content__desc, [class*=introduction] p, [class*=desc] p'));
    return {
      actor: byLabel(['主演', '演员']), director: byLabel(['导演']),
      area: byLabel(['地区', '国家']), year: byLabel(['年份', '年代', '上映']),
      vodClass: byLabel(['类型', '题材']),
      score: txtOf(document.querySelector('.module-info-douban-score, [class*=score]')),
      content: intro.slice(0, 500)
    };
  }

  /* ---------- 播放页提流（__dsResolver，页面会话内 fetch） ---------- */

  function extractPlayUrl(html) {
    // 直链判定 = 媒体后缀（.m3u8/.mp4）；无后缀的 player_aaaa.url 是
    // 加密参数（歪比实锤 "kJrerEB…"），绝不当直链——交给 lazy 解密链
    function isMedia(u) { return /\.(m3u8|mp4|flv)(\?|$)/i.test(u); }
    var m = html.match(/"url"\s*:\s*"([^"]+)"/);
    if (m && isMedia(m[1])) return absUrl(m[1]);
    m = html.match(/(?:url1|url2)\s*[:=]\s*['"]([^'"]+)['"]/);
    if (m && isMedia(m[1])) return absUrl(m[1]);
    m = html.match(/https?:\/\/[^"'\s]+\.m3u8[^"'\s]*/);
    if (m) return m[0];
    return '';
  }

  /* ---------- lazy 解析规则（2026-10-11，移植自歪比 py 源全链） ----------
   * window.__dsLazy = async (pageUrl) => ({url, headers}) | null——站点定制
   * 直链规则挂点（通用提取器 resolver 会先试它）。链路：
   * 1 403 挑战纯算法解算（huadong js 的 key/value → md5(ord+1) 摘要 →
   *   yanzheng 端点换 cookie → 重放）
   * 2 播放页提 url_param（iframe /player/?url=X 或 player_aaaa.url）
   * 3 直链短路（.m3u8/.mp4）
   * 4 RC4+MD5 签名（salt=stray，rc4_key=md5(url) 尾 22）→ api.php 经
   *   fm.req 代理（跨域 POST 走 Dart 侧无 CORS）
   * 5 RC4 解动态 AES key/iv → crypto.subtle AES-CBC 解出 m3u8
   */
  var md5 = function (str) {
    function rl(n, c) { return (n << c) | (n >>> (32 - c)); }
    function au(x, y) { var l = (x & 0xFFFF) + (y & 0xFFFF), m = (x >> 16) + (y >> 16) + (l >> 16); return (m << 16) | (l & 0xFFFF); }
    function cmn(q, a, b, x, s, t) { return au(rl(au(au(a, q), au(x, t)), s), b); }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
    function tb(str) {
      var nb = ((str.length + 8) >> 6) + 1, blk = [], i;
      for (i = 0; i < nb * 16; i++) blk[i] = 0;
      for (i = 0; i < str.length; i++) blk[i >> 2] |= (str.charCodeAt(i) & 0xFF) << ((i % 4) * 8);
      blk[i >> 2] |= 0x80 << ((i % 4) * 8);
      blk[nb * 16 - 2] = str.length * 8;
      return blk;
    }
    function hex(n) { var s = '', j; for (j = 0; j < 4; j++) s += ('0' + ((n >> (j * 8)) & 0xFF).toString(16)).slice(-2); return s; }
    return function (str) {
      str = unescape(encodeURIComponent(str));
      var x = tb(str), a = 1732584193, b = -271733879, c = -1732584194, d = 271733878, k, aa, bb, cc, dd;
      for (k = 0; k < x.length; k += 16) {
        aa = a; bb = b; cc = c; dd = d;
        a=ff(a,b,c,d,x[k],7,-680876936);d=ff(d,a,b,c,x[k+1],12,-389564586);c=ff(c,d,a,b,x[k+2],17,606105819);b=ff(b,c,d,a,x[k+3],22,-1044525330);
        a=ff(a,b,c,d,x[k+4],7,-176418897);d=ff(d,a,b,c,x[k+5],12,1200080426);c=ff(c,d,a,b,x[k+6],17,-1473231341);b=ff(b,c,d,a,x[k+7],22,-45705983);
        a=ff(a,b,c,d,x[k+8],7,1770035416);d=ff(d,a,b,c,x[k+9],12,-1958414417);c=ff(c,d,a,b,x[k+10],17,-42063);b=ff(b,c,d,a,x[k+11],22,-1990404162);
        a=ff(a,b,c,d,x[k+12],7,1804603682);d=ff(d,a,b,c,x[k+13],12,-40341101);c=ff(c,d,a,b,x[k+14],17,-1502002290);b=ff(b,c,d,a,x[k+15],22,1236535329);
        a=gg(a,b,c,d,x[k+1],5,-165796510);d=gg(d,a,b,c,x[k+6],9,-1069501632);c=gg(c,d,a,b,x[k+11],14,643717713);b=gg(b,c,d,a,x[k],20,-373897302);
        a=gg(a,b,c,d,x[k+5],5,-701558691);d=gg(d,a,b,c,x[k+10],9,38016083);c=gg(c,d,a,b,x[k+15],14,-660478335);b=gg(b,c,d,a,x[k+4],20,-405537848);
        a=gg(a,b,c,d,x[k+9],5,568446438);d=gg(d,a,b,c,x[k+14],9,-1019803690);c=gg(c,d,a,b,x[k+3],14,-187363961);b=gg(b,c,d,a,x[k+8],20,1163531501);
        a=gg(a,b,c,d,x[k+13],5,-1444681467);d=gg(d,a,b,c,x[k+2],9,-51403784);c=gg(c,d,a,b,x[k+7],14,1735328473);b=gg(b,c,d,a,x[k+12],20,-1926607734);
        a=hh(a,b,c,d,x[k+5],4,-378558);d=hh(d,a,b,c,x[k+8],11,-2022574463);c=hh(c,d,a,b,x[k+11],16,1839030562);b=hh(b,c,d,a,x[k+14],23,-35309556);
        a=hh(a,b,c,d,x[k+1],4,-1530992060);d=hh(d,a,b,c,x[k+4],11,1272893353);c=hh(c,d,a,b,x[k+7],16,-155497632);b=hh(b,c,d,a,x[k+10],23,-1094730640);
        a=hh(a,b,c,d,x[k+13],4,681279174);d=hh(d,a,b,c,x[k],11,-358537222);c=hh(c,d,a,b,x[k+3],16,-722521979);b=hh(b,c,d,a,x[k+6],23,76029189);
        a=hh(a,b,c,d,x[k+9],4,-640364487);d=hh(d,a,b,c,x[k+12],11,-421815835);c=hh(c,d,a,b,x[k+15],16,530742520);b=hh(b,c,d,a,x[k+2],23,-995338651);
        a=ii(a,b,c,d,x[k],6,-198630844);d=ii(d,a,b,c,x[k+7],10,1126891415);c=ii(c,d,a,b,x[k+14],15,-1416354905);b=ii(b,c,d,a,x[k+5],21,-57434055);
        a=ii(a,b,c,d,x[k+12],6,1700485571);d=ii(d,a,b,c,x[k+3],10,-1894986606);c=ii(c,d,a,b,x[k+10],15,-1051523);b=ii(b,c,d,a,x[k+1],21,-2052929799);
        a=ii(a,b,c,d,x[k+8],6,1873313359);d=ii(d,a,b,c,x[k+15],10,-30611744);c=ii(c,d,a,b,x[k+6],15,-1560198380);b=ii(b,c,d,a,x[k+13],21,1309151649);
        a=ii(a,b,c,d,x[k+4],6,-145523070);d=ii(d,a,b,c,x[k+11],10,-1120210379);c=ii(c,d,a,b,x[k+2],15,718787258);b=ii(b,c,d,a,x[k+9],21,-343485551);
        a = au(a, aa); b = au(b, bb); c = au(c, cc); d = au(d, dd);
      }
      return hex(a) + hex(b) + hex(c) + hex(d);
    };
  }();
  function rc4Bytes(key, dataBytes) {
    var S = [], i, j = 0, x, res = [];
    for (i = 0; i < 256; i++) S[i] = i;
    for (i = 0; i < 256; i++) { j = (j + S[i] + key.charCodeAt(i % key.length)) % 256; x = S[i]; S[i] = S[j]; S[j] = x; }
    i = j = 0;
    for (var n = 0; n < dataBytes.length; n++) {
      i = (i + 1) % 256; j = (j + S[i]) % 256; x = S[i]; S[i] = S[j]; S[j] = x;
      res.push(dataBytes[n] ^ S[(S[i] + S[j]) % 256]);
    }
    return res;
  }
  function b64ToBytes(b64) {
    var s = atob(b64), out = [];
    for (var i = 0; i < s.length; i++) out.push(s.charCodeAt(i));
    return out;
  }
  function bytesToStr(bs) { var s = ''; for (var i = 0; i < bs.length; i++) s += String.fromCharCode(bs[i]); return s; }
  function enplay(key, dataStr) {
    var bytes = [];
    for (var i = 0; i < dataStr.length; i++) bytes.push(dataStr.charCodeAt(i) & 0xFF);
    return btoa(bytesToStr(rc4Bytes(key, bytes)));
  }
  function deplay(key, b64Str) { return bytesToStr(rc4Bytes(key, b64ToBytes(b64Str))); }

  async function fetchWithChallenge(url) {
    for (var attempt = 0; attempt < 3; attempt++) {
      var r = await fetch(url, { credentials: 'include' });
      if (r.status === 200) return await r.text();
      if (r.status !== 403) return null;
      var text = await r.text().catch(function () { return ''; });
      var jm = text.match(/src="(\/huadong_[^"]+\.js\?id=\d+)"/);
      if (!jm) { if (attempt > 0) return null; continue; }
      try {
        var jsUrl = new URL(jm[1], url).href;
        var js = await (await fetch(jsUrl, { credentials: 'include' })).text();
        var kv = js.match(/key="([0-9a-f]{32})",value="([0-9a-f]{32})"/);
        var ep = js.match(/c\.get\("(\/[^"]+_yanzheng_huadong\.php\?type=[0-9a-f]{32})&key="/);
        if (!(kv && ep)) return null;
        var ord = '';
        for (var i = 0; i < kv[2].length; i++) ord += String(kv[2].charCodeAt(i) + 1);
        var digest = md5(ord);
        await fetch(new URL(ep[1] + '&key=' + kv[1] + '&value=' + digest, url).href,
            { credentials: 'include' });
      } catch (e) { log('challenge fail: ' + e); }
    }
    return null;
  }

  function iframePage(url) {
    return new Promise(function (resolve) {
      var f = document.createElement('iframe');
      // 勿 display:none——隐藏 iframe 的定时器/动画被节流，挑战 JS 的
      // 延迟计算不执行（2026-10-11 实锤 unsolved）；屏外 1px 保持可渲染
      f.style.cssText =
          'position:fixed;left:-9999px;top:0;width:1px;height:1px;border:0;opacity:0.01;';
      f.src = url;
      var done = false;
      function finish(html) {
        if (done) return;
        done = true;
        clearTimeout(tm);
        f.remove();
        resolve(html);
      }
      var tm = setTimeout(function () { finish(''); }, 9000);
      f.onload = function () {
        var tries = 0;
        (function poll() {
          if (done) return;
          try {
            var doc = f.contentDocument;
            if (doc) {
              var h = doc.documentElement.outerHTML;
              // 播放页特征：player 数据字段就绪（挑战壳只有跳转 script）
              if (h.length > 5000 && h.indexOf('"url"') >= 0) { finish(h); return; }
            }
          } catch (e) {}
          if (++tries < 24) setTimeout(poll, 400);
          else finish('');
        })();
      };
      (document.body || document.documentElement).appendChild(f);
    });
  }

  window.__dsLazy = async function (pageUrl) {
    try {
      var html = await fetchWithChallenge(pageUrl);
      if (!html) {
        // 新版挑战（2026-10-11：huadong js 已改 CryptoJS 混淆 + %s 模板，
        // 纯算法解算失效）——iframe 真加载让浏览器自己过挑战，同源读文档
        html = await iframePage(pageUrl);
        if (!html) { log('lazy: challenge unsolved (fetch+iframe both)'); return null; }
      }
      var urlParam = '', playHost = 'xn--qvr2v.850088.xyz';
      var im = html.match(/<iframe[^>]*src=["'](https?:\/\/[^"']+\/player\/\?url=[^"'&]+)["'&]/i);
      if (im) {
        var p = new URL(im[1].replace(/&amp;/g, '&'));
        playHost = p.host;
        urlParam = p.searchParams.get('url') || '';
      }
      if (!urlParam) {
        // 播放页唯一 url 字段即 player_aaaa.url——整对象 parse 会被嵌套
        // vod_data 的 } 提前截断（真机实锤），字段直提稳
        var pm = html.match(/"url"\s*:\s*"([^"]+)"/);
        if (pm) urlParam = pm[1];
      }
      if (!urlParam) { log('lazy: no url_param (host=' + playHost + ')'); return null; }
      log('lazy: url_param=' + urlParam.slice(0, 24) + ' host=' + playHost);
      if (/\.(m3u8|mp4)(\?|$)/i.test(urlParam)) {
        return { url: urlParam, headers: { CHROME_UA } };
      }
      var salt = 'stray', t = String(Math.floor(Date.now() / 1000));
      var urlMd5 = md5(urlParam);
      var rc4Key = urlMd5.slice(-22);
      var api = 'https://' + playHost + '/player/api.php';
      var body = {
        url: urlParam,
        key: enplay(rc4Key, md5(urlParam + salt)),
        vkey: enplay(rc4Key, t + md5(rc4Key + salt)),
        ckey: enplay(rc4Key, md5(playHost + salt))
      };
      var r2 = await fm.req(api, {
        method: 'POST',
        headers: {
          CHROME_UA,
          'Referer': 'https://' + playHost + '/player/?url=' + urlParam,
          'Origin': 'https://' + playHost,
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Accept': 'application/json, text/javascript, */*; q=0.01',
          'X-Requested-With': 'XMLHttpRequest'
        },
        postType: 'form',
        data: body,
        responseType: 'text',
        timeout: 15
      });
      if (!r2 || !r2.ok) return null;
      var j = {};
      try { j = JSON.parse(r2.body); } catch (e) { return null; }
      if (!(j.url && j.aes_key && j.aes_iv)) return null;
      var aesKey = deplay(rc4Key, j.aes_key);
      var aesIv = deplay(rc4Key, j.aes_iv);
      var enc = b64ToBytes(j.url);
      var ck = await crypto.subtle.importKey('raw',
          new TextEncoder().encode(aesKey), { name: 'AES-CBC' }, false, ['decrypt']);
      var dec = await crypto.subtle.decrypt(
          { name: 'AES-CBC', iv: new TextEncoder().encode(aesIv) },
          ck, new Uint8Array(enc));
      var m3u8 = new TextDecoder().decode(dec);
      log('lazy resolved: ' + m3u8.slice(0, 80));
      return { url: m3u8, headers: { CHROME_UA } };
    } catch (e) {
      log('lazy error: ' + (e && e.message));
      return null;
    }
  };

  window.__dsResolver = async function (ep) {
    var pageUrl = ep && ep.url;
    if (!pageUrl) return null;
    // lazy 规则优先（站点定制直链链，2026-10-11）
    try {
      var lazy = await window.__dsLazy(pageUrl);
      if (lazy && lazy.url) return lazy;
    } catch (e) {}
    if (/\.(m3u8|mp4)(\?|$)/i.test(pageUrl)) {
      return { url: pageUrl, headers: { CHROME_UA, 'Referer': TOP_ORIGIN + '/' } };
    }
    // 快路径：页内 fetch（无挑战站）；不中即 webview:// 交给壳子嗅探链
    try {
      var r = await fetch(pageUrl, { credentials: 'include' });
      if (r.ok) {
        var html = await r.text();
        var url = extractPlayUrl(html);
        if (url) {
          log('resolved(fetch) ' + url.slice(0, 80));
          return { url: url, headers: { CHROME_UA, 'Referer': TOP_ORIGIN + '/' } };
        }
      }
    } catch (e) {}
    log('fallback to sniff: ' + pageUrl);
    return { url: 'webview://' + pageUrl, headers: { CHROME_UA, 'Referer': TOP_ORIGIN + '/' } };
  };

  /* ---------- 注入按钮 ---------- */

  function pushToShell() {
    try {
      var d = extractDetail();
      log('extract: ' + (d ? (d.title + ' / ' + d.lines.length + ' lines / ' +
          d.lines.map(function (l) { return l.episodes.length; }).join('+') + ' eps')
          : 'null'));
      if (!d) {
        ds.toast('未提取到选集数据（选集列表选择器未命中）');
        return;
      }
      // 首集名（线路 1 第 1 集）作 mark：详情页预选
      var first = d.lines[0].episodes[0];
      fm.vodInline({
        vod_id: 'wbbb1_' + d.vid,
        vod_name: d.title,
        vod_pic: d.pic,
        vod_remarks: 'wbbb1 · 共 ' + d.lines[0].episodes.length + ' 集 · ' +
            d.lines.length + ' 条线路',
        vod_actor: (d.meta && d.meta.actor) || '', vod_director: (d.meta && d.meta.director) || '',
        vod_area: (d.meta && d.meta.area) || '', vod_year: (d.meta && d.meta.year) || '',
        vod_class: (d.meta && d.meta.vodClass) || '', vod_score: (d.meta && d.meta.score) || '',
        vod_content: (d.meta && d.meta.content) || '',
        mark: first ? first.name : '',
        lines: d.lines
      }).then(function () {
        ds.toast('已推送到 DsPlayer（' + d.lines.length + ' 线路）');
      }).catch(function (e) {
        log('push failed: ' + (e && e.message));
        ds.toast('推送失败：' + (e && e.message));
      });
    } catch (e) {
      log('push error: ' + (e && e.stack || e));
      ds.toast('提取异常：' + (e && e.message));
    }
  }

  // 自动化/调试入口（automation: webeval 'window.__dsBoosterPush()'）
  window.__dsBoosterPush = pushToShell;

  function injectButton() {
    // 仅详情/播放页出按钮（首页也含 play-list 组件，纯 DOM 判会误出）
    if (!/\/(detail|vplay|play)\//.test(location.pathname)) return;
    if (!extractDetail()) return;
    if (document.getElementById('__dsPlayFab')) return;
    var b = document.createElement('div');
    b.id = '__dsPlayFab';
    b.textContent = '▶ DsPlayer';
    b.style.cssText =
        'position:fixed;right:14px;bottom:96px;z-index:2147483647;' +
        'padding:10px 16px;border-radius:99px;cursor:pointer;' +
        'background:linear-gradient(135deg,#FF512F,#FF9A3D);color:#fff;' +
        'font:700 13px/1 -apple-system,"PingFang SC",sans-serif;' +
        'box-shadow:0 6px 18px rgba(255,81,47,.45);' +
        '-webkit-tap-highlight-color:transparent;user-select:none;';
    b.onclick = pushToShell;
    (document.body || document.documentElement).appendChild(b);
    log('button injected @ ' + location.pathname);
  }

  function boot() {
    try { injectButton(); } catch (e) { log('inject failed: ' + e); }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  // SPA 路由兜底（本站 MPA，挑战跳转会重注——幂等守卫兜住）
  var lastPath = location.pathname;
  setInterval(function () {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      boot();
    }
  }, 800);
})();

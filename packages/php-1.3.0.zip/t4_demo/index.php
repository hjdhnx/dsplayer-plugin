<?php
/**
 * PHP 服务控制台（1.3.0：探针 JSON → HTML 状态页）
 * - 页面：服务状态卡 + /config.php 源列表入口 + 一键复制完整地址
 * - 机器可读探针兼容：?format=json 保持原 JSON 输出（健康检查只看 HTTP
 *   响应不看 body，改造无回归风险）
 */
$isHttps = (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on' || $_SERVER['HTTPS'] == 1))
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
$scheme = $isHttps ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';
$dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$configUrl = $scheme . $host . $dir . '/config.php';

if (isset($_GET['format']) && $_GET['format'] === 'json') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'ok',
        'message' => 'PHP 服务运行正常',
        'version' => PHP_VERSION,
        'platform' => 'Android',
        'time' => date('Y-m-d H:i:s'),
        'extensions' => get_loaded_extensions(),
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
header('Content-Type: text/html; charset=utf-8');
$extCount = count(get_loaded_extensions());
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PHP 服务状态</title>
<style>
  body { font-family: -apple-system, "Segoe UI", Roboto, sans-serif; background: #f6f7f9;
         color: #22262b; margin: 0; padding: 24px 16px; }
  .card { max-width: 560px; margin: 0 auto 14px; background: #fff; border: 1px solid #e6e8eb;
          border-radius: 14px; padding: 18px 20px; }
  h1 { font-size: 17px; margin: 0 0 12px; }
  .ok { color: #0d9463; font-weight: 600; }
  .kv { display: flex; justify-content: space-between; gap: 12px; padding: 5px 0;
        font-size: 13.5px; border-bottom: 1px dashed #eef0f2; }
  .kv:last-child { border-bottom: 0; }
  .kv b { font-weight: 500; color: #6a7178; }
  code { font-family: Menlo, Consolas, monospace; font-size: 12px; word-break: break-all; }
  .btn { display: inline-block; border: 0; border-radius: 9px; padding: 9px 16px; font-size: 14px;
         text-decoration: none; cursor: pointer; }
  .btn.primary { background: #e23e2b; color: #fff; }
  .btn.ghost { background: #f1f2f4; color: #22262b; }
  .row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 12px; }
  .hint { font-size: 12.5px; color: #6a7178; line-height: 1.7; margin: 8px 0 0; }
</style>
</head>
<body>
  <div class="card">
    <h1>PHP 服务状态 <span class="ok">● 运行中</span></h1>
    <div class="kv"><b>PHP 版本</b><span><?= htmlspecialchars(PHP_VERSION) ?></span></div>
    <div class="kv"><b>平台</b><span>Android</span></div>
    <div class="kv"><b>服务器时间</b><span><?= date('Y-m-d H:i:s') ?></span></div>
    <div class="kv"><b>已加载扩展</b><span><?= $extCount ?> 个</span></div>
  </div>
  <div class="card">
    <h1>T4 源列表（config.php）</h1>
    <p class="hint">以下地址可直接挂为 DsPlayer 的接口配置（生成的 sites 含 t4_demo 内全部站点源）：</p>
    <div class="kv"><b>地址</b><code id="cfgUrl"><?= htmlspecialchars($configUrl) ?></code></div>
    <div class="row">
      <a class="btn primary" href="config.php">打开 /config.php</a>
      <button class="btn ghost" onclick="copyCfg()">复制 config.php 完整地址</button>
    </div>
    <p class="hint">自定义脚本：把 PHP 源放进 <code>t4_demo/php/</code> 目录（会自动进源列表），
       详细约定见该目录下 README。</p>
  </div>
<script>
function copyCfg() {
  var url = document.getElementById('cfgUrl').textContent;
  function done() { alert('已复制：' + url); }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(done, function () { fallback(); });
  } else { fallback(); }
  function fallback() {
    var t = document.createElement('textarea');
    t.value = url; document.body.appendChild(t); t.select();
    document.execCommand('copy'); document.body.removeChild(t); done();
  }
}
</script>
</body>
</html>

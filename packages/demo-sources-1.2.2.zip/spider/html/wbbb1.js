/* 页面增强器：歪比巴卜 wbbb1.com（MacCMS V10 模板通用提取器）
 * 形态：api=web://https://wbbb1.com/ + ext=本文件（wbbb1.web.json 同名挂载）
 * 能力：详情页注入「用 DsPlayer 播放」按钮 → 提取全部线路/选集推壳子
 *       详情页；点集时 __dsResolver 在页面会话内 fetch 播放页提流
 *       （站有 JS cookie 挑战，Dart 侧无会话 cookie——必须页内 fetch）。
 * 契约：幂等（__dsBooster 守卫）；ds/fm 桥由壳子先行注入；只动 DOM 不
 *       劫持站内行为。适配其它 MacCMS V10 站：改 TOP_ORIGIN + 选择器微调。
 */
(function () {
  'use strict';
  if (window.__dsBooster) return;
  window.__dsBooster = 1;

  var TOP_ORIGIN = location.origin;

  function log(m) { try { console.log('[wbbb1-booster] ' + m); } catch (e) {} }

  /* ---------- DOM 提取（MacCMS V10） ---------- */

  function absUrl(u) {
    if (!u) return '';
    if (u.indexOf('//') === 0) return 'https:' + u;
    if (u.charAt(0) === '/') return TOP_ORIGIN + u;
    return u;
  }

  function picOf(el) {
    if (!el) return '';
    var img = el.querySelector('img');
    if (!img) return '';
    return absUrl(img.getAttribute('data-original') ||
        img.getAttribute('data-src') || img.src || '');
  }

  // 线路 tab 名：MacCMS V10 的 .module-tab-item / .module-tab-small 文本序
  // 与 .module-play-list 容器序一一对应；取不到按序号兜底
  function lineNames() {
    var out = [];
    var tabs = document.querySelectorAll(
        '.module-tab-item, .module-tab-small, .playlist-tab a');
    for (var i = 0; i < tabs.length; i++) {
      var t = (tabs[i].textContent || '').trim();
      if (t) out.push(t);
    }
    return out;
  }

  // 详情页数据：{ vid, title, pic, lines:[{name, episodes:[{name,url}]}] }
  function extractDetail() {
    var lists = document.querySelectorAll('.module-play-list');
    if (!lists.length) return null;
    var vid = (location.pathname.match(/\/(?:detail|vplay)\/(\d+)/) || [])[1] ||
        String(Date.now());
    var h1 = document.querySelector('h1, .page-title, .module-info-content h1');
    var title = h1 ? (h1.textContent || '').trim() : document.title;
    var pic = picOf(document.querySelector('.module-info-poster')) ||
        picOf(document.querySelector('.module-item-pic'));
    var names = lineNames();
    var lines = [];
    for (var i = 0; i < lists.length; i++) {
      var eps = [];
      var as = lists[i].querySelectorAll('.module-play-list-link, a[href]');
      for (var j = 0; j < as.length; j++) {
        var a = as[j];
        var href = absUrl(a.getAttribute('href'));
        if (href.indexOf('/vplay/') < 0 && href.indexOf('/play/') < 0) continue;
        var name = (a.textContent || '').trim().replace(/\s+/g, ' ');
        if (!name || !href) continue;
        eps.push({ name: name, url: href, resolve: true });
      }
      if (eps.length) {
        lines.push({ name: names[i] || ('线路' + (i + 1)), episodes: eps });
      }
    }
    if (!lines.length) return null;
    return { vid: vid, title: title, pic: pic, lines: lines };
  }

  /* ---------- 播放页提流（__dsResolver，页面会话内 fetch） ---------- */

  function extractPlayUrl(html) {
    // 优先级：player_aaaa.url（MacCMS 标准页内变量）> player_data > url1/2
    // > iframe src > 页内裸 m3u8
    var m = html.match(/var\s+player_aaaa\s*=\s*(\{[\s\S]*?\});/);
    if (m) {
      try {
        var pa = JSON.parse(m[1].replace(/'/g, '"'));
        if (pa.url && /^https?:|^\/\//.test(pa.url)) return absUrl(pa.url);
      } catch (e) {}
    }
    m = html.match(/var\s+player_data\s*=\s*(\{[\s\S]*?\});/);
    if (m) {
      try {
        var pd = JSON.parse(m[1].replace(/'/g, '"'));
        if (pd.url) return absUrl(pd.url);
      } catch (e) {}
    }
    m = html.match(/(?:url1|url2)\s*[:=]\s*['"]([^'"]+)['"]/);
    if (m) return absUrl(m[1]);
    m = html.match(/<iframe[^>]+src=["']([^"']+)["']/i);
    if (m) return absUrl(m[1]);
    m = html.match(/https?:\/\/[^"'\s]+\.m3u8[^"'\s]*/);
    if (m) return m[0];
    return '';
  }

  window.__dsResolver = async function (ep) {
    var pageUrl = ep && ep.url;
    if (!pageUrl) return null;
    if (/\.(m3u8|mp4)(\?|$)/i.test(pageUrl)) {
      return { url: pageUrl, headers: { 'User-Agent': navigator.userAgent, 'Referer': TOP_ORIGIN + '/' } };
    }
    // 快路径：页内 fetch（无挑战站）；不中即 webview:// 交给壳子嗅探链
    try {
      var r = await fetch(pageUrl, { credentials: 'include' });
      if (r.ok) {
        var html = await r.text();
        var url = extractPlayUrl(html);
        if (url) {
          log('resolved(fetch) ' + url.slice(0, 80));
          return { url: url, headers: { 'User-Agent': navigator.userAgent, 'Referer': TOP_ORIGIN + '/' } };
        }
      }
    } catch (e) {}
    log('fallback to sniff: ' + pageUrl);
    return { url: 'webview://' + pageUrl, headers: { 'User-Agent': navigator.userAgent, 'Referer': TOP_ORIGIN + '/' } };
  };

  /* ---------- 注入按钮 ---------- */

  function pushToShell() {
    try {
      var d = extractDetail();
      log('extract: ' + (d ? (d.title + ' / ' + d.lines.length + ' lines / ' +
          d.lines.map(function (l) { return l.episodes.length; }).join('+') + ' eps')
          : 'null'));
      if (!d) {
        ds.toast('未提取到选集数据（选集列表选择器未命中）');
        return;
      }
      // 首集名（线路 1 第 1 集）作 mark：详情页预选
      var first = d.lines[0].episodes[0];
      fm.vodInline({
        vod_id: 'wbbb1_' + d.vid,
        vod_name: d.title,
        vod_pic: d.pic,
        vod_remarks: 'wbbb1 · 共 ' + d.lines[0].episodes.length + ' 集 · ' +
            d.lines.length + ' 条线路',
        mark: first ? first.name : '',
        lines: d.lines
      }).then(function () {
        ds.toast('已推送到 DsPlayer（' + d.lines.length + ' 线路）');
      }).catch(function (e) {
        log('push failed: ' + (e && e.message));
        ds.toast('推送失败：' + (e && e.message));
      });
    } catch (e) {
      log('push error: ' + (e && e.stack || e));
      ds.toast('提取异常：' + (e && e.message));
    }
  }

  // 自动化/调试入口（automation: webeval 'window.__dsBoosterPush()'）
  window.__dsBoosterPush = pushToShell;

  function injectButton() {
    // 仅详情/播放页出按钮（首页也含 play-list 组件，纯 DOM 判会误出）
    if (!/\/(detail|vplay|play)\//.test(location.pathname)) return;
    if (!extractDetail()) return;
    if (document.getElementById('__dsPlayFab')) return;
    var b = document.createElement('div');
    b.id = '__dsPlayFab';
    b.textContent = '▶ DsPlayer';
    b.style.cssText =
        'position:fixed;right:14px;bottom:96px;z-index:2147483647;' +
        'padding:10px 16px;border-radius:99px;cursor:pointer;' +
        'background:linear-gradient(135deg,#FF512F,#FF9A3D);color:#fff;' +
        'font:700 13px/1 -apple-system,"PingFang SC",sans-serif;' +
        'box-shadow:0 6px 18px rgba(255,81,47,.45);' +
        '-webkit-tap-highlight-color:transparent;user-select:none;';
    b.onclick = pushToShell;
    (document.body || document.documentElement).appendChild(b);
    log('button injected @ ' + location.pathname);
  }

  function boot() {
    try { injectButton(); } catch (e) { log('inject failed: ' + e); }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
  // SPA 路由兜底（本站 MPA，挑战跳转会重注——幂等守卫兜住）
  var lastPath = location.pathname;
  setInterval(function () {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      boot();
    }
  }, 800);
})();

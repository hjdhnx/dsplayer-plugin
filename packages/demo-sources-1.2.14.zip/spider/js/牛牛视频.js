// 本资源来源于互联网公开渠道，仅可用于个人学习爬虫技术。
// 严禁将其用于任何商业用途，下载后请于 24 小时内删除，搜索结果均来自源站，本人不承担任何责任。
// 牛牛视频 —— CatVod open JS 源（移植自 PyramidStore 源 牛牛视频.py）
// ---------------------------------------------------------------------------
// ext：配置地址或业务域名。
//   · 直接填字符串即可（也可 JSON {"host":"..."}）。
//   · 留空 → 默认 https://nnal.oss-cn-beijing.aliyuncs.com/nn.php
//     （GET 后 AES-128-ECB 解密，key='@@bull!!!video$$'，取首行真实业务域名）
//   · 形如 https://xxx.com（无路径）→ 直接当业务域名使用
// ---------------------------------------------------------------------------
// 协议要点（py 原文逐条对齐）：
//   ① 业务接口全是 GET，响应体 AES-128-ECB 密文（base64），
//      key = 请求 path 的前 16 字符、不足 16 补 '0'（故 /list 与 /detail 的 key 不同）
//   ② 播放三套 src：hema(src2, 3DES-CBC) / xiaocao·xm3u8(src7, AES-CBC) / shizi(src10, 明文 JSON)
//   ③ src2 / src7 取列表与取播放地址前各要上报一次广告，缺则服务端下发放盗占位视频
//   ④ 播放地址 = replaceDomain + path + '?' + base64解码(ck) + wsSecret/wsTime，
//      wsSecret = md5(盐 + 路径 + wsTime)。wsTime 有效期约 5 分钟 ⇒
//      m3u8 与其 ts 分片都必须走本地代理现签（直连签名必过期 403）
//   ⑤ 默认不送 Accept-Encoding / Connection（fongmi 手动指定会破坏透明解压 → 业务全空）
//   ⑥ 设备号取自真机抓包（16 位 hex 固定值），服务端把 token 与该号绑定

import { Crypto } from 'assets://js/lib/cat.js';

// 猫影视(catvod-open)壳特征：js2Proxy + desX 存在、getProxy 不存在
const cat = typeof js2Proxy === 'function'
    && typeof desX === 'function'
    && typeof getProxy !== 'function';
// 表单值编码：猫影视 qs.stringify(encode:false) 不编码，需手动；fongmi FormBody.add 自动编码
const NEED_ENC = cat && typeof MD5 !== 'function';

// 全局唯一容器：配置常量 + 运行时状态
const C = {
    ver: '20261030-1',                  // 版本横幅：init 打一次，logcat 直接确认壳里跑的是哪份副本
    ns: 'niuniusp',                     // local 存储命名空间
    host: '',                           // 业务域名
    ext: {},                            // init 解析出的 ext（供 ensureReady 在独立上下文重建）
    siteKey: '', siteType: 0,           // init 注入，代理路由用
    parser: [],                         // /config 下发的解析站清单
    src: { src1: {}, src2: {}, src7: {}, src10: {} },
    // ads/adsAt：src7 广告位配置（/api/new_ad/get_list_v2 下发，ad_id/ad_source_id 会轮换，
    // 故按 TTL 缓存而非永久；硬编码历史值会被判「未看广告」→ 第二次起下发防盗占位）
    st: { src2: { token: '', map_list: {} }, src7: { token: '', vod_collection: {}, ads: null, adsAt: 0, listAdDone: false } },
    cdn: [], cdnSaved: '',             // 播放 CDN 候选池（host 与盐成对）
    dev: {}, aid: '',                   // 设备标识缓存（对齐 APP：生成一次长期复用）
    ps: { list: 0, search: 0 }          // 页大小自学习
};

const DEF_HOST = 'https://nnal.oss-cn-beijing.aliyuncs.com/nn.php';
const HOST_KEY = '@@bull!!!video$$';    // 配置地址密文的 AES key（正好 16 字节）
const DECOY = ['ydsp.skzsz.com'];       // 防盗占位视频专用 CDN（命中即代表没拿到真实内容）
const PAGE_DEF = { list: 12, search: 12 };

// 接口身份头（1.6.3 / com.qingbian.jz）：服务端按这套头决定下发哪一版 src 配置
// ★ dex 实证 q3.c.f()（okhttp 拦截器 k() 每请求注入），各头来源：
//   p='android'(字面量) / pkg=getPackageName() / v=versionName / t=登录token(未登录'')
//   y=登录态?1:0 / d=Settings.Secure android_id / product=Build.MODEL / os=Build.VERSION.RELEASE
// ⇒ product/d/os 全部读真机，dex 内无 SM-S9080 等字面量（抓包值）；JS 读不到真机，
//   product 固定 'xiaomi'，d 用随机 16hex（devSeed：生成一次 + 壳子 local 缓存 + 内存复用）。
const HDR = {
    'User-Agent': 'okhttp/3.12.1',
    'p': 'android', 'product': 'xiaomi', 't': '',
    'os': '12', 'v': '1.6.3', 'y': '1', 'pkg': 'com.qingbian.jz'
};
async function hdr() {                          // 完整身份头（d = 缓存的随机 android_id）
    const h = Object.assign({}, HDR);
    h['d'] = await devSeed();
    return h;
}

// 播放头（交播放器；每次新建，避免被壳子写回 Content-Type 污染）
function ph() { return { 'User-Agent': 'Mozi' }; }


// ---------------- 基础工具 ----------------
const BIG_ID = /("(?:[A-Za-z_][A-Za-z0-9_]{0,31})?[Ii][Dd]"\s*:\s*)(-?\d{15,})(?=\s*[,\}\]])/g;
function toJson(t) {
    if (!t) return null;
    try { return JSON.parse(String(t).replace(BIG_ID, '$1"$2"')); } catch (e) { return null; }
}
function md5(s) {
    if (typeof md5X === 'function') { try { return md5X(String(s)); } catch (e) { } }
    return Crypto.MD5(String(s)).toString();
}
function ms() { return String(Date.now()); }

// 设备标识：对齐 APP com.qingbian.jz 1.6.3 的 r3/y0.i()
//   deviceId = md5( androidId + System.currentTimeMillis() ).toLowerCase().substring(8, 24)   // 16 位 hex
//   androidId = Settings.Secure.getString(cr, "android_id")  （q3/c.e()，静态缓存）
// APP 生成后写 SharedPreferences("source")：XC_DEVICE_ID / XC_2_DEVICE_ID / HM_DEVICE_ID，并记 *_DEVICE_ID_STAMP；
// 之后一律复用缓存，只有设置页手动重置（SettingActivity -> y0.g()）才清空重生成。
// JS 侧读不到真机 ANDROID_ID，故种子用一枚「一次性生成并缓存」的 16 位 hex ——
// 语义等价于 Settings.Secure android_id（设备级稳定随机值），不手填、不每请求变化。
async function devSeed() {
    if (C.aid) return C.aid;
    let a = '';
    try { a = String((await local.get(C.ns, 'aid')) || ''); } catch (e) { }
    if (!/^[0-9a-f]{16}$/.test(a)) {
        a = md5(String(Math.random()) + ms() + String(Math.random())).slice(0, 16);
        try { await local.set(C.ns, 'aid', a); } catch (e) { }
    }
    C.aid = a;
    return a;
}
async function devId(kind) {                    // kind: xiaocao / xm3u8 / hema（APP 三套源各一份，互不共享）
    if (C.dev[kind]) return C.dev[kind];
    let v = '';
    try { v = String((await local.get(C.ns, 'dev_' + kind)) || ''); } catch (e) { }
    if (!/^[0-9a-f]{16}$/.test(v)) {
        v = md5((await devSeed()) + ms()).slice(8, 24);
        try { await local.set(C.ns, 'dev_' + kind, v); } catch (e) { }
    }
    C.dev[kind] = v;
    return v;
}

// 换新设备号：服务端按设备号放行播放地址（同号第二次起必被判风控），
// 命中风控后换号重试等价「换个新用户」，与小草V2 的 switchDev 同范式。
async function switchDev(kind) {
    C.dev[kind] = '';
    try { await local.set(C.ns, 'dev_' + kind, ''); } catch (e) { }
    // 新设备 = 新会话：列表页 pos2 需随新会话重发一次（换号后服务端对该号重新记账）
    if (C.st && C.st.src7) C.st.src7.listAdDone = false;
    return await devId(kind);
}
function hexTime() { return Math.floor(Date.now() / 1000).toString(16); }

// AES-ECB 解密（业务接口）：key = path 前 16 字符，不足补 '0'
function decKey(path) {
    const k = String(path).slice(0, 16);
    return k.length < 16 ? (k + '0000000000000000').slice(0, 16) : k;
}
function aesEcbDec(b64, key) {
    const s = String(b64 || '').trim();
    if (!s || !key) return '';
    if (typeof aesX === 'function') {
        const ivs = cat ? ['', null] : [null, ''];
        for (let i = 0; i < ivs.length; i++) {
            try {
                const t = aesX('AES/ECB/PKCS7', false, s, true, key, ivs[i], false);
                if (t) return String(t);
            } catch (e) { }
        }
    }
    try {
        return Crypto.AES.decrypt(
            { ciphertext: Crypto.enc.Base64.parse(s) },
            Crypto.enc.Utf8.parse(key),
            { mode: Crypto.mode.ECB, padding: Crypto.pad.Pkcs7 }
        ).toString(Crypto.enc.Utf8);
    } catch (e) { return ''; }
}
// AES-CBC 解密（src7）
function aesCbcDec(b64, key, iv) {
    const s = String(b64 || '').trim();
    if (!s || !key || !iv) return '';
    if (typeof aesX === 'function') {
        try {
            const t = aesX('AES/CBC/PKCS7', false, s, true, key, iv, false);
            if (t) return String(t);
        } catch (e) { }
    }
    try {
        return Crypto.AES.decrypt(
            { ciphertext: Crypto.enc.Base64.parse(s) },
            Crypto.enc.Utf8.parse(key),
            { iv: Crypto.enc.Utf8.parse(iv), mode: Crypto.mode.CBC, padding: Crypto.pad.Pkcs7 }
        ).toString(Crypto.enc.Utf8);
    } catch (e) { return ''; }
}
// 3DES-CBC 解密（src2）
function des3Dec(b64, key, iv) {
    const s = String(b64 || '').replace(/[\r\n\s]/g, '');
    if (!s || !key || !iv) return '';
    if (typeof desX === 'function') {
        try {
            const t = desX('DESede/CBC/PKCS7Padding', false, s, true, key, iv, false);
            if (t) return String(t);
        } catch (e) { }
    }
    try {
        return Crypto.TripleDES.decrypt(
            { ciphertext: Crypto.enc.Base64.parse(s) },
            Crypto.enc.Utf8.parse(key),
            { iv: Crypto.enc.Utf8.parse(iv), mode: Crypto.mode.CBC, padding: Crypto.pad.Pkcs7 }
        ).toString(Crypto.enc.Utf8);
    } catch (e) { return ''; }
}
function b64Decode(s) {
    try { return Crypto.enc.Base64.parse(String(s)).toString(Crypto.enc.Utf8); } catch (e) { return String(s == null ? '' : s); }
}
// base64url：代理 payload 全程塞进 URL 路径段，字符集只留 [-_A-Za-z0-9]
//   ⇒ 壳子编不编都不会变样（旧方案的 '@' 分隔会被编成 %40，encodeURIComponent 再叠一层变 %2540）
function b64uEnc(s) {
    return Crypto.enc.Utf8.parse(String(s)).toString(Crypto.enc.Base64)
        .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
// 标准 base64（带 padding、无换行）：臻享三步链请求体对齐 APK Base64.encodeToString(bytes, Base64.NO_WRAP)
function b64Enc(s) {
    return Crypto.enc.Utf8.parse(String(s)).toString(Crypto.enc.Base64);
}
function b64uDec(s) {
    let t = String(s).replace(/-/g, '+').replace(/_/g, '/');
    while (t.length % 4) t += '=';
    return b64Decode(t);
}
// base64url(字节)：ClearKey license 里的 k/kid 必须是无填充 base64url（壳侧 Base64 flag=11 同款）
function b64uFromBytes(u8) {
    return b64FromBytes(u8).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function hexToU8(hex) {
    const s = String(hex || '').toLowerCase();
    const n = s.length >> 1, u8 = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
        const v = parseInt(s.substr(i * 2, 2), 16);
        u8[i] = isNaN(v) ? 0 : v;
    }
    return u8;
}
// ClearKey license（对齐壳侧 bean/ClearKey：kty=oct / k / kid / type=temporary）
//   ⇒ 壳的 LocalClearKeyLicense.parse(key) 解析非空 ⇒ 强制 C.CLEARKEY_UUID（连 type 都不必写 clearkey）
function clearKeyLicense(kidHex, keyHex) {
    return JSON.stringify({
        keys: [{ kty: 'oct', k: b64uFromBytes(hexToU8(keyHex)), kid: b64uFromBytes(hexToU8(kidHex)) }],
        type: 'temporary'
    });
}
// [{key,value}...] → 请求头对象
function kvList(arr) {
    const o = {};
    for (let i = 0; i < (arr || []).length; i++) {
        const it = arr[i];
        if (it && it.key) o[String(it.key)] = String(it.value == null ? '' : it.value);
    }
    return o;
}
// 'k=v&k2=v2' → 对象（广告上报体是配置里下发的裸串）
function formToObj(s) {
    const o = {}, parts = String(s || '').split('&');
    for (let i = 0; i < parts.length; i++) {
        const p = parts[i];
        if (!p) continue;
        const at = p.indexOf('=');
        const k = at < 0 ? p : p.slice(0, at);
        const v = at < 0 ? '' : p.slice(at + 1);
        let kk = k, vv = v;
        try { kk = decodeURIComponent(k); } catch (e) { }
        try { vv = decodeURIComponent(v); } catch (e) { }
        o[kk] = vv;
    }
    return o;
}
// 'User-Agent: xxx\nReferer: yyy' → 请求头对象
function hdrTextToObj(s) {
    const o = {}, lines = String(s || '').split('\n');
    for (let i = 0; i < lines.length; i++) {
        const at = lines[i].indexOf(':');
        if (at < 0) continue;
        const k = lines[i].slice(0, at).trim(), v = lines[i].slice(at + 1).trim();
        if (k) o[k] = v;
    }
    return o;
}
// 臻享三步链专用：对齐 APK Src2RespXxxModel.getHeaderMap()（去 \r、按 \n 切、key 转小写）
//   与 hdrTextToObj 的差异就是这两点（APP 转小写后用于 OkHttp 头，大小写不敏感但保持原样更安全）
function nnHdrMap(s) {
    const o = {}, lines = String(s || '').replace(/\r/g, '').split('\n');
    for (let i = 0; i < lines.length; i++) {
        const at = lines[i].indexOf(':');
        if (at <= 0) continue;
        o[lines[i].slice(0, at).trim().toLowerCase()] = lines[i].slice(at + 1).trim();
    }
    return o;
}
function pathOf(u) {
    const s = String(u || '');
    const q = s.indexOf('?');
    const noQ = q > -1 ? s.slice(0, q) : s;
    const m = noQ.match(/^https?:\/\/[^/]+(.*)$/i);
    return m ? (m[1] || '') : noQ;
}

// ---------------- 请求封装 ----------------
async function getJson(path) {
    const r = await req(C.host + path, { headers: await hdr(), timeout: 15000 });
    return toJson(aesEcbDec(r && r.content ? r.content : '', decKey(path)));
}
function stripCT(h) {
    const o = {};
    for (const k in h) { if (String(k).toLowerCase() === 'content-type') continue; o[k] = h[k]; }
    return o;
}
// 表单 POST：必须 postType:'form' + data 对象（壳子注入 Content-Type）
async function postForm(url, obj, hdrs) {
    const data = {};
    for (const k in obj) {
        const v = String(obj[k] == null ? '' : obj[k]);
        data[k] = NEED_ENC ? encodeURIComponent(v) : v;
    }
    return req(url, { method: 'post', postType: 'form', headers: stripCT(hdrs || {}), data: data, timeout: 15000 });
}
// 裸串 POST：猫影视走 data + text/plain，fongmi/影图走 body + Content-Type
async function postRaw(url, rawStr, hdrs) {
    const h = stripCT(hdrs || {});
    h['Content-Type'] = 'text/plain; charset=UTF-8';
    const opt = { method: 'post', headers: h, timeout: 15000 };
    if (cat) opt.data = rawStr; else opt.body = rawStr;
    return req(url, opt);
}

// ---------------- init ----------------
function readExt(cfg) {
    let e = (cfg && typeof cfg === 'object') ? cfg.ext : cfg;
    if (typeof e === 'string') {
        const t = e.trim();
        if (t.charAt(0) === '{') { try { e = JSON.parse(t); } catch (err) { e = null; } }
        else return { host: t };
    }
    if (e && typeof e === 'object' && e.ext && typeof e.ext === 'object') e = e.ext;
    return (e && typeof e === 'object') ? e : {};
}

async function init(cfg) {
    C.siteKey = (cfg && cfg.skey) || '';
    C.siteType = (cfg && cfg.stype) || 0;
    C.ext = readExt(cfg);
    console.log('[牛牛视频] ' + 'init ver=' + C.ver + ' cat=' + cat + ' stream=' + (typeof netStreamBody === 'function' ? 1 : 0) + ' jspstream=' + (typeof JSProxyStream === 'function' ? 1 : 0) + ' drmauto=' + (!cat && drmAuto() ? 1 : 0));
    await ensureReady();
}

// ★ 猫影视 open(QuickJS) 每次生命周期调用可能是独立求值上下文，模块级 C 会被重置。
//   凡依赖 C.host/C.src 的函数（play / detail / category / search / homeVod）都必须先过这道守卫，
//   否则 play 时 C.src 为空 → 所有线路取不到播放地址（真机「所有线路 Url: -」的根因）。
let ready = null;
async function ensureReady() {
    if (C.host && C.src.src7.tokenUrl) return true;
    if (ready) return ready;
    ready = (async function () {
        try {
            let host = String((C.ext && C.ext.host) || '').trim();
            if (!host) host = DEF_HOST;
            // 只有「纯域名（可带端口）」才直接用；带路径的一律当成配置地址下载后解密取首行
            if (!/^https?:\/\/[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*(:\d+)?\/?$/.test(host)) {
                const r = await req(host, { headers: await hdr(), timeout: 15000 });
                const txt = aesEcbDec(r && r.content ? r.content : '', HOST_KEY);
                const lines = String(txt).split('\n');
                host = '';
                for (let i = 0; i < lines.length; i++) {
                    const t = lines[i].trim();
                    if (t) { host = t; break; }
                }
            }
            C.host = host.replace(/\/+$/, '');
            await loadConfig();
            console.log('[牛牛视频] ' + 'ensureReady: host=' + C.host + ' parser=' + C.parser.length
                + ' src7=' + (C.src.src7.tokenUrl ? 'Y' : 'N') + ' src2=' + (C.src.src2.listUrl ? 'Y' : 'N'));
        } catch (e) { console.log('[牛牛视频] ' + 'ensureReady: ' + e); }
        return !!(C.host && C.src.src7.tokenUrl);
    })();
    const ok = await ready;
    if (!ok) ready = null;                 // 失败允许下次重试
    return ok;
}

async function loadConfig() {
    const j = await getJson('/config');
    const d = (j && j.data) || {};
    C.parser = d.parser || [];
    C.src.src1 = d.src1 || {};
    C.src.src2 = d.src2 || {};
    C.src.src7 = d.src7 || {};
    C.src.src10 = d.src10 || {};
}

// ---------------- 列表 / 首页 / 分类 / 搜索 ----------------
function videoItem(j) {
    return {
        vod_id: String(j.vod_id == null ? '' : j.vod_id),
        vod_name: String(j.vod_name || ''),
        vod_pic: String(j.vod_pic || ''),
        vod_remarks: String(j.vod_remarks || j.vod_behind || ''),
        vod_year: parseInt(String(j.vod_year || '').slice(0, 4), 10) || 0,
        vod_douban_score: String(j.vod_douban_score == null ? '' : j.vod_douban_score)
    };
}

// 筛选组构造：服务端 type_extend 给的是逗号分隔词表；不足两项就不产出（避免空筛选组）
// 「全部」用哨兵 v='all'（空串在部分壳里被当无效值跳过 ⇒ 默认选中会落到第一项）
function filterGroup(key, name, csv) {
    const items = String(csv || '').split(',');
    const value = [{ n: '全部', v: 'all' }];
    for (let i = 0; i < items.length; i++) {
        const t = items[i].trim();
        if (t) value.push({ n: t, v: t });
    }
    return value.length > 1 ? { key: key, name: name, init: 'all', value: value } : null;
}

// 「状态」组（APK v1.6.3 实证：com.sexy.goddess.tab.main.MainItemFragment.onCreateView）
//   if ("1".equals(mainPageTypeModelD.extendModel.state)) {
//       itemConfigList.add([("状态",""), ("更新中","更新中"), ("已完结","已完结")]); hasStateChoose = true;
//   }
//   ⇒ 判据是「严格等值字符串 '1'」，不是「非空即真」。服务端 type_extend.state 只有 '1'（剧集/综艺/动漫）
//     与 ''（电影/短剧/直播）两种取值（见 APK 内置 assets/tab_list_json_default.json / h3.c 兜底串）。
//   词表由 APP 硬编码两值、服务端不下发；取值即中文原文（抓包实测）：
//   /list?state=更新中 → 整页「更新至xx集」；state=已完结 → 整页「已完结」。
function stateGroup(raw) {
    return String(raw || '').trim() === '1' ? filterGroup('state', '状态', '更新中,已完结') : null;
}

const filters = {};

async function home(filter) {
    const classes = [];
    try {
        const j = await getJson('/types');
        const data = (j && j.data) || [];
        for (let i = 0; i < data.length; i++) {
            const it = data[i];
            if (!it || typeof it !== 'object') continue;
            const ext = it.type_extend || {};
            // version 为空的分类才是可点进去的常规分类（其余为专题聚合，由首页行卡承载）
            if (!ext || typeof ext !== 'object' || String(ext.version || '') !== '') continue;
            const tid = String(it.type_id);
            classes.push({ type_id: tid, type_name: String(it.type_name || '') });
            // ★ 筛选项全部在线获取（源码不固化词表），组顺序与 APP 分类页一致：排序 / 类型 / 地区 / 年份 / 状态
            //   class / area / year —— 服务端 type_extend 按分类下发的逗号分隔词表
            //   order —— 抓包实证的三个有效值：最新 / 最热 / 评分（三个值实测返回互不相同）
            //   state —— 服务端 type_extend.state 为开关，词表见 stateGroup
            //   lang 服务端有词表但 APP 不带、实测传了也不生效；star/director/version 是标量元数据 ⇒ 不产出
            const gs = [];
            gs.push({ key: 'order', name: '排序', init: '最新', value: [{ n: '最新', v: '最新' }, { n: '最热', v: '最热' }, { n: '评分', v: '评分' }] });
            const gc = filterGroup('class', '类型', ext.class);
            const ga = filterGroup('area', '地区', ext.area);
            const gy = filterGroup('year', '年份', ext.year);
            const gt = stateGroup(ext.state);
            if (gc) gs.push(gc);
            if (ga) gs.push(ga);
            if (gy) gs.push(gy);
            if (gt) gs.push(gt);
            filters[tid] = gs;
        }
    } catch (e) { console.log('[牛牛视频] ' + '[首页分类] 获取失败：' + e); }
    if (cat) classes.unshift({ type_id: 'home', type_name: '首页' });
    // filters 不含虚拟分类 home，避免渲染空筛选面板
    return JSON.stringify({ class: classes, filters: null });
}

async function homeVod() {
    const videos = [];
    await ensureReady();
    try {
        const j = await getJson('/main');
        const data = (j && j.data) || [];
        for (let i = 0; i < data.length; i++) {
            const it = data[i];
            if (!it || typeof it !== 'object') continue;
            const list = it.list || [];
            for (let k = 0; k < list.length; k++) {
                if (list[k] && typeof list[k] === 'object') videos.push(videoItem(list[k]));
            }
        }
    } catch (e) { console.log('[牛牛视频] ' + '[首页推荐] 获取失败：' + e); }
    return JSON.stringify({ list: videos });
}

function pageCountOf(n, kind, page) {
    if (!n) return page;
    if (n > (C.ps[kind] || 0)) C.ps[kind] = n;
    const size = C.ps[kind] || PAGE_DEF[kind] || 12;
    return n >= size ? page + 1 : page;
}

async function category(tid, pg, filter, extend) {
    await ensureReady();
    if (tid === 'home') {
        const d = JSON.parse(await homeVod());
        return JSON.stringify({ list: d.list || [], page: 1, pagecount: 1 });
    }
    if (!C.host) return '{}';
    const page = parseInt(pg, 10) || 1;
    // ★ 第 3 参 filter 是「是否启用筛选」的布尔，真实选中值在第 4 参 extend（少数壳塞在第 3 参）
    const f = (extend && typeof extend === 'object') ? extend
        : ((filter && typeof filter === 'object') ? filter : {});
    const sel = function (k) {
        const v = String(f[k] == null ? '' : f[k]).trim();
        return v === 'all' ? '' : v;      // 'all' 是筛选面板「全部」的哨兵值 ⇒ 还原为不筛选
    };
    const cls = sel('class'), area = sel('area'), yr = sel('year'), st = sel('state');
    let ord = sel('order');
    if (!ord) ord = '最新';
    // ★ 参数顺序刻意与 APP 不同（APP 是 class/order/type_id/area/year/state/wd/page）：
    //   把 type_id、page 提到最前，使请求 URI 前 16 字节恒为纯 ASCII 的 '/list?type_id=1&'。
    //   原因：响应解密的 key = 请求 path 的前 16 字符（不足补 '0'），而筛选值多为中文；
    //   若中文落进前 16 字符，key 会随 URL 编码方式漂移导致解密失败、分类页空白。
    //   实测该顺序与 APP 原序请求返回逐条一致（服务端 $_GET 与顺序无关）。
    const path = '/list?type_id=' + encodeURIComponent(tid) + '&page=' + page
        + '&class=' + encodeURIComponent(cls) + '&order=' + encodeURIComponent(ord)
        + '&area=' + encodeURIComponent(area) + '&year=' + encodeURIComponent(yr)
        + '&state=' + encodeURIComponent(st) + '&wd=';
    let list = [];
    try {
        const j = await getJson(path);
        const data = (j && j.data) || [];
        for (let i = 0; i < data.length; i++) {
            if (data[i] && typeof data[i] === 'object') list.push(videoItem(data[i]));
        }
    } catch (e) { console.log('[牛牛视频] ' + '[分类] 获取失败：' + e); }
    return JSON.stringify({ list: list, page: page, pagecount: pageCountOf(list.length, 'list', page), filters: page===1 ? filters[tid] : null });
}

async function search(wd, quick, pg) {
    await ensureReady();
    if (!C.host) return '{}';
    const page = parseInt(pg, 10) || 1;
    const path = '/list?class=&order=&type_id=&area=&year=&state=&wd='
        + encodeURIComponent(String(wd || '')) + '&page=' + page;
    const videos = [];
    try {
        const j = await getJson(path);
        const data = (j && j.data) || [];
        for (let i = 0; i < data.length; i++) {
            const it = data[i];
            if (!it || typeof it !== 'object') continue;
            const item = videoItem(it);
            item.vod_content = String(it.vod_content || it.vod_blurb || '');
            videos.push(item);
        }
    } catch (e) { console.log('[牛牛视频] ' + '[搜索] 获取失败：' + e); }
    return JSON.stringify({ list: videos, page: page, pagecount: pageCountOf(videos.length, 'search', page) });
}

// ---------------- 详情 ----------------
async function detail(id) {
    await ensureReady();
    const vid = String(Array.isArray(id) ? id[0] : (id == null ? '' : id));
    if (!C.host || !vid) return JSON.stringify({ list: [] });
    const path = '/detail?vod_id=' + vid;
    let data = {};
    try {
        const j = await getJson(path);
        data = (j && j.data) || {};
    } catch (e) { console.log('[牛牛视频] ' + '[详情] 获取失败：' + e); }
    const playFrom = [], playUrls = [];
    const sources = data.sources || [];
    for (let i = 0; i < sources.length; i++) {
        const s = sources[i];
        if (!s || typeof s !== 'object') continue;
        const playerId = String(s.player_id == null ? '' : s.player_id);
        const eps = s.episodes || [];
        const one = [];
        for (let k = 0; k < eps.length; k++) {
            const ep = eps[k];
            if (!ep || typeof ep !== 'object') continue;
            one.push(String(ep.name || '') + '$' + playerId + ',' + String(ep.url || ''));
        }
        if (!one.length) continue;          // 无集数的线路整条丢弃，避免出现空的线路分组
        let show = '';
        for (let k = 0; k < C.parser.length; k++) {
            if (String(C.parser[k].player_id) === playerId) {
                const name = String(C.parser[k].player_name || playerId || '');
                show = name.charAt(name.length - 1) === '）' ? (name + '(' + playerId + ')') : (name + '\u2005(' + playerId + ')');
                break;
            }
        }
        if (!show) show = playerId;          // parser 未收录时兜底，保证 from 与 url 组数一致
        playFrom.push(show);
        playUrls.push(one.join('#'));
    }
    const video = {
        vod_id: String(data.vod_id == null ? vid : data.vod_id),
        vod_name: String(data.vod_name || ''),
        vod_pic: String(data.vod_pic || ''),
        vod_remarks: String(data.vod_remarks || ''),
        vod_year: parseInt(String(data.vod_year || '').slice(0, 4), 10) || 0,
        vod_area: String(data.vod_area || ''),
        vod_actor: String(data.vod_actor || ''),
        vod_director: String(data.vod_director || ''),
        vod_content: String(data.vod_content || data.vod_blurb || ''),
        vod_play_from: playFrom.join('$$$'),
        vod_play_url: playUrls.join('$$$')
    };
    return JSON.stringify({ list: [video] });
}

// ---------------- 播放 ----------------
async function play(flag, id, flags) {
    await ensureReady();                 // ★ 猫影视 open 的 play 可能处于独立求值上下文
    try {
        return await doPlay(flag, id);
    } catch (e) {
        // 取流失败只影响单集：返回空 url 让壳子弹「播放失败」，绝不让异常冒泡到壳子
        console.log('[牛牛视频] ' + '[播放] 取地址异常：' + e);
        return JSON.stringify({ parse: 0, url: '', header: ph() });
    }
}

async function doPlay(flag, id) {
    const s = String(id == null ? '' : id);
    console.log('[牛牛视频] ' + '[播放] flag=' + flag + ' id=' + s.slice(0, 80));
    if (s.indexOf(',') < 0) {
        console.log('[牛牛视频] ' + '[播放] id 无线路前缀，按直链处理');
        return JSON.stringify({ parse: 0, url: s, header: ph() });
    }
    const at = s.indexOf(',');
    const playFrom = s.slice(0, at), rawUrl = s.slice(at + 1);
    let res = null;
    if (playFrom === 'djzy') res = await srcDjzy(rawUrl);
    else if (playFrom === 'hema') res = await src2(rawUrl);
    else if (playFrom === 'xm3u8' || playFrom === 'xiaocao') res = await src1(playFrom, rawUrl);
    else if (playFrom === 'shizi') res = await src10(rawUrl);
    else res = await srcGeneric(playFrom, rawUrl);
    let url = '', headers = ph();
    if (res) {
        url = String(res.url || '');
        if (res.headers && Object.keys(res.headers).length) headers = res.headers;
    }
    const out = { parse: 0, url: url, header: headers };
    // 播放器解密（短剧）：壳子 Gson 解析 Result.drm / Result.format；不支持的壳静默忽略
    if (res && res.format) out.format = String(res.format);
    if (res && res.drm) out.drm = res.drm;
    console.log('[牛牛视频] ' + '[播放] ' + playFrom + ' → urlLen=' + url.length
        + (out.drm ? ' drm=clearkey' : '') + (out.format ? ' format=' + out.format : '')
        + (url ? (' url=' + url.slice(0, 120)) : ' 【取地址为空】'));
    return JSON.stringify(out);
}

// ---------------- 短剧：交给播放器解密（Result.drm / ClearKey） ----------------
// 壳侧实证（2026-10-30）：OK影视 3.0.3 / 5.1.6 / fongmi 上游 都在 MediaItem 构建处消费 Result.drm ——
//   bean/Drm{key,type,forceKey,header} + bean/ClearKey(kid:key) + C.CLEARKEY_UUID +
//   setForceDefaultLicenseUri(forceKey)（无 pssh 时靠它才用我们给的 license）。
//   drm 自 2023-08-03 就在 fongmi（"Support drm for live"），不是新版才有。
//   ★ 猫影视（cat）不是 fongmi 系，其 drm 支持未验证 ⇒ 恒走本地代理，本开关不参与。
// ★★ 默认改为「自动探测」（2026-10-30 二次改判，§十四）：
//   ① 判据 = 蜂蜜环境新函数 netStreamBody（quickjs runtime 1.0.7 新绑定的 _streamBody 在
//      net.js 里派生的全局函数）。真机三壳 init 日志实证：OK 3.0.3 stream=0、OK 5.1.6
//      stream=0、蜂蜜（自建5.8.0 runtime1.0.7）stream=1；官方蜂蜜 5.8.x 主 dex 无插件
//      字符串 ⇒ quickjs 插件运行时下发最新版 ⇒ 同样带 _streamBody。而 progressive MP4
//      CENC 软解（Mp4Extractor 白名单 + sinf/tenc/senc 解析）恰是 media3 新层（官方
//      5.8.x / 已补丁自建版）才有 ⇒ netStreamBody 在场 ≈ 壳子能吃 drm 直出。
//   ② ext 强制控制优先级最高：drm=1/true/on/yes ⇒ 强制直出；drm=0/false/off/no ⇒ 强制
//      代理；不填或其它值 ⇒ 自动（探测到 netStreamBody 直出，否则回落本地代理）。
//   ③ 猫影视（cat）恒走本地代理（调用点 !cat 守卫，不受本开关与 ext 强制影响）。
function drmAuto() {
    return typeof netStreamBody === 'function';
}
function drmOn() {
    const e = C.ext;
    const v = (e && typeof e === 'object') ? e.drm : undefined;
    if (v === undefined || v === null || v === '') return drmAuto();
    const s = String(v).trim().toLowerCase();
    if (s === '1' || s === 'true' || s === 'on' || s === 'yes') return true;
    if (s === '0' || s === 'false' || s === 'off' || s === 'no') return false;
    return drmAuto();
}
// KID 探测：★ 必须复用与代理完全相同的那条通道（mcAsset → bcRead），不能另开一套 Range 探测。
//   真机实证（2026-10-30 fongmi 261026 logcat）：play 阶段自己调 bcRead 四通道全失败（模式 0/3/1/2，
//   65ms 内跑完 ⇒ 请求根本没发出/没回字节），而同一个 URL 在代理里经 mcAsset 204ms 就建好索引。
//   ⇒ KID 从 mcAsset 解析结果里取（MP4C.parseSinf 已把 tenc 的 KID 存进 track.kid）。
//   附带的索引不浪费：拿不到 KID 回落代理时，代理直接命中 MC_CACHE，不重复建。
async function mp4TencKid(url, keyHex) {
    try {
        const a = await mcAsset(url, keyHex);
        const ts = (a && a.tracks) || [];
        for (let i = 0; i < ts.length; i++) {
            if (ts[i].isVid && /^[0-9a-f]{32}$/.test(String(ts[i].kid || ''))) return String(ts[i].kid);
        }
        for (let i = 0; i < ts.length; i++) {
            if (/^[0-9a-f]{32}$/.test(String(ts[i].kid || ''))) return String(ts[i].kid);
        }
        console.log('[牛牛视频] ' + '[短剧] KID 探测 tracks=' + ts.length + ' 内无 tenc KID');
    } catch (e) {
        console.log('[牛牛视频] ' + '[短剧] KID 探测失败：' + (e && e.message ? e.message : e));
        // ★ 清缓存：否则 MC_CACHE.p 是个 rejected Promise，回落代理时 mcAsset 会把它直接返给代理 ⇒ 整条链炸
        MC_CACHE.k = ''; MC_CACHE.a = null; MC_CACHE.p = null;
    }
    return '';
}

// 牛牛短剧（player_id=djzy）：加密 mp4，与 APP 同一调用时机
//   APP: 点播放 → x3.a(ParsePlayer) → z3.d.G(url,key,cacheId,hdr) → 下载+FFmpegKit 解密 → 播 file://
//   本源: 点播放 → play() 里请求 dj.php 拿 url/key → 交本地代理按 Range 流式解密（不落盘、可 seek）
//   注意 detail 阶段**不请求** dj.php（APP 也不请求），避免无谓消耗 1 小时有效期的 key。
async function srcDjzy(epId) {
    const headers = ph();
    let parser = null;
    for (let i = 0; i < C.parser.length; i++) {
        if (String(C.parser[i].player_id) === 'djzy') { parser = C.parser[i]; break; }
    }
    const api = (parser && parser.url) ? String(parser.url) : '';
    if (!api) { console.log('[牛牛视频] ' + '[短剧] parser 未收录 djzy 解析接口'); return null; }
    let j = null;
    try {
        const r = await req(api.replace('%s', String(epId)), { headers: await hdr(), timeout: 20000 });
        j = toJson(r && r.content ? r.content : '');
        console.log('[牛牛视频] ' + '[短剧] dj.php code=' + (r && r.code) + ' type=' + String((j || {}).type || '')
            + ' key=' + String((j || {}).key || '').slice(0, 8) + ' expire=' + String((j || {}).expire || ''));
    } catch (e) {
        console.log('[牛牛视频] ' + '[短剧] dj.php 异常：' + e);
        return null;
    }
    if (!j || !j.url) { console.log('[牛牛视频] ' + '[短剧] dj.php 未给出地址'); return null; }
    const keyHex = String(j.key || '').toLowerCase();
    // 与 APP 同一判据（z3.d.G：type=keymp4 且 key 必须 ^[0-9a-f]{32}$），否则按普通直链
    if (String(j.type || '').toLowerCase() !== 'keymp4' || !/^[0-9a-f]{32}$/.test(keyHex)) {
        console.log('[牛牛视频] ' + '[短剧] 非 keymp4，按直链输出');
        return { url: String(j.url), headers: headers };
    }
    // ★★ 播放器解密（自动探测 / ext 强制控制）：把「加密直链 + KID/KEY」交 Result.drm 由 ExoPlayer 自己解，
    //    整条本地代理（206 封顶 / {$tvStream} 流式 / 索引预热）全部跳过，seek 也白送。
    //    猫影视（cat）恒走代理：其 drm 支持未验证，且现代理方案真机已通过 —— 不动。
    if (true || (!cat && drmOn())) {
        const kidHex = await mp4TencKid(String(j.url), keyHex);
        if (/^[0-9a-f]{32}$/.test(kidHex)) {
            console.log('[牛牛视频] ' + '[短剧] drm 直出 kid=' + kidHex.slice(0, 8) + '（播放器解密，跳过本地代理）');
            return {
                url: String(j.url), headers: headers, format: 'video/mp4',
                drm: { type: 'clearkey', key: clearKeyLicense(kidHex, keyHex), forceKey: true }
            };
        }
        console.log('[牛牛视频] ' + '[短剧] 未取到 tenc KID，回落本地代理');
    }
    const payload = 'MP4-' + b64uEnc(JSON.stringify({ u: String(j.url), k: keyHex, e: j.expire || 0 }));
    // ★★ 猫影视预热索引：该壳的 proxy() 一返回就把响应对象取走，流对象 + head()（含总长 Content-Range）
    //    必须在那之前同步建好 ⇒ 索引不能在代理里才建。这里多花约 0.3s，换代理侧全程同步。
    //    runtime 1.0.7 流式壳（fongmi 261026）同理：206/content-length 头要 outSize，索引先行。
    if (cat && typeof JSProxyStream === 'function') {
        try {
            const a = await mcAsset(String(j.url), keyHex);
            console.log('[牛牛视频] ' + '[短剧] 索引预热 ' + a.buildMs + 'ms tot=' + a.outSize);
        } catch (e) {
            console.log('[牛牛视频] ' + '[短剧] 索引预热失败（代理内会用异步链路重试）：' + (e && e.message ? e.message : e));
        }
    } else if (!cat && typeof netStreamBody === 'function') {
        try {
            const a = await mcAsset(String(j.url), keyHex);
            console.log('[牛牛视频] ' + '[短剧] 索引预热(stream) ' + a.buildMs + 'ms tot=' + a.outSize);
        } catch (e) {
            console.log('[牛牛视频] ' + '[短剧] 索引预热失败（代理内会用异步链路重试）：' + (e && e.message ? e.message : e));
        }
    }
    return { url: await proxyUrlFor(payload), headers: headers };
}

// 通用解析站（parser 里未在 src1/src2/src10 特判的 player_id）
async function srcGeneric(playFrom, rawUrl) {
    let parser = null;
    for (let i = 0; i < C.parser.length; i++) {
        if (String(C.parser[i].player_id) === playFrom) { parser = C.parser[i]; break; }
    }
    if (!parser) { console.log('[牛牛视频] ' + '[解析] ' + playFrom + ' 未在 parser 中收录'); return null; }
    let headers = kvList(parser.headers);
    if (!Object.keys(headers).length) headers = ph();
    const rules = parser.no_parse_rule ? String(parser.no_parse_rule).split(',') : [];
    for (let i = 0; i < rules.length; i++) {
        if (rules[i] && rawUrl.indexOf(rules[i]) > -1) return { url: rawUrl, headers: headers };
    }
    if (!parser.url) { console.log('[牛牛视频] ' + '[解析] ' + playFrom + ' 无解析接口'); return { url: '', headers: headers }; }
    try {
        const r = await req(String(parser.url).replace('%s', rawUrl.replace(/@/g, '%40')), { headers: await hdr(), timeout: 15000 });
        const j = toJson(r && r.content ? r.content : '');
        console.log('[牛牛视频] ' + '[解析] ' + playFrom + ' code=' + (r && r.code) + ' url=' + String((j || {}).url || '').slice(0, 100));
        if (!j) return { url: '', headers: headers };
        if (typeof j.headers === 'string' && j.headers) headers = hdrTextToObj(j.headers);
        return { url: String(j.url || ''), headers: headers };
    } catch (e) { console.log('[牛牛视频] ' + '[解析] ' + playFrom + ' 请求异常：' + e); return { url: '', headers: headers }; }
}

// 臻享线路（src10 / player_id=shizi）：APK 1.6.3 的三步解析链（com.sexy.goddess.play.parse.c）
//   ★ 请求方法（Retrofit 接口 u3.c：@f=GET / @o=POST / @m7.a=@Body）：
//     ① GET  firstUrl(yUrl) + 原地址                      → {type,get,url,headers,body}
//     ② get=="1" ? GET url : POST url(body)（c.r）        → 远端文本，再用 qSubstr/hSubstr 裁剪（c.z）
//     ③ POST secondUrl(eUrl) b64(JSON{nndata,nnid})（c.t）→ {code,type,url,headers}（code 必须 "200"）
//     ④ type=m3u8 时 GET url 取文本（c.v）；文本里含 ".m3u8" 行 ⇒ 换掉 url 最后一段再取一次（c.f）
//     ⑤ POST thirdUrl(sUrl)  b64(JSON{nndata,nnid,nndz})（c.w）→ {code,type,url,headers}
//   ★ 请求体形态由 Retrofit converter 顺序决定：Scalars(l7.k) 先于 Gson(k7.a) ⇒ String 走 l7.a，
//     即 MediaType "text/plain; charset=UTF-8" 的**裸字符串**（不是 JSON、不是表单）。
//   ★ nnid 是「原地址」本身（APK c.t/c.w：put("nnid", str)，str 就是 c.q 的入参原地址），不是视频 id。
//   ★ 旧实现把 eUrl/sUrl 当 GET 拼 id（…/jx2.php<id>）⇒ 服务端 404，即真机「源异常请求 404」的根因。
//     2026-10-30 实测：GET jx2.php7330@4@3996794 → 404；POST jx2.php + b64 体 → 200 JSON（业务 code 另说）。
async function src10(videoUrl) {
    const conf = C.src.src10 || {};
    const headers = ph();
    const ua = { 'User-Agent': HDR['User-Agent'] || 'okhttp/3.12.1' };
    const orig = String(videoUrl == null ? '' : videoUrl);
    const dflt = String(conf.mMp4 || '');            // APK: Src2.defaultUrl（mMp4）
    // APK 语义：三步链任何一步失败 ⇒ 交出 defaultUrl（提示片），不是「播放失败弹窗」
    // ★ 服务端头按 APP 语义是小写键；壳子默认头是 'User-Agent' ⇒ 直接赋值会留下两个 UA 键
    //   （OkHttp 会真发出两行 User-Agent）⇒ 写入前先按小写删掉同名旧键
    function merge(s) {
        const hv = nnHdrMap(s);
        for (const k in hv) {
            for (const kk in headers) { if (String(kk).toLowerCase() === k) delete headers[kk]; }
            headers[k] = hv[k];
        }
    }
    // 臻享 m3u8 分片是「真 PNG + 尾部加密 TS」，靠 #EXT-X-BYTERANGE 定位区间：
    //   猫影视播放器不认 byterange（把整张 png 当图片渲染）⇒ 必须走本地代理逐段取区间 + AES 解密；
    //   其余壳（fongmi / TVBox / 影图 等走 ExoPlayer）原生支持 byterange + #EXT-X-KEY ⇒ 原样交出去，不做任何处理。
    async function out(j) {
        merge(j.headers);
        const t = String(j.type || '').toLowerCase();
        if (t === 'm3u8' && cat) {
            return { url: await proxyUrlFor('M3U8-' + b64uEnc(JSON.stringify({ l: 'shizi', u: String(j.url) }))), headers: headers };
        }
        return { url: String(j.url || ''), headers: headers };
    }

    // APK c.q：原地址为空 ⇒ 直接 defaultUrl
    if (!orig) { console.log('[牛牛视频] ' + '[臻享] ' + ('原地址为空') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
    if (!conf.yUrl) { console.log('[牛牛视频] ' + '[臻享] ' + ('yUrl 为空') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }

    // ① 第一步配置接口（GET，APK c.q → u3.c.a）
    let j1 = null;
    try {
        // ★ 猫影视 open 的 req 对含 @ 的 URL 解析失败（@ 被当 userinfo 分隔符，code=undefined），
        //   必须编码成 %40（服务端 PHP 自动解码，语义不变）；POST body 里的 nnid 用未编码的原值。
        const r = await req(String(conf.yUrl) + orig.replace(/@/g, '%40'), { headers: ua, timeout: 15000 });
        j1 = toJson(r && r.content ? r.content : '');
        console.log('[牛牛视频] ' + '[臻享] ① GET code=' + (r && r.code) + ' type=' + String((j1 || {}).type || '(空)')
            + ' get=' + String((j1 || {}).get || '(空)') + ' url=' + String((j1 || {}).url || '').slice(0, 100));
    } catch (e) { { console.log('[牛牛视频] ' + '[臻享] ' + ('① 请求异常：' + e) + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; } }
    if (!j1) { console.log('[牛牛视频] ' + '[臻享] ' + ('① 返回为空') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
    // APK Src2RespFirstModel.isForPlay()：type equalsIgnoreCase m3u8|mp4 ⇒ 直接播，不再走远端链。
    //   type=mp4 是普通签名直链（任何壳都不解密）；type=m3u8 才是臻享 PNG+TS 形态（猫影视才需代理）。
    const t1 = String(j1.type || '').toLowerCase();
    if (t1 === 'm3u8' || t1 === 'mp4') return await out(j1);

    // ② 第一步远端（APK c.r）：get=="1" ⇒ GET，否则 POST body（Content-Type 同 ③/⑤）
    const h1 = Object.assign({}, ua, nnHdrMap(j1.headers));
    let content = null;
    try {
        if (String(j1.get) === '1') {
            const r = await req(String(j1.url || ''), { headers: h1, timeout: 20000 });
            content = r && r.content != null ? String(r.content) : null;
            console.log('[牛牛视频] ' + '[臻享] ② 远端 GET code=' + (r && r.code) + ' len=' + (content == null ? -1 : content.length));
        } else {
            const r = await postRaw(String(j1.url || ''), String(j1.body || ''), h1);
            content = r && r.content != null ? String(r.content) : null;
            console.log('[牛牛视频] ' + '[臻享] ② 远端 POST code=' + (r && r.code) + ' len=' + (content == null ? -1 : content.length));
        }
    } catch (e) { { console.log('[牛牛视频] ' + '[臻享] ' + ('② 远端异常：' + e) + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; } }
    if (content == null) { console.log('[牛牛视频] ' + '[臻享] ' + ('② 远端无内容') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
    // APK c.z：qSubstr/hSubstr 都非空才裁剪；任一找不到 ⇒ null ⇒ defaultUrl
    const fore = String(conf.qSubstr || ''), tail = String(conf.hSubstr || '');
    if (fore && tail) {
        const i = content.indexOf(fore);
        if (i < 0) { console.log('[牛牛视频] ' + '[臻享] ' + ('② 裁剪找不到 qSubstr') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
        const sub = content.slice(i + fore.length);
        const k = sub.indexOf(tail);
        if (k < 0) { console.log('[牛牛视频] ' + '[臻享] ' + ('② 裁剪找不到 hSubstr') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
        content = sub.slice(0, k);
        console.log('[牛牛视频] ' + '[臻享] ② 裁剪后 len=' + content.length);
    }

    // ③ 第二步配置（POST eUrl，APK c.t）：body = b64(JSON{nndata, nnid})
    if (!conf.eUrl) { console.log('[牛牛视频] ' + '[臻享] ' + ('③ eUrl 为空') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
    let j2 = null;
    try {
        const r = await postRaw(String(conf.eUrl), b64Enc(JSON.stringify({ nndata: content, nnid: orig })), ua);
        j2 = toJson(r && r.content ? r.content : '');
        console.log('[牛牛视频] ' + '[臻享] ③ POST eUrl http=' + (r && r.code) + ' code=' + String((j2 || {}).code || '(空)')
            + ' type=' + String((j2 || {}).type || '(空)') + ' url=' + String((j2 || {}).url || '').slice(0, 100));
    } catch (e) { { console.log('[牛牛视频] ' + '[臻享] ' + ('③ 请求异常：' + e) + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; } }
    if (!j2) { console.log('[牛牛视频] ' + '[臻享] ' + ('③ 返回非 JSON') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
    if (String(j2.code) !== '200') { console.log('[牛牛视频] ' + '[臻享] ' + ('③ 业务 code=' + j2.code + ' msg=' + String(j2.msg || '')) + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }

    // ④ 第二步远端（APK c.v + c.f）：type=m3u8 才取文本；命中子 m3u8 行则换 url 最后一段再取一次
    let step2Url = String(j2.url || '');
    let nndata = step2Url;
    const isM3u8 = String(j2.type || '').toLowerCase() === 'm3u8';
    if (isM3u8) {
        const h2 = Object.assign({}, ua, nnHdrMap(j2.headers));
        for (let round = 0; round < 2; round++) {
            let txt = null;
            try {
                const r = await req(step2Url, { headers: h2, timeout: 20000 });
                txt = r && r.content != null ? String(r.content) : null;
                console.log('[牛牛视频] ' + '[臻享] ④ 远端 GET 第' + (round + 1) + '次 http=' + (r && r.code)
                    + ' len=' + (txt == null ? -1 : txt.length));
            } catch (e) { { console.log('[牛牛视频] ' + '[臻享] ' + ('④ 远端异常：' + e) + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; } }
            if (txt == null) { console.log('[牛牛视频] ' + '[臻享] ' + ('④ 远端无内容') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
            nndata = txt;
            if (round > 0) break;                    // 第二次（isFirst=false）取完直接进第三步
            const line = txt.replace(/\r/g, '').split('\n').filter(function (x) { return x.indexOf('.m3u8') > -1; })[0] || '';
            if (!line) break;                        // 未命中子 m3u8 ⇒ 直接进第三步
            const noQ = step2Url.indexOf('?') > 0 ? step2Url.slice(0, step2Url.indexOf('?')) : step2Url;
            step2Url = step2Url.replace(noQ.slice(noQ.lastIndexOf('/') + 1), line);
            console.log('[牛牛视频] ' + '[臻享] ④ 命中子 m3u8 ' + line.slice(0, 80) + ' → ' + step2Url.slice(0, 120));
        }
    }

    // ⑤ 第三步配置（POST sUrl，APK c.w）：body = b64(JSON{nndata, nnid, nndz})，nndz = isM3u8 ? step2Url : nndata
    if (!conf.sUrl) { console.log('[牛牛视频] ' + '[臻享] ' + ('⑤ sUrl 为空') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
    let j3 = null;
    try {
        const r = await postRaw(String(conf.sUrl), b64Enc(JSON.stringify({
            nndata: nndata, nnid: orig, nndz: isM3u8 ? step2Url : nndata
        })), ua);
        j3 = toJson(r && r.content ? r.content : '');
        console.log('[牛牛视频] ' + '[臻享] ⑤ POST sUrl http=' + (r && r.code) + ' code=' + String((j3 || {}).code || '(空)')
            + ' type=' + String((j3 || {}).type || '(空)') + ' url=' + String((j3 || {}).url || '').slice(0, 120));
    } catch (e) { { console.log('[牛牛视频] ' + '[臻享] ' + ('⑤ 请求异常：' + e) + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; } }
    if (!j3) { console.log('[牛牛视频] ' + '[臻享] ' + ('⑤ 返回非 JSON') + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
    if (String(j3.code) !== '200') { console.log('[牛牛视频] ' + '[臻享] ' + ('⑤ 业务 code=' + j3.code + ' msg=' + String(j3.msg || '')) + ' → defaultUrl=' + (dflt || '(空)')); return { url: dflt, headers: headers }; }
    return await out(j3);
}

// 小草线路（src7 / player_id=xiaocao·xm3u8）
async function src1(playFrom, videoUrl) {
    const playerHeaders = kvList((C.src.src7 || {}).playerHeaders);
    const fail = { url: '', headers: playerHeaders };
    if (videoUrl.indexOf('@') < 0) return fail;
    const at = videoUrl.indexOf('@');
    const videoId = videoUrl.slice(0, at), collection = videoUrl.slice(at + 1);
    const conf = C.src.src7 || {};
    if (!conf.tokenUrl) return fail;
    let deviceId = await devId('xiaocao');
    const mainHeader = kvList(conf.headers);
    const st = C.st.src7;

    function signed(token) {
        const curTime = ms();
        const h = Object.assign({}, mainHeader, {
            'sys_platform': '2',
            'device_id': deviceId,
            'sign': md5(String(conf.salt || '') + deviceId + curTime).toUpperCase(),
            'cur_time': curTime,
            'mobmodel': 'xiaomi',
            'mob_mfr': 'xiaomi',
            'token': token || '',
            'log-header': 'I am the log request header.'
        });
        return { h: h, t: curTime };
    }

    // ---- 以下 1)~5) 整体放进重试循环：命中服务端风控就换设备号重来 ----
    // ★ 风控判据（jadx 实证 SummaryPageMvpPresenter / SpoonMvpPresenter）：
    //   result_v2 / collection_v2 响应的 result 里 vid=1 → 需人机验证（下发 check_page_url，
    //   APP 弹 WebView 过阿里云滑块，回调 SlideVerifyJsInterface 回传 session_id/sig/nc_token
    //   再重试）；vid=2 → 另一档受限。源内无法完成滑块。
    // ★ 正解是 4) 的 pos4 播放页广告上报（绑本片本集，取流前必须发）—— 发了服务端就不判违规。
    //   下面的换号重试只是**兜底**：万一服务端仍标记（例如出口 IP 额度耗尽、ad_id 轮换不同步），
    //   换枚新设备号即可恢复，用户侧无感（不换线路、不弹提示）。
    const MAX_TRY = 3;
    let lastResp = null;
    for (let attempt = 1; attempt <= MAX_TRY; attempt++) {
        // 1) init_v2 取 token —— 每轮重新取（token 与设备号绑定，换号后必须换 token）
        //    ★★ 与 APP 的已知差异（**有意保留**，别照 APP 改）：
        //      jadx 实证 —— APP 换集**不**请求 init_v2：
        //        · 唯一入口 = AppViewModel.T(String,boolean) ← AppRepository.g（只有这 1 个调用者）
        //        · T() 的调用者只有 6 个：SplashStartMvpActivity / PrimaryMainMvpPresenter /
        //          SummaryPageActivity.t / CreateAccountContentMvpPresenter / SignRegistMvpPresenter /
        //          SpoonMvpActivity —— **没有任何播放器类**；
        //        · SummaryPageActivity.t 由 BaseMvpActivity.onCreate 调用一次，内部还是条件触发
        //          `if (w75.c(uu5.k0())) AppViewModel.T("", false)`（≈ 没有 token 才拉）。
        //      ⇒ init_v2 是会话级引导（token + ad_view_time / show_ad_time / today_view_ad 阈值），
        //        不是取流前置；换集不重建 Activity ⇒ APP 不请求。
        //      但 live A/B（2026-10-31，同片连看 3 集 / 每轮现场随机设备号 / 每轮间隔 100s 冷却）：
        //        每轮 init_v2（本实现）：6 次换集中 1 次首尝试命中风控
        //        复用 token（照 APP）  ：8 次换集中 4 次首尝试命中风控
        //      ⇒ 跳过 init_v2 后风控率明显升高（样本小，但方向一致），代价是每次换集都要
        //        换设备号重试（设备号是稀缺资源，测试期会被封）。故保留每轮 init_v2。
        {
            const s0 = signed('');
            const r = await postForm(conf.tokenUrl, { invited_by: '', is_install: '1' }, s0.h);
            const data = toJson(aesCbcDec(r && r.content ? r.content : '', conf.key, conf.iv));
            const info = (data && data.result) || {};
            harvestCdnHosts(info, conf.replaceEncryptDomain || '');
            const tk = String((info.user_info || {}).token || '');
            if (tk) st.token = tk;
        }

        // 1.5) 广告位配置（ad_id/ad_source_id 由服务端下发且会轮换，禁止硬编码）
        //      APP 实测：/api/new_ad/get_list_v2 空 body，返回 ad_position_N → {ad_id, ad_source_id}
        if (!st.ads || !st.adsAt || (ms() - st.adsAt) > 600000) {
            const sA = signed(st.token);
            const ra = await postForm(conf.adListUrl || adFallback(conf, '/api/new_ad/get_list_v2'), {}, sA.h);
            const da = toJson(aesCbcDec(ra && ra.content ? ra.content : '', conf.key, conf.iv));
            const slots = adSlots(da && da.result);
            if (slots) { st.ads = slots; st.adsAt = ms(); }
            console.log('[牛牛视频] ' + '[小草] 广告位 ' + Object.keys(st.ads || {}).length + ' 个');
        }

        // 2) 广告上报 ①（列表页 pos2）—— ★ 同一设备号只发一次
        //    实证（tests/xc_pos4_probe.mjs W/W2 组，间隔 9~15s 连播）：
        //      每轮重取 token 且**不再**发 pos2 → 3/3 ✅（两次复现）
        //      每轮重取 token 且每轮重发 pos2   → 第 2 次 vid=1 🔒
        //      不重取 token 且不再发 pos2       → 第 2 次 vid=1 🔒
        //      不重取 token 但每轮都发 pos2     → 3/3 ✅
        //    ⇒ pos2 与「当前会话」是一次性配对：换 token 后重发 pos2 会被服务端判为
        //      「重新进入列表页」，把已记账的播放额度清掉。源每轮 play 都会重取 token，
        //      故 pos2 只能随首次发一次；后续额度靠 pos4 三条维持。
        //   ★ 标记必须落 local（按设备号）：猫影视 QuickJS 每次生命周期调用可能重建上下文，
        //     内存标记会丢 ⇒ 又变成每轮重发 ⇒ 回到被标记的老路。
        const s1 = signed(st.token);
        let adDone = '';
        try { adDone = String((await local.get(C.ns, 'list_ad_done')) || ''); } catch (e) { }
        if (!st.listAdDone && adDone !== deviceId) {
            await reportAd('src7', s1.h, 'list');
            st.listAdDone = true;
            try { await local.set(C.ns, 'list_ad_done', deviceId); } catch (e) { }
        }

        // 3) result_v2 取线路列表
        // ★ 配对（vod_token + cur_time）早期判定为「一次性」：collection_v2 消费后即失效，
        //   复用旧配对必被判违规回 19s 防盗片（实测：同设备第 2 次播放复用 7s 前配对 → 直接防盗）。
        //   该结论后来被下面的「配对缓存」修正：**同一播放会话内可跨集复用整份列表**，
        //   前提是换集不再重复 result_v2（见下）。跨会话/跨片仍一律重新取。
        // ★ 参数逐字对齐 APP（jadx 实证 SummaryPageMvpPresenter.J0 / SpoonMvpPresenter.g0）：
        //   仅 vod_id / session_id / sig / nc_token / phone / code（+ 5% 概率的 vi），
        //   **不带 cur_time 表单字段**（时间只走请求头，参与 sign）。
        let vc = null, meta = null;
        // ★★ 配对缓存：APP 换集**不重新 result_v2**（2026-10-31 复核：
        //    con 85/173/1689/… 那批「init_v2 → pos4×3 → collection_v2」簇后来被证伪 ——
        //    其中 init_v2 的 body 是 `invited_by=&is_install=1`（24B，无 ua），而 APP 的
        //    AppViewModel.T 恒定 put("ua", uu5.getIsUA())（conn 75 那条 187B 才是 APP 的）；
        //    即那批簇是**源自己**的流量，不能当作 APP 证据。
        //    真正的依据是地瓜视频抓包（短期换集只有 collection_v2 + get_list_v2，无广告无 init）；
        //    ⇒ 「配对」不是一次性的，而是**一次播放会话内整份列表可跨集复用**。
        //    源早先每轮 play 都重新 result_v2，正是「隔一会儿换集就 vid=1」的真因：
        //    result_v2 在冷却期外要求本片本集已有广告记录，而广告是在它之后才发的，
        //    APP 根本不走这条路。
        const cached = await vcCacheGet(videoId);
        if (cached) {
            vc = cached;
            console.log('[牛牛视频] ' + '[小草] 配对缓存命中 ' + vc.length + ' 集，按 APP 逻辑跳过 result_v2');
        } else {
            const r = await postForm(conf.listUrl, {
                sig: '', nc_token: '', code: '', phone: '',
                vod_id: videoId, session_id: ''
            }, s1.h);
            const data = toJson(aesCbcDec(r && r.content ? r.content : '', conf.key, conf.iv));
            meta = (data && data.result) || null;
            vc = (meta && meta.vod_collection) || null;
            console.log('[牛牛视频] ' + '[小草] result_v2 code=' + (r && r.code) + ' bodyLen=' + String((r && r.content) || '').length
                + ' 线路数=' + (vc ? vc.length : 0) + ' vid=' + String((meta && meta.vid) || ''));
            if (!vc) { st.token = ''; console.log('[牛牛视频] ' + '[小草] result_v2 未下发线路'); return lastResp || fail; }
            await vcCacheSet(videoId, vc);
        }

        // 结果级风控：vid=1/2 或直接下发 check_page_url ⇒ 换号重试
        if (meta && (Number(meta.vid) === 1 || Number(meta.vid) === 2 || meta.check_page_url)) {
            lastResp = { url: String(meta.check_page_url || ''), headers: playerHeaders };
            if (attempt < MAX_TRY) {
                console.log('[牛牛视频] ' + '[小草] 结果级风控 vid=' + String(meta.vid || '') + ' → 换设备号重试 ' + attempt + '/' + MAX_TRY);
                await vcCacheDel(videoId);
                deviceId = await switchDev('xiaocao');
                st.token = '';
                continue;
            }
        }

        let collectionId = '', vodToken = '', collectionCurTime = '';
        for (let i = 0; i < vc.length; i++) {
            if (String(vc[i].collection) === collection) {
                collectionId = String(vc[i].id);
                vodToken = String(vc[i].vod_token || '');
                collectionCurTime = String(vc[i].cur_time == null ? '' : vc[i].cur_time);
                break;
            }
        }
        if (!collectionId || !vodToken) { st.token = ''; return lastResp || fail; }

        // 4) 广告上报 ②（取播放地址前）：播放页 pos4，必须绑「本片 + 本集号」
        //    ★ 这是「第 2 次弹人机验证」的唯一开关（见 reportAd 上方对照实验）
        //    ★ 但受 interval_time 冷却约束：APP 60 秒内换集不会再播广告（APK 实证 m2），
        //      冷却期内 reportAd 直接返回，不产生任何 ad_v2 请求。
        const s2 = signed(st.token);
        await reportAd('src7', s2.h, 'play', { vodId: videoId, collection: collection, dev: deviceId });

        // 5) collection_v2 取播放地址
        const r2 = await postForm(conf.detailUrl, {
            collection_id: collectionId, sig: '', nc_token: '', code: '', phone: '',
            vod_id: videoId, session_id: '', vod_token: vodToken, cur_time: collectionCurTime
        }, s2.h);
        const result = ((toJson(aesCbcDec(r2 && r2.content ? r2.content : '', conf.key, conf.iv)) || {}).result) || {};
        const checkUrl = result.check_page_url || result.check_url;
        const guardUrl = /ydsp\.skzsz|\/xl01\/|check_v2/i.test(String(result.vod_url || ''));
        console.log('[牛牛视频] ' + '[小草] collection_v2 code=' + (r2 && r2.code) + ' vod_url=' + String(result.vod_url || '').slice(0, 100)
            + ' check=' + String(checkUrl || ''));

        if (checkUrl || guardUrl) {
            // 服务端未放行：记下最后一次响应，换号重试
            lastResp = checkUrl ? { url: String(checkUrl), headers: playerHeaders } : lastResp;
            if (attempt < MAX_TRY) {
                console.log('[牛牛视频] ' + '[小草] 取流命中风控 → 换设备号重试 ' + attempt + '/' + MAX_TRY);
                await vcCacheDel(videoId);
                deviceId = await switchDev('xiaocao');
                st.token = '';
                await new Promise(function (res) { setTimeout(res, 1200); });
                continue;
            }
            // 重试用尽：照实回传（不审查、不兜底）
            return lastResp || fail;
        }
        if (!result.vod_url) { await vcCacheDel(videoId); st.token = ''; return lastResp || fail; }
        const ck = b64Decode(result.ck);
        const rep = String(conf.replaceDomain || '').replace(/\/+$/, '');
        const playUrl = rep ? (rep + pathOf(result.vod_url)) : String(result.vod_url);
        const payload = 'M3U8-' + b64uEnc(JSON.stringify({
            l: playFrom, s: String(conf.replaceEncryptDomain || ''), u: playUrl + '?' + ck
        }));
        return { url: await proxyUrlFor(payload), headers: playerHeaders };
    }
    return lastResp || fail;
}

// 河马线路（src2 / player_id=hema）
async function src2(videoUrl) {
    const conf = C.src.src2 || {};
    const playerHeaders = kvList(conf.playerHeaders);
    const fail = { url: '', headers: playerHeaders };
    if (videoUrl.indexOf('@') < 0) return fail;
    if (!conf.listUrl) return fail;
    const at = videoUrl.indexOf('@');
    const videoId = videoUrl.slice(0, at), collection = videoUrl.slice(at + 1);
    const mainHeader = kvList(conf.headers);
    const st = C.st.src2;
    const deviceId = await devId('hema');

    function base(extra) {
        return Object.assign({}, mainHeader, {
            'Device-Id': deviceId,
            'Cur-Time': ms(),
            'Mob-Mfr': 'xiaomi',
            'Mob-Model': 'xiaomi',
            'token': '',
            'timestamp': ms()
        }, extra || {});
    }

    // 1) 广告/注册接口取 token（成功一次即缓存）
    if (!st.token) {
        const h0 = base({});
        const r = await postRaw(conf.adUrl, conf.adBody || '', h0);
        const j = toJson(r && r.content ? r.content : '');
        const data = toJson(des3Dec(j && j.data ? j.data : '', conf.key, conf.iv));
        const result = (data && data.result) || {};
        harvestCdnHosts(result, conf.replaceEncryptDomain || '');
        st.token = String((result.user_info || {}).token || '');
    }

    const listHeader = base({ token: st.token, 'Cur-Time': ms(), timestamp: ms() });
    // 2) 广告上报（过风控）：取列表前先上报一次
    await reportAd('src2', listHeader);

    // 3) 取线路列表
    let mapList = st.map_list[videoId];
    if (!mapList) {
        const r = await postForm(conf.listUrl, { vod_id: videoId }, listHeader);
        const j = toJson(r && r.content ? r.content : '');
        const data = toJson(des3Dec(j && j.data ? j.data : '', conf.key, conf.iv));
        mapList = (data && data.result && data.result.map_list) || null;
        if (!mapList) return fail;
        st.map_list[videoId] = mapList;
    }
    let vodMapId = '';
    for (let i = 0; i < mapList.length; i++) {
        if (String(mapList[i].collection) === collection) { vodMapId = String(mapList[i].id); break; }
    }
    if (!vodMapId) return fail;

    // 4) 广告上报（再报一次）：取播放地址前必须上报，否则服务端下发防盗视频
    const detailHeader = base({ token: st.token, 'Cur-Time': ms(), timestamp: ms() });
    await reportAd('src2', detailHeader);

    // 5) 取播放地址
    const r2 = await postForm(conf.detailUrl, {
        xz: '0', vod_map_id: vodMapId, vod_id: videoId, collection: collection
    }, detailHeader);
    const j2 = toJson(r2 && r2.content ? r2.content : '');
    const result = ((toJson(des3Dec(j2 && j2.data ? j2.data : '', conf.key, conf.iv)) || {}).result) || {};
    const checkUrl = result.check_url || result.check_page_url;
    if (checkUrl) return { url: String(checkUrl), headers: playerHeaders };
    if (!result.vod_url) return fail;
    const ck = b64Decode(result.ck);
    const rep = String(conf.replaceDomain || '').replace(/\/+$/, '');
    const playUrl = rep ? (rep + pathOf(result.vod_url)) : String(result.vod_url);
    const payload = 'M3U8-' + b64uEnc(JSON.stringify({
        l: 'hema', s: String(conf.replaceEncryptDomain || ''), u: playUrl + '?' + ck
    }));
    return { url: await proxyUrlFor(payload), headers: playerHeaders };
}

// 广告上报（过风控）。src2 → 裸串 text/plain；src7 → 表单。返回值无用，异常静默。
// 广告位映射：result 里的 ad_position_N 数组 → { N: {id, src} }
function adSlots(result) {
    if (!result || typeof result !== 'object') return null;
    const out = {};
    for (const k in result) {
        const m = /^ad_position_(\d+)$/.exec(k);
        if (!m) continue;
        const it = (result[k] || [])[0];
        if (!it) continue;
        out[m[1]] = {
            id: String(it.ad_id == null ? '' : it.ad_id),
            src: String(it.ad_source_id == null ? '' : it.ad_source_id),
            // ★ interval_time：该广告位的「展示冷却」（秒），服务端实时下发且会改。
            //   实测 2026-10-31：pos4=60、pos9=300、pos1=300、pos2/5/8/12=0。
            interval: Number(it.interval_time == null ? 0 : it.interval_time) || 0
        };
    }
    return Object.keys(out).length ? out : null;
}

// ---------------- result_v2 配对缓存（跨集复用，APP 同构） ----------------
//   APP 实证：同一部片连续换集只 result_v2 一次，后续每集直接用列表里各自的
//   vod_token + 同一个 cur_time 取流（抓包 6 集 cur_time 全等于 1793375569）。
//   落 local 而不是内存：猫影视 QuickJS 每次生命周期调用可能重建上下文。
const VC_TTL = 1800000;   // 30 分钟：超过视为新播放会话，重新 result_v2
async function vcCacheGet(vodId) {
    try {
        const raw = String((await local.get(C.ns, 'vc_' + vodId)) || '');
        if (!raw) return null;
        const j = JSON.parse(raw);
        if (!j || !j.t || !j.l || !j.l.length) return null;
        if (Number(ms()) - Number(j.t) > VC_TTL) return null;
        return j.l.map(function (a) {
            return {
                id: a[0], vod_token: a[1],
                cur_time: a[2], collection: a[3]
            };
        });
    } catch (e) { return null; }
}
async function vcCacheSet(vodId, list) {
    try {
        const l = (list || []).map(function (x) {
            return [
                String(x.id == null ? '' : x.id),
                String(x.vod_token == null ? '' : x.vod_token),
                String(x.cur_time == null ? '' : x.cur_time),
                String(x.collection == null ? '' : x.collection)
            ];
        });
        await local.set(C.ns, 'vc_' + vodId, JSON.stringify({ t: Number(ms()), l: l }));
    } catch (e) { }
}
async function vcCacheDel(vodId) {
    try { await local.set(C.ns, 'vc_' + vodId, ''); } catch (e) { }
}

// ★★ 广告上报（过风控）：ad_id/ad_source_id 必须用服务端当次下发值，序列与 APP 完全一致。
//   APP 抓包（2026-10-30，reqable conn26 一次完整播放）三步：
//     列表页 pos2：log_type=4 → log_type=2（vod_id=0, collection=0）
//     播放页 pos4：log_type=4 → log_type=2 → log_type=1（**vod_id=<本片>, collection=<本集号>**，
//                  第三条 is_success=0 —— APP 原值，表示广告结束/跳过）
//     详情页 pos8：log_type=2 / 4（vod_id=0, collection=0，取流之后）
//   ★★ 真正决定「第 2 次会不会弹人机验证」的是 **pos4**，必须绑片绑集、必须在取流前、必须三条齐全：
//     纯 API 对照（tests/xc_pos4_probe.mjs，每组新设备号，间隔 20s 复播）：
//       取流前只发 pos2（旧实现）              → 复播 result_v2 vid=1 🔒
//       取流前 pos4 只发 4+2（两条）           → 间隔 3s 内侥幸过，8s/15s 后必 🔒
//       取流前 pos4 发 4+2+1，is_success=1     → 🔒（声称播完但时长不足，判作弊）
//       取流前 pos4 发 4+2+1，is_success=0     → 间隔 20s 连播 3 次全 ✅（连做两轮）
//       取流后 23s 补 pos4（APP 时序）         → 🔒（事后补无效，必须在 collection_v2 之前）
//       连续 5 次 result_v2 不取流             → 全部正常（⇒ 触发器是 collection_v2 取流本身）
//   ⇒ 服务端在 collection_v2 校验「本片本集是否有 pos4 的 4/2/1 完整记录（且 1 的 is_success=0）」，
//     没有就记一次"未看广告"，下次 result_v2 直接下发 vid=1 + 19 秒防盗占位。
//   ★ 「间隔 3 秒内复播能过」是假象：短窗口内服务端视为同一次播放不记账，与 pos4 无关。
//   历史坑：硬编码 ad_id=4927&ad_source_id=5&ad_position=9 在首次播放能过
//   （服务端对新设备有免费额度 new_user_has_ad），第二次起必判违规。
//
// ★★★ 广告频率闸门（2026-10-31 APK 反编译实证，source of truth：
//      com.tank.lh.mvp.detail.SummaryPageActivity#m2）：
//        if ((z3 && entry.getNew_user_has_ad() != 1) || uu5.V() != 1
//            || us.x(uu5.m(), entry.getInterval_time())) { l3(); return; }   // 不播广告、不上报
//      - `us.x(lastShow, interval)` = `|now - lastShow| / 1000 <= interval`（**秒**）
//      - `uu5.m()` = SP `KEY_PREF_AD_PLAY_SHOW_THREE`，只存「最后一次播放页广告展示时间」，
//        **不分片不分集** ⇒ 冷却期内的换集/重播一律不再播广告、不再上报 ad_v2
//        （写入点：com.fnmobi.sdk.library.yb$p#c()，pos4 曝光回调里 uu5.G0(now)）。
//      - interval 来自服务端 get_list_v2 的 ad_position_4[].interval_time，实测 pos4 = **60 秒**。
//      这与抓包一致：174248 首次进播放页（conn2054）报 pos4；16s 后重取同集（conn2284）、
//      81s 后切下一集（conn2480）都**没有** ad_v2 —— 因为 APP 侧根本没走到播广告那一步。
//      ⇒ 源必须同样遵守：冷却期内换集绝不再发 pos4（否则等于 APP 不会做的行为，反被判异常）。
//
// ★★★ 换集绝不上报（2026-10-31 地瓜视频 v50100 抓包实证，app_id=diguashipin，
//      host=u.gslock.com，vod_id=174248，device_id=c53839fa8cf04d81）：
//      00:34:32 collection_v2 (collection_id=4556798)   ← 进播放页，解析第 1 集
//      00:34:54 ad_v2 log_type=3 ad_position=4 collection=1 is_success=1
//      00:35:00 ad_v2 log_type=3 ad_position=4 collection=1 is_success=1
//      00:35:11 ad_v2 log_type=5 ad_position=4 collection=1 is_success=1
//      00:35:15 collection_v2 (同一份 vod_token/cur_time，仅换 collection_id) ← 换第 2 集
//      00:35:15 get_list_v2 collection=2                                  ← 换第 2 集
//      ⇒ **换集整段没有任何 ad_v2**：所有 ad_v2 都绑 collection=1、且都在换集之前；
//        全抓包里 collection=2 的请求只有 get_list_v2 一条，collection=3 一条都没有。
//      ⇒ APP 只在「真的播了一次广告」时上报，一次上报覆盖该片后续换集；换集不重进播放页，
//        根本走不到播广告那一步。
//      ⇒ 「冷却到期(60s)就补报」是错的：81 秒后换集 APP 仍然不报（conn2480 实证），
//        源按冷却补报 = 做了 APP 不会做的事，反被判异常。
async function reportAd(srcType, hdrs, phase, ctx) {
    try {
        const conf = C.src[srcType] || {};
        if (srcType !== 'src2') {
            const adUrl = conf.adUrl || adFallback(conf, '/api/new_log/ad_v2');
            if (!adUrl) return;
            const slots = (C.st[srcType] || {}).ads || {};
            const c = ctx || {};
            // ★★ pos4 闸门（两层，与 APP 同构）：
            //   ① 同片换集：本片已上报过、且集号不同 ⇒ 直接跳过（本次抓包实证，不受冷却影响）
            //   ② 全局冷却：距上次广告展示 <= interval_time ⇒ 跳过（APP 的 us.x(lastShow, interval)）
            //   两条记录都落 local 并绑定设备号（换号=新机，互不干扰）。
            if (phase === 'play') {
                const slot4 = slots['4'] || {};
                const cd = slot4.interval > 0 ? slot4.interval : 60;
                const dev = String(c.dev || '');
                const curVod = String(c.vodId == null ? '' : c.vodId);
                const curCol = String(c.collection == null ? '' : c.collection);
                // 单键存「设备号|时间戳」：换设备号自动失效，也不会在 local 里堆一串 key
                let lastTs = 0, lastVod = '', lastCol = '';
                try {
                    const raw = String((await local.get(C.ns, 'ad4_ts')) || '');
                    const p = raw.split('|');
                    if (p[0] === dev) lastTs = Number(p[1]) || 0;
                } catch (e) { }
                try {
                    const raw2 = String((await local.get(C.ns, 'ad4_vod')) || '');
                    const q = raw2.split('|');
                    if (q[0] === dev) { lastVod = String(q[1] || ''); lastCol = String(q[2] || ''); }
                } catch (e) { }
                if (lastVod && lastVod === curVod && lastCol !== curCol) {
                    console.log('[牛牛视频] ' + '[小草] 同片换集 ' + lastCol + '→' + curCol + '，APP 不重播广告 ⇒ 跳过上报');
                    return;
                }
                const gap = lastTs ? Math.floor((Number(ms()) - lastTs) / 1000) : -1;
                if (lastTs && gap >= 0 && gap <= cd) {
                    console.log('[牛牛视频] ' + '[小草] pos4 冷却中 ' + gap + 's <= ' + cd + 's，按 APP 逻辑跳过广告上报');
                    return;
                }
                console.log('[牛牛视频] ' + '[小草] pos4 冷却已过 ' + (gap < 0 ? '(首次)' : gap + 's') + '，上报广告');
            }
            // list 段：列表页 pos2 两条（4 加载 / 2 曝光，result_v2 之前）
            // play 段：播放页 pos4 **三条**（4 加载 / 2 曝光 / 1 结束，collection_v2 之前）
            const seq = phase === 'play' ? [['4', '4'], ['2', '4'], ['1', '4']] : [['4', '2'], ['2', '2']];
            for (let i = 0; i < seq.length; i++) {
                const lt = seq[i][0], pos = seq[i][1];
                const slot = slots[pos] || { id: '', src: '' };
                const bound = phase === 'play';
                await postForm(adUrl, {
                    log_type: lt, ad_id: slot.id, ad_type: '2', ad_source_id: slot.src,
                    vod_id: bound ? String(c.vodId == null ? '' : c.vodId) : '0',
                    ad_position: pos,
                    collection: bound ? String(c.collection == null ? '' : c.collection) : '0',
                    // ★ 第三条 log_type=1 必须 is_success=0：服务端按广告实际时长核账，
                    //   声称"成功"(=1) 而时长不足反而判作弊 → 下一次 result_v2 直接 vid=1。
                    //   这是 APP 抓包原值（conn26 seq15: log_type=1&ad_position=4&is_success=0）。
                    is_success: lt === '1' ? '0' : '1'
                }, hdrs);
            }
            // 曝光（log_type=2）已发 ⇒ 按 APP 的 yb$p#c() 语义写「最后一次展示时间」，
            //   同时记「本片最后一次上报的集号」，供上面的换集判断用（单键轮换，不堆 key）。
            if (phase === 'play') {
                const dev = String(c.dev || '');
                try { await local.set(C.ns, 'ad4_ts', dev + '|' + Number(ms())); } catch (e) { }
                try {
                    await local.set(C.ns, 'ad4_vod', dev + '|' + String(c.vodId == null ? '' : c.vodId)
                        + '|' + String(c.collection == null ? '' : c.collection));
                } catch (e) { }
            }
            return;
        }
        const adUrl = conf.adsUrl || adFallback(conf, '/api/stats/ads');
        const adBody = conf.adsBody || 'errcode=&count=1&is_click=1&tag_id=7-1-7';
        if (!adUrl || !adBody) return;
        await postRaw(adUrl, adBody, hdrs);
    } catch (e) { }
}
function adFallback(conf, path) {
    const m = String(conf.detailUrl || '').match(/^(https?:\/\/[^/]+)/i);
    return m ? (m[1] + path) : '';
}

// ---------------- 播放 CDN 候选池 ----------------
function harvestCdnHosts(result, salt) {
    try {
        const sc = (result && result.sys_conf) || {};
        if (!sc || typeof sc !== 'object') return C.cdn;
        const found = [];
        if (typeof sc.play_domain === 'string' && sc.play_domain.indexOf('http') === 0) {
            found.push(sc.play_domain.replace(/\/+$/, ''));
        }
        const keys = ['p2p_config', 'p2p_config_str'];
        for (let i = 0; i < keys.length; i++) {
            const raw = sc[keys[i]];
            if (typeof raw !== 'string') continue;
            const re = /sec_domain=(https?:\/\/[^\^]+)/g;
            let m;
            while ((m = re.exec(raw)) !== null) found.push(m[1].replace(/\\\//g, '/').replace(/\/+$/, ''));
        }
        for (let i = 0; i < found.length; i++) {
            let dup = false;
            for (let k = 0; k < C.cdn.length; k++) {
                if (C.cdn[k].host === found[i] && C.cdn[k].salt === (salt || '')) dup = true;
            }
            if (!dup) C.cdn.push({ host: found[i], salt: salt || '' });
        }
    } catch (e) { }
    saveCdnHosts();
    return C.cdn;
}
// 池子落 local：真壳 local.set 同步（wrapper 是 async ⇒ 不 await，失败无妨）。
// 作用：proxy 若处在独立求值上下文（模块级 C 被重置），同步读回池子仍有多 CDN 兜底。
function saveCdnHosts() {
    if (!C.cdn.length) return;
    try {
        const s = JSON.stringify(C.cdn);
        if (s === C.cdnSaved) return;
        C.cdnSaved = s;
        local.set(C.ns, 'cdn_hosts', s);
    } catch (e) { }
}

// 播放 CDN 候选：prefer（replaceDomain）→ origin（播放地址原域名）→ 已采集池 → local 落盘池
// ★ 必须**同步**返回（proxy 同步约束，见 handleM3u8）：真壳的 local.get 是同步阻塞；
//   wrapper 是 async ⇒ 探测到 thenable 直接放弃这一路，不阻塞。
function cdnCandidatesSync(origin, salt, prefer) {
    const cands = [];
    function add(host, s) {
        const h = String(host || '').replace(/\/+$/, '');
        if (!h || !/^https?:\/\//i.test(h)) return;
        for (let k = 0; k < cands.length; k++) if (cands[k].host === h) return;
        cands.push({ host: h, salt: s || '' });
    }
    add(prefer, salt);
    add(origin, salt);
    for (let i = 0; i < C.cdn.length; i++) add(C.cdn[i].host, C.cdn[i].salt);
    if (!C.cdn.length) {
        let raw = '';
        try { raw = local.get(C.ns, 'cdn_hosts'); } catch (e) { }
        if (raw && typeof raw.then !== 'function') {
            try {
                const arr = JSON.parse(String(raw) || '[]');
                for (let i = 0; i < arr.length; i++) {
                    const e = (arr[i] && typeof arr[i] === 'object') ? arr[i] : { host: arr[i], salt: '' };
                    add(e.host, e.salt);
                }
            } catch (e) { }
        }
    }
    const ok = [], bad = [];
    for (let i = 0; i < cands.length; i++) (isDecoyHost(cands[i].host) ? bad : ok).push(cands[i]);
    return ok.concat(bad);
}

function isDecoyHost(host) {
    const h = String(host || '');
    const m = (h.indexOf('://') > -1 ? h : 'http://' + h).match(/^https?:\/\/([^/]+)/i);
    const netloc = m ? m[1].toLowerCase() : '';
    for (let i = 0; i < DECOY.length; i++) if (netloc.indexOf(DECOY[i]) > -1) return true;
    return false;
}

// CDN 播放鉴权：wsSecret = md5(盐 + 播放路径 + wsTime)
function hlsSign(url, salt) {
    const s = String(url || '');
    if (!salt) return s;
    const t = hexTime();
    const data = String(salt) + pathOf(s) + t;
    return s + (s.indexOf('?') > -1 ? '&' : '?') + 'wsSecret=' + md5(data) + '&wsTime=' + t;
}

// ---------------- 本地代理（m3u8 改写 + ts 302 现签） ----------------
const RESP = { json: true };
// ★★ 代理通道只有猫影视系用 js2Proxy，其余壳（fongmi/TVBox/影图…）一律走老数组通道：
//    fongmi 的 js2Proxy 走 Spider.proxy2，只回 {code,contentType,stream}，**丢弃 headers**
//    （Proxy.java 仅 rs.length>3 才 addHeader）⇒ ts 的 302 出去没有 Location；
//    老数组通道（getProxy + ptype/purl → proxy1 的 result[3]=headers）能带 Location。
//    此前按 siteKey 非空就切猫格式，把 fongmi 也带进了 proxy2，正是 302 无 Location 的来源。
function useCatFmt() {
    return cat;                                        // 只认壳身份，不按 siteKey 猜
}
function proxyUrlSync(payload) {
    // ★★ payload 一律 'M3U8-'/'TS-' + base64url，天然 URL 安全 ⇒ **绝不再 encodeURIComponent**
    //   （再编一层会让 proxy1 的 purl 变样，个别壳反解不回；旧 '@' 分隔方案就是在这儿丢前缀的）
    // ★★ 猫格式代理路由 key 必须用 init(cfg) 注入的真实 siteKey（cfg.skey），且「壳子配置 JSON 的 site key 必须纯 ASCII」：
    //   猫影视 quickjs 版的 /jp/<uuid>/<stype>/<site>/<header>/<url> 代理路由按 <site> 段查找站点；
    //   key 含中文时壳子 HTTP 处理器会在回调本源 proxy() 之前直接 500（api-reference.md §212 真机实证），
    //   表象极具迷惑性——play 正常返回代理 URL、URL 也能生成，但所有 /jp/ 请求失败、proxy() 零日志、
    //   播放器「播放出错正在重试」。故两处都须 ASCII：源码侧用 C.siteKey，部署侧 index.json 的 key 也须 ASCII。
    if (useCatFmt()) {
        try { return js2Proxy(false, C.siteType, C.siteKey, payload, {}); } catch (e) { console.log('[牛牛视频] ' + 'js2Proxy 失败：' + e); }
    }
    if (typeof getProxy === 'function') return getProxy(true) + '&ptype=niuniu&purl=' + payload;
    return '';
}
async function proxyUrlFor(payload) { return proxyUrlSync(payload); }

function isProxy1(params) {
    return !!(params && typeof params === 'object' && typeof params.ptype === 'string' && typeof params.purl === 'string');
}
function hasPfx(s) { return s.indexOf('M3U8-') === 0 || s.indexOf('TS-') === 0 || s.indexOf('MP4-') === 0; }
// 逐步解码直到认出前缀（壳子可能已解一层、js2Proxy 在猫影视系还会再编一层）
function unwrap(s) {
    for (let k = 0; k < 3; k++) {
        if (hasPfx(s)) return s;
        let d;
        try { d = decodeURIComponent(s); } catch (e) { break; }
        if (d === s) break;
        s = d;
    }
    return s;
}
function readPayload(params) {
    if (isProxy1(params)) return unwrap(String(params.purl || ''));
    const cands = [];
    if (Array.isArray(params)) {
        cands.push(params.join('/'));
        for (let i = params.length - 1; i >= 0; i--) cands.push(String(params[i] || ''));
    } else if (params && typeof params === 'object') {
        cands.push(String(params.url || params[0] || ''));
    } else {
        cands.push(String(params || ''));
    }
    for (let i = 0; i < cands.length; i++) {
        const s = unwrap(cands[i]);
        if (hasPfx(s)) return s;
    }
    return '';
}
function respText(code, text, ct) {
    if (!RESP.json) return [code, ct, text, { 'Content-Type': ct }, 0];
    return JSON.stringify({ code: code, content: text, headers: { 'Content-Type': ct } });
}
function respErr(code) {
    if (!RESP.json) return [code, 'text/plain', '', {}, 0];
    return JSON.stringify({ code: code, content: '', headers: {} });
}
function thenOf(r, okFn, errFn) {
    if (r && typeof r.then === 'function') return r.then(okFn, errFn || function () { return respErr(500); });
    return okFn(r);
}
// ==== ZH-BEGIN 臻享线路（shizi / src10）PNG 内嵌 TS 解密代理 ====
// 臻享 m3u8 的分片是图片 CDN 上的“真 PNG”（整文件 592KB 级、Content-Type: image/png），真实 TS 经
// AES-128-CBC 加密后追加在 PNG 末尾，区间由 #EXT-X-BYTERANGE 给出（IV = 媒体序列号，0 基；实测
// 首段 80014..592701 解密出 512676B = 2727 个 188B TS 包 + 12B PKCS7 填充）。
// 浏览器 hls.js / exoplayer 按 byterange + key 取区段并解密；猫影视播放器不认 byterange（拉整张
// .png 按图片渲染 → “变图片播放”）。故臻享同样走本地代理：代理侧按 byterange 取 PNG 区段 →
// AES-128-CBC 解密 → 回传明文 TS。重写后的 m3u8 已无 #EXT-X-KEY / #EXT-X-BYTERANGE，播放器按普通
// TS 播（与小草/河马同套代理机制）。二进制回传通道按壳身份分流（央视片库 2026-09-21 真机实证：
// 猫影视吃 {buffer:3, content:JSProxyStream}，给它 base64 JSON 反而会让分片全废）。
function binToU8(bin) {
    if (!bin) return null;
    try {
        if (bin instanceof Uint8Array) return bin;
        if (typeof ArrayBuffer !== 'undefined' && bin instanceof ArrayBuffer) return new Uint8Array(bin);
        if (bin && typeof bin === 'object' && typeof bin.byteLength === 'number') return new Uint8Array(bin);
        if (bin && typeof bin.length === 'number' && bin.length > 0 && typeof bin[0] === 'number') {
            const u = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) u[i] = bin[i] & 0xff;
            return u;
        }
    } catch (e) { }
    return null;
}
function h2n(n) { n = n & 0xff; const s = n.toString(16); return s.length < 2 ? '0' + s : s; }
function bytesToHex(u8) { let s = ''; for (let i = 0; i < u8.length; i++) s += h2n(u8[i]); return s; }
function contentToText(r) {                          // m3u8 / key 全 ASCII，latin1 即正确文本
    const c = r && r.content;
    if (c == null) return '';
    if (typeof c === 'string') return c;
    const u = binToU8(c);
    if (!u) return '';
    let s = '';
    for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
    return s;
}
function u8ToWA(u8) {
    const len = u8.length, words = [];
    for (let i = 0; i < len; i += 4) words.push(((u8[i] || 0) << 24) | ((u8[i + 1] || 0) << 16) | ((u8[i + 2] || 0) << 8) | (u8[i + 3] || 0));
    return Crypto.lib.WordArray.create(words, len);
}
function waToU8(wa) {
    const words = (wa && wa.words) || [];
    const len = (wa && typeof wa.sigBytes === 'number') ? wa.sigBytes : words.length * 4;
    const out = new Uint8Array(len);
    for (let i = 0; i < len; i++) out[i] = ((words[i >> 2] | 0) >>> (24 - (i % 4) * 8)) & 0xff;
    return out;
}
function aesCbcDecBin(u8, keyHex, ivHex) {           // 二进制 key ⇒ 只能走 cat.js 的 CryptoJS（aesX 只收 ASCII key）
    const res = Crypto.AES.decrypt(
        { ciphertext: u8ToWA(u8) },
        Crypto.enc.Hex.parse(keyHex),
        { iv: Crypto.enc.Hex.parse(ivHex), mode: Crypto.mode.CBC, padding: Crypto.pad.Pkcs7 }
    );
    return waToU8(res);
}
function b64FromBytes(u8) {
    try { return Crypto.enc.Base64.stringify(u8ToWA(u8)); } catch (e) { }
    const tbl = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    const parts = [];
    let buf = '', n = 0, i = 0;
    for (; i + 2 < u8.length; i += 3) {
        n = (u8[i] << 16) | (u8[i + 1] << 8) | u8[i + 2];
        buf += tbl[(n >> 18) & 63] + tbl[(n >> 12) & 63] + tbl[(n >> 6) & 63] + tbl[n & 63];
        if (buf.length >= 8192) { parts.push(buf); buf = ''; }
    }
    const rem = u8.length - i;
    if (rem === 1) { n = u8[i] << 16; buf += tbl[(n >> 18) & 63] + tbl[(n >> 12) & 63] + '=='; }
    else if (rem === 2) { n = (u8[i] << 16) | (u8[i + 1] << 8); buf += tbl[(n >> 18) & 63] + tbl[(n >> 12) & 63] + tbl[(n >> 6) & 63] + '='; }
    parts.push(buf);
    return parts.join('');
}
function respBytes(bytes, ct) {                      // 非猫影视通道：猫格式 JSON+buffer:2 base64 / 老数组通道 flag=1
    const b64 = b64FromBytes(bytes);
    if (!RESP.json) return [200, ct, b64, { 'Content-Type': ct }, 1];
    return JSON.stringify({ code: 200, buffer: 2, content: b64, headers: { 'Content-Type': ct } });
}
function dirOf(u) {                                  // 取 URL 所在目录（先剥 query，避免 query 里的 / 干扰）
    const s = String(u || '');
    const q = s.indexOf('?');
    const base = q > -1 ? s.slice(0, q) : s;
    const i = base.lastIndexOf('/');
    return i > 8 ? base.slice(0, i + 1) : '';
}
// 二进制取字节：猫影视走 JSFile 落盘（实证通道，二进制不进 JS 内存的取法）；其余壳 buffer:1 → buffer:2
async function fetchShiziBytes(url, hdrs) {
    if (typeof JSFile === 'function') {
        C.zhSeq = (C.zhSeq || 0) + 1;
        const f = new JSFile('nn_ts/s' + C.zhSeq + '_' + Date.now() + '.bin');
        let got = null;
        try {
            await f.open('w');
            let r = null;
            try { r = await req(url, { headers: hdrs, buffer: 3, stream: f, timeout: [8000, 15000] }); } catch (e) { r = null; }
            await f.close();
            if (r && !r.error && !(r.code >= 300)) {
                await f.open('r');
                const sz = await f.size();
                const bin = sz > 0 ? await f.read(sz, 0) : null;
                await f.close();
                const u = binToU8(bin);
                if (u && u.length) got = u;
            }
        } catch (e) { console.log('[牛牛视频] ' + '[臻享] JSFile 取字节异常：' + e); }
        try { await f.delete(); } catch (e2) { }
        if (got) return got;
    }
    let u = null;
    try { const r = await req(url, { headers: hdrs, buffer: 1, timeout: 15000 }); u = r ? binToU8(r.content) : null; } catch (e) { u = null; }
    if (u && u.length) return u;
    try {
        const r = await req(url, { headers: hdrs, buffer: 2, timeout: 15000 });
        const s = r && typeof r.content === 'string' ? r.content : '';
        if (s) { const w = Crypto.enc.Base64.parse(s.replace(/[^A-Za-z0-9+/=]/g, '')); return waToU8(w); }
    } catch (e) { }
    return null;
}
async function fetchShiziKey(m3u8Url, keyUri) {
    let url = String(keyUri || '');
    if (!/^https?:\/\//i.test(url)) url = dirOf(m3u8Url) + url;
    const hdrs = ph();
    let b = await fetchShiziBytes(url, hdrs);
    if (!b || b.length < 16) {                       // 兜底：部分站点 key 也要带 m3u8 的 query 签名
        const q = String(m3u8Url).indexOf('?');
        if (q > -1) b = await fetchShiziBytes(url + (url.indexOf('?') > -1 ? '&' : '?') + String(m3u8Url).slice(q + 1), hdrs);
    }
    return (b && b.length >= 16) ? bytesToHex(b.subarray(0, 16)) : '';
}
async function fetchShiziRange(pngUrl, offset, length) {
    const hdrs = Object.assign({}, ph(), { 'Range': 'bytes=' + offset + '-' + (offset + length - 1) });
    const b = await fetchShiziBytes(pngUrl, hdrs);
    if (!b || !b.length) return null;
    if (b.length === length) return b;                                    // 206：正好是区间
    if (b.length > offset + length) return b.subarray(offset, offset + length); // 200：服务端忽略 Range，截区间
    return b.length > length ? b.subarray(0, length) : b;
}
function hex32(n) {                                  // 媒体序列号 → 32 位 hex IV（高位补零）
    let h = Number(n || 0).toString(16);
    while (h.length < 32) h = '0' + h;
    return h.slice(-32);
}
// 猫影视二进制回传：JSProxyStream 流式（base64 JSON 在猫影视会让分片全废）；setTimeout 重臂驱动事件循环
function shiziStream(u8, ct) {
    const st = new JSProxyStream();
    st.head(200, { connection: 'close', 'content-type': ct });
    const bin = (u8.byteOffset === 0 && u8.byteLength === u8.buffer.byteLength)
        ? u8.buffer
        : u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength);
    const wRetry = function () {
        (async function () {
            try {
                const rc = await st.write(bin);
                if (rc === -1) return;                     // 播放器已断开
                if (rc === 0) { setTimeout(wRetry, 10); return; }   // 背压，延时重写
                await st.done();
            } catch (we) { try { await st.error(we); } catch (e2) { } }
        })();
    };
    setTimeout(wRetry, 5);
    return { code: 200, buffer: 3, content: st, headers: { 'Content-Type': ct } };
}
// 重写 m3u8：剥掉 #EXT-X-KEY / #EXT-X-BYTERANGE，分片改成本地代理 URL（解密在代理内完成）
async function handleM3u8Shizi(m3u8Url) {
    const t0 = Date.now();
    const text = contentToText(await req(m3u8Url, { headers: ph(), timeout: 15000 }));
    if (!text || text.indexOf('#EXTM3U') < 0) { console.log('[牛牛视频] ' + '[臻享] m3u8 拉取失败'); return respErr(500); }
    const keyM = text.match(/#EXT-X-KEY:[^\r\n]*URI="([^"]+)"/i);
    if (!keyM) { console.log('[牛牛视频] ' + '[臻享] m3u8 无 #EXT-X-KEY'); return respErr(500); }
    const keyHex = await fetchShiziKey(m3u8Url, keyM[1]);
    if (!keyHex || keyHex.length !== 32) { console.log('[牛牛视频] ' + '[臻享] key 取失败'); return respErr(500); }
    const ivM = text.match(/#EXT-X-KEY:[^\r\n]*IV=0[xX]([0-9a-fA-F]{32})/i);
    const fixedIv = ivM ? ivM[1] : '';
    const sqM = text.match(/#EXT-X-MEDIA-SEQUENCE:(\d+)/i);
    const seqBase = sqM ? (parseInt(sqM[1], 10) || 0) : 0;
    const lines = text.split('\n'), out = [];
    let range = null, prevEnd = 0, inf = null, idx = 0;
    for (let i = 0; i < lines.length; i++) {
        const raw = lines[i].replace(/\r$/, ''), t = raw.trim();
        if (!t) continue;
        if (t.indexOf('#EXT-X-KEY') === 0 || t.indexOf('#EXT-X-MEDIA-SEQUENCE') === 0) continue;
        if (t.indexOf('#EXT-X-BYTERANGE') === 0) {
            const bm = t.match(/#EXT-X-BYTERANGE:(\d+)(?:@(\d+))?/i);
            if (bm) {
                const len = parseInt(bm[1], 10);
                range = { length: len, offset: bm[2] ? parseInt(bm[2], 10) : prevEnd };   // 无 @offset 按规范接续上一段
                prevEnd = range.offset + len;
            }
            continue;
        }
        if (t.indexOf('#EXTINF') === 0) { inf = raw; continue; }
        if (t.charAt(0) === '#') { out.push(raw); continue; }        // 其余标签原样（#EXTM3U/VERSION/TARGETDURATION…）
        if (!range || !inf) { range = null; inf = null; continue; }  // 缺 byterange/EXTINF 的脏段跳过
        const iv = fixedIv || hex32(seqBase + idx);
        out.push(inf);
        out.push(await proxyUrlFor('TS-' + b64uEnc(JSON.stringify({
            l: 'shizi', k: keyHex, i: iv, o: range.offset, n: range.length, u: t
        }))));
        idx++; range = null; inf = null;
    }
    if (!idx) { console.log('[牛牛视频] ' + '[臻享] m3u8 无可播放分片'); return respErr(500); }
    out.push('#EXT-X-ENDLIST');
    console.log('[牛牛视频] ' + '[臻享] m3u8 重写 ' + idx + ' 段（' + (Date.now() - t0) + 'ms）');
    return respText(200, out.join('\n'), 'application/vnd.apple.mpegurl');
}
// arg = '<keyHex>@<ivHex>@<offset>@<length>@<pngUrl>'
async function handleTsShizi(o) {
    const keyHex = String(o.k || ''), ivHex = String(o.i || '');
    const offset = parseInt(o.o, 10) || 0, length = parseInt(o.n, 10) || 0;
    const pngUrl = String(o.u || '');
    if (keyHex.length !== 32 || ivHex.length !== 32 || !length || !pngUrl) return respErr(500);
    const t0 = Date.now();
    const bytes = await fetchShiziRange(pngUrl, offset, length);
    if (!bytes || !bytes.length) { console.log('[牛牛视频] ' + '[臻享] 区段取字节为空 off=' + offset + ' len=' + length); return respErr(500); }
    let dec = null;
    try { dec = aesCbcDecBin(bytes, keyHex, ivHex); } catch (e) { console.log('[牛牛视频] ' + '[臻享] 解密异常：' + e); }
    if (!dec || !dec.length) return respErr(500);
    console.log('[牛牛视频] ' + '[臻享] TS ' + dec.length + 'B（' + (Date.now() - t0) + 'ms）');
    // 只有猫影视会进这条链路（其余壳根本不走代理），JSProxyStream 是猫影视的二进制流式回传通道
    if (cat && typeof JSFile === 'function' && typeof JSProxyStream === 'function') return shiziStream(dec, 'video/mp2t');
    return respBytes(dec, 'video/mp2t');
}
// ==== ZH-END ====
// ==== MP4CENC-BEGIN 短剧加密 mp4（ISO/IEC 23001-7 'cenc' = AES-128-CTR）流式解密 ====
// 与 APP 的调用时机对齐（dex 实证 com.sexy.goddess）：
//   detail 阶段只下发集 ID（djzy,<19位剧集ID>），**不解密、不请求解析接口**；
//   点播放才走 z3.d.G(url,key,cacheId,hdr) → 取 key → 解密 → 播放。
//   本源同样只在 play() 里请求 dj.php 拿 url/key，解密则下沉到代理、按播放器请求的字节区间惰性进行。
// 为什么能流式（不必整集落盘）：
//   ① 逐 sample 独立 IV（tenc.per_sample_IV_size=8，IV 表在 senc）⇒ 任一 sample 可单独解；
//   ② AES-CTR 无填充 ⇒ 明文长度==密文长度，stsz/stsc/stco 关系不变，mdat 尺寸不变；
//   ③ key 由接口下发、解密参数全在 moov ⇒ 只读 ~180KB moov 即掌握全片。
// 因此只做三件事：重建 moov（encv/enca→frma 原类型、删 sinf/schi/tenc/senc/saiz/saio/pssh）
//   → stco 按 moov 长度差平移 → 建「输出区间→源区间」映射，按请求区间读上游 + 逐 sample 解密。
// ★ 两个必踩坑（已在 Python/JS 双实现验证）：
//   ① stco 平移判据是「chunk 偏移 > moov 起点」，不是无条件加 delta
//      （moov 在尾部的非 faststart 文件 chunk 在 moov 前，加了就全错）；
//   ② subsample 的 CTR counter 必须按「累计受保护字节」做**字节级**偏移（blk,off = divmod(skip,16)），
//      CENC 的 subsample 边界不要求 16 对齐，按「每段从块边界重开」会整段错位。
function seq2(v, fn) { return (v && typeof v.then === 'function') ? v.then(fn) : fn(v); }

const MP4C = (function () {
    // ---------------- 字节读写 ----------------
    function rU32(b, p) { return ((b[p] << 24) | (b[p + 1] << 16) | (b[p + 2] << 8) | b[p + 3]) >>> 0; }
    function rU16(b, p) { return (b[p] << 8) | b[p + 1]; }
    function wU32(b, p, v) { b[p] = (v >>> 24) & 255; b[p + 1] = (v >>> 16) & 255; b[p + 2] = (v >>> 8) & 255; b[p + 3] = v & 255; }

    // ---------------- AES-128（只需加密方向：CTR 的 keystream = AES_enc(counter)） ----------------
    // 不依赖 CryptoJS 的 CTR（跨壳版本不一），T-table 实现；QuickJS 下约 5~15MB/s，够 1080p 播放。
    const S = new Uint8Array(256);
    const T0 = new Uint32Array(256), T1 = new Uint32Array(256), T2 = new Uint32Array(256), T3 = new Uint32Array(256);
    (function initAes() {
        const exp = new Uint8Array(512), log = new Uint8Array(256);
        let x = 1;
        for (let i = 0; i < 255; i++) {
            exp[i] = x; log[x] = i;
            const m2 = ((x << 1) ^ ((x & 0x80) ? 0x1b : 0)) & 0xff;
            x = (x ^ m2) & 0xff;
        }
        for (let i = 255; i < 512; i++) exp[i] = exp[i - 255];
        const rotl8 = function (v, n) { return ((v << n) | (v >>> (8 - n))) & 0xff; };
        for (let a = 0; a < 256; a++) {
            const inv = a === 0 ? 0 : exp[(255 - log[a]) % 255];
            S[a] = (inv ^ rotl8(inv, 1) ^ rotl8(inv, 2) ^ rotl8(inv, 3) ^ rotl8(inv, 4) ^ 0x63) & 0xff;
        }
        for (let a = 0; a < 256; a++) {
            const s = S[a];
            const s2 = ((s << 1) ^ ((s & 0x80) ? 0x1b : 0)) & 0xff;
            const s3 = s2 ^ s;
            const t = (((s2 << 24) | (s << 16) | (s << 8) | s3) >>> 0);
            T0[a] = t;
            T1[a] = ((t >>> 8) | (t << 24)) >>> 0;
            T2[a] = ((t >>> 16) | (t << 16)) >>> 0;
            T3[a] = ((t >>> 24) | (t << 8)) >>> 0;
        }
    })();
    const RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36];

    function aesExpand(key) {
        const rk = new Uint32Array(44);
        for (let i = 0; i < 4; i++) rk[i] = ((key[4 * i] << 24) | (key[4 * i + 1] << 16) | (key[4 * i + 2] << 8) | key[4 * i + 3]) >>> 0;
        for (let i = 4; i < 44; i++) {
            let t = rk[i - 1];
            if (i % 4 === 0) {
                t = (((S[(t >>> 16) & 0xff] << 24) | (S[(t >>> 8) & 0xff] << 16) | (S[t & 0xff] << 8) | S[t >>> 24]) >>> 0);
                t = (t ^ (RCON[(i >> 2) - 1] << 24)) >>> 0;
            }
            rk[i] = (rk[i - 4] ^ t) >>> 0;
        }
        return rk;
    }
    function aesEncBlock(rk, inp, ip, out, op) {
        let s0 = (rU32(inp, ip) ^ rk[0]) >>> 0;
        let s1 = (rU32(inp, ip + 4) ^ rk[1]) >>> 0;
        let s2 = (rU32(inp, ip + 8) ^ rk[2]) >>> 0;
        let s3 = (rU32(inp, ip + 12) ^ rk[3]) >>> 0;
        let t0, t1, t2, t3;
        for (let r = 4; r < 40; r += 4) {
            t0 = (T0[s0 >>> 24] ^ T1[(s1 >>> 16) & 0xff] ^ T2[(s2 >>> 8) & 0xff] ^ T3[s3 & 0xff] ^ rk[r]) >>> 0;
            t1 = (T0[s1 >>> 24] ^ T1[(s2 >>> 16) & 0xff] ^ T2[(s3 >>> 8) & 0xff] ^ T3[s0 & 0xff] ^ rk[r + 1]) >>> 0;
            t2 = (T0[s2 >>> 24] ^ T1[(s3 >>> 16) & 0xff] ^ T2[(s0 >>> 8) & 0xff] ^ T3[s1 & 0xff] ^ rk[r + 2]) >>> 0;
            t3 = (T0[s3 >>> 24] ^ T1[(s0 >>> 16) & 0xff] ^ T2[(s1 >>> 8) & 0xff] ^ T3[s2 & 0xff] ^ rk[r + 3]) >>> 0;
            s0 = t0; s1 = t1; s2 = t2; s3 = t3;
        }
        wU32(out, op, (((S[s0 >>> 24] << 24) | (S[(s1 >>> 16) & 0xff] << 16) | (S[(s2 >>> 8) & 0xff] << 8) | S[s3 & 0xff]) ^ rk[40]) >>> 0);
        wU32(out, op + 4, (((S[s1 >>> 24] << 24) | (S[(s2 >>> 16) & 0xff] << 16) | (S[(s3 >>> 8) & 0xff] << 8) | S[s0 & 0xff]) ^ rk[41]) >>> 0);
        wU32(out, op + 8, (((S[s2 >>> 24] << 24) | (S[(s3 >>> 16) & 0xff] << 16) | (S[(s0 >>> 8) & 0xff] << 8) | S[s1 & 0xff]) ^ rk[42]) >>> 0);
        wU32(out, op + 12, (((S[s3 >>> 24] << 24) | (S[(s0 >>> 16) & 0xff] << 16) | (S[(s1 >>> 8) & 0xff] << 8) | S[s2 & 0xff]) ^ rk[43]) >>> 0);
    }

    // data[base..base+len) 原地 XOR keystream；counter 从 iv 前进 skip 个受保护字节（字节级，非块级）
    function ctrXor(rk, iv, skip, buf, base, len) {
        if (!len) return;
        let c0 = rU32(iv, 0), c1 = rU32(iv, 4), c2 = rU32(iv, 8), c3 = rU32(iv, 12);
        const blk = Math.floor(skip / 16), off = skip % 16;
        if (blk > 0) {
            const sum = c3 + blk;
            c3 = sum % 4294967296;
            if (sum >= 4294967296) {
                c2 = (c2 + 1) % 4294967296;
                if (c2 === 0) { c1 = (c1 + 1) % 4294967296; if (c1 === 0) c0 = (c0 + 1) % 4294967296; }
            }
        }
        const cb = new Uint8Array(16), ks = new Uint8Array(16);
        let p = 0;
        while (p < len) {
            wU32(cb, 0, c0); wU32(cb, 4, c1); wU32(cb, 8, c2); wU32(cb, 12, c3);
            aesEncBlock(rk, cb, 0, ks, 0);
            const st = p === 0 ? off : 0;
            for (let i = st; i < 16 && p < len; i++) { buf[base + p] ^= ks[i]; p++; }
            c3 = (c3 + 1) % 4294967296;
            if (c3 === 0) { c2 = (c2 + 1) % 4294967296; if (c2 === 0) { c1 = (c1 + 1) % 4294967296; if (c1 === 0) c0 = (c0 + 1) % 4294967296; } }
        }
    }

    // ---------------- box 常量与遍历 ----------------
    const TY = {
        moov: 0x6d6f6f76, mdat: 0x6d646174, trak: 0x7472616b, mdia: 0x6d646961, minf: 0x6d696e66,
        stbl: 0x7374626c, stsd: 0x73747364, encv: 0x656e6376, enca: 0x656e6361, sinf: 0x73696e66,
        frma: 0x66726d61, schm: 0x7363686d, schi: 0x73636869, tenc: 0x74656e63, stsz: 0x7374737a,
        stz2: 0x73747a32, stsc: 0x73747363, stco: 0x7374636f, co64: 0x636f3634, senc: 0x73656e63,
        saiz: 0x7361697a, saio: 0x7361696f, pssh: 0x70737368, tkhd: 0x746b6864
    };
    const ENTRY_FIXED = { 0x656e6376: 78, 0x656e6361: 28, 0x68766331: 78, 0x61766331: 78, 0x6d703461: 28 };
    const STBL_DROP = [TY.senc, TY.saiz, TY.saio];
    const MOOV_DROP = [TY.pssh];

    function parseBoxes(buf, start, end) {
        const out = [];
        let off = start;
        while (off + 8 <= end) {
            let size = rU32(buf, off);
            const type = rU32(buf, off + 4);
            let hdr = 8;
            if (size === 1) {
                if (off + 16 > end) break;
                size = rU32(buf, off + 8) * 4294967296 + rU32(buf, off + 12);
                hdr = 16;
            } else if (size === 0) size = end - off;
            if (size < hdr || off + size > end) break;
            out.push({ t: type, s: off, n: size, h: hdr });
            off += size;
        }
        return out;
    }
    function has(arr, v) { for (let i = 0; i < arr.length; i++) if (arr[i] === v) return true; return false; }
    function tname(t) { return String.fromCharCode((t >>> 24) & 255, (t >>> 16) & 255, (t >>> 8) & 255, t & 255); }

    // ---------------- 顶层 box（逐个头探测，mdat 内容绝不下载） ----------------
    function loadTop(a) {
        const want = 131072;
        return seq2(a.read(0, want - 1), function (buf) {
            if (!buf || !buf.length) throw new Error('上游读取失败（Range/二进制通道均拿不到字节）');
            a.head = buf;
            a.top = [];
            a.moov = null;
            const step = function (pos) {
                while (pos + 8 <= a.size) {
                    let hb;
                    if (pos + 16 <= a.head.length) hb = a.head.subarray(pos, pos + 16);
                    else return seq2(a.read(pos, Math.min(pos + 15, a.size - 1)), function (x) { return one(pos, x); });
                    const r = one2(a, pos, hb);
                    if (!r) return finalize2(a);
                    pos += r;
                }
                return finalize2(a);
            };
            const one = function (pos, x) {
                if (!x || x.length < 8) return finalize2(a);
                const r = one2(a, pos, x);
                if (!r) return finalize2(a);
                return step(pos + r);
            };
            return step(0);
        });
    }
    function one2(a, pos, hb) {
        let bsize = rU32(hb, 0);
        const typ = rU32(hb, 4);
        let hdr = 8;
        if (bsize === 1) {
            if (hb.length < 16) return 0;
            bsize = rU32(hb, 8) * 4294967296 + rU32(hb, 12);
            hdr = 16;
        } else if (bsize === 0) bsize = a.size - pos;
        if (bsize < hdr || pos + bsize > a.size) return 0;
        a.top.push({ t: typ, s: pos, n: bsize, h: hdr });
        return bsize;
    }
    function finalize2(a) {
        if (a._fin) return true;
        a._fin = true;
        for (let i = 0; i < a.top.length; i++) {
            const b = a.top[i];
            if (b.t === TY.moov) a.moov = b;
            if (b.t === TY.mdat) a.mdats.push(b);
        }
        if (!a.moov) throw new Error('无 moov（fragmented mp4？）');
        if (!a.mdats.length) throw new Error('无 mdat');
        return true;
    }
    function loadMoov(a) {
        const m = a.moov;
        if (m.s + m.n <= a.head.length) { a.moovBuf = a.head.subarray(m.s, m.s + m.n); return true; }
        return seq2(a.read(m.s, m.s + m.n - 1), function (b) { a.moovBuf = b; return true; });
    }

    // ---------------- moov 解析 ----------------
    function parseTracks(a) {
        const buf = a.moovBuf;
        const kids = parseBoxes(buf, 8, buf.length);
        a.tracks = [];
        for (let i = 0; i < kids.length; i++) {
            if (kids[i].t !== TY.trak) continue;
            const t = parseTrak(buf, kids[i]);
            if (t) a.tracks.push(t);          // ★ 全部保留：stsd 遍历顺序 == tracks 下标
        }
    }
    function parseTrak(buf, trak) {
        const t = {
            entryType: 0, origType: 0, trackId: 0, sizes: null, chunks: null, stsc: null,
            ivs: null, subs: null, ivSize: 0, constIv: null, isProtected: 0,
            kid: '', isVid: 0                   // ★ tenc 的 KID（16B hex）+ 是否视频轨（ClearKey 只需视频轨那把）
        };
        const tk = parseBoxes(buf, trak.s + trak.h, trak.s + trak.n);
        const tkhd = findIn(tk, TY.tkhd);
        if (tkhd) {
            const p = tkhd.s + tkhd.h;
            const ver = buf[p];
            const off = ver === 1 ? 16 : 8;
            if (p + 4 + off + 4 <= tkhd.s + tkhd.n) t.trackId = rU32(buf, p + 4 + off);
        }
        const mdia = findIn(tk, TY.mdia);
        if (!mdia) return t;
        const minf = findIn(parseBoxes(buf, mdia.s + mdia.h, mdia.s + mdia.n), TY.minf);
        if (!minf) return t;
        const stbl = findIn(parseBoxes(buf, minf.s + minf.h, minf.s + minf.n), TY.stbl);
        if (!stbl) return t;
        const st = parseBoxes(buf, stbl.s + stbl.h, stbl.s + stbl.n);

        const stsd = findIn(st, TY.stsd);
        if (stsd) {
            const ents = parseBoxes(buf, stsd.s + stsd.h + 8, stsd.s + stsd.n);
            if (ents.length) {
                const ent = ents[0];
                t.entryType = ent.t;
                t.isVid = ent.t === TY.encv ? 1 : 0;
                const fixed = ENTRY_FIXED[ent.t];
                if (fixed === undefined) throw new Error('未知 sample entry ' + tname(ent.t));
                const sub = parseBoxes(buf, ent.s + ent.h + fixed, ent.s + ent.n);
                for (let i = 0; i < sub.length; i++) if (sub[i].t === TY.sinf) parseSinf(buf, sub[i], t);
                if (!t.origType) t.origType = ent.t === TY.encv ? 0x68766331 : (ent.t === TY.enca ? 0x6d703461 : ent.t);
            }
        }
        const stsz = findIn(st, TY.stsz);
        if (stsz) {
            const p = stsz.s + stsz.h;
            const ss = rU32(buf, p + 4), cnt = rU32(buf, p + 8);
            t.sizes = new Uint32Array(cnt);
            if (ss) { for (let i = 0; i < cnt; i++) t.sizes[i] = ss; }
            else for (let i = 0; i < cnt; i++) t.sizes[i] = rU32(buf, p + 12 + 4 * i);
        } else {
            const stz2 = findIn(st, TY.stz2);
            if (stz2) {
                const p = stz2.s + stz2.h;
                const fs = buf[p + 7], cnt = rU32(buf, p + 8);
                t.sizes = new Uint32Array(cnt);
                for (let i = 0; i < cnt; i++) {
                    if (fs === 4) { const b = buf[p + 12 + (i >> 1)]; t.sizes[i] = (i % 2 === 0) ? (b >> 4) : (b & 15); }
                    else if (fs === 8) t.sizes[i] = buf[p + 12 + i];
                    else t.sizes[i] = rU16(buf, p + 12 + 2 * i);
                }
            }
        }
        const stco = findIn(st, TY.stco), co64 = findIn(st, TY.co64);
        if (stco) {
            const p = stco.s + stco.h, n = rU32(buf, p + 4);
            t.chunks = new Uint32Array(n);
            for (let i = 0; i < n; i++) t.chunks[i] = rU32(buf, p + 8 + 4 * i);
        } else if (co64) {
            const p = co64.s + co64.h, n = rU32(buf, p + 4);
            t.chunks = new Float64Array(n);
            for (let i = 0; i < n; i++) t.chunks[i] = rU32(buf, p + 8 + 8 * i) * 4294967296 + rU32(buf, p + 12 + 8 * i);
        }
        const stsc = findIn(st, TY.stsc);
        if (stsc) {
            const p = stsc.s + stsc.h, n = rU32(buf, p + 4);
            t.stsc = [];
            for (let i = 0; i < n; i++) t.stsc.push([rU32(buf, p + 8 + 12 * i), rU32(buf, p + 12 + 12 * i)]);
        }
        const senc = findIn(st, TY.senc);
        if (senc && t.sizes) {
            const p = senc.s + senc.h;
            const flags = rU32(buf, p) & 0xffffff;
            const n = rU32(buf, p + 4);
            const ivSize = t.ivSize || 8;
            const hasSub = (flags & 2) !== 0;
            t.ivs = new Uint8Array(n * 16);
            t.subs = new Array(n);
            let q = p + 8;
            for (let i = 0; i < n; i++) {
                // IV 补齐 16 字节（8 字节 IV 尾部补 0，正是 CENC 的 counter 规则）
                for (let k = 0; k < ivSize && k < 16; k++) t.ivs[i * 16 + k] = buf[q + k];
                q += ivSize;
                if (hasSub) {
                    const c = rU16(buf, q); q += 2;
                    const segs = [];
                    for (let k = 0; k < c; k++) { segs.push([rU16(buf, q), rU32(buf, q + 2)]); q += 6; }
                    t.subs[i] = segs;
                } else t.subs[i] = null;
            }
        }
        return t;
    }
    function findIn(list, type) {
        for (let i = 0; i < list.length; i++) if (list[i].t === type) return list[i];
        return null;
    }
    function parseSinf(buf, sinf, t) {
        const kids = parseBoxes(buf, sinf.s + sinf.h, sinf.s + sinf.n);
        for (let i = 0; i < kids.length; i++) {
            if (kids[i].t === TY.frma) t.origType = rU32(buf, kids[i].s + kids[i].h);
            else if (kids[i].t === TY.schi) {
                const tenc = findIn(parseBoxes(buf, kids[i].s + kids[i].h, kids[i].s + kids[i].n), TY.tenc);
                if (tenc) {
                    const p = tenc.s + tenc.h;
                    const ver = buf[p];
                    // v0: [reserved][crypt:skip][isProtected][ivSize][KID16]
                    // v1: [pattern][isProtected][ivSize][KID16][constIVSize][constIV]
                    const q = p + 4 + (ver > 0 ? 1 : 2);
                    t.isProtected = buf[q];
                    t.ivSize = buf[q + 1];
                    // ★ KID（16B，v0/v1 位置相同：紧跟 ivSize 之后）——播放器解密（Result.drm/ClearKey）要用
                    let kh = '';
                    for (let b = q + 2; b < q + 18; b++) kh += ('0' + (buf[b] & 255).toString(16)).slice(-2);
                    t.kid = kh;
                    if (ver > 0) { const cz = buf[q + 18]; if (cz) t.constIv = buf.subarray(q + 19, q + 19 + cz); }
                }
            }
        }
    }

    // ---------------- sample 合并表（按源偏移升序） ----------------
    function buildSamples(a) {
        const list = [];
        for (let ti = 0; ti < a.tracks.length; ti++) {
            const t = a.tracks[ti];
            if (!(t.sizes && t.chunks && t.stsc)) continue;
            const stsc = t.stsc.slice().sort(function (x, y) { return x[0] - y[0]; });
            let si = 0;
            const nch = t.chunks.length;
            for (let k = 0; k < stsc.length && si < t.sizes.length; k++) {
                const first = stsc[k][0], spc = stsc[k][1];
                const nxt = (k + 1 < stsc.length) ? stsc[k + 1][0] : nch + 1;
                for (let ch = first; ch < nxt && si < t.sizes.length; ch++) {
                    if (ch - 1 >= nch) break;
                    let off = t.chunks[ch - 1];
                    for (let q = 0; q < spc && si < t.sizes.length; q++) {
                        list.push({ o: off, z: t.sizes[si], ti: ti, si: si });
                        off += t.sizes[si];
                        si++;
                    }
                }
            }
        }
        list.sort(function (x, y) { return x.o - y.o; });
        const n = list.length;
        a.sOff = new Float64Array(n);
        a.sSize = new Uint32Array(n);
        a.sIv = new Uint8Array(n * 16);
        a.sSubs = new Array(n);
        a.sEnc = new Uint8Array(n);   // ★ per-sample 加密标志：只认结构证据（senc IV 表 / tenc constIV）
        for (let i = 0; i < n; i++) {
            const it = list[i], tr = a.tracks[it.ti];
            a.sOff[i] = it.o;
            a.sSize[i] = it.z;
            if (tr.ivs) { const base = it.si * 16; for (let k = 0; k < 16; k++) a.sIv[i * 16 + k] = tr.ivs[base + k]; }
            else if (tr.constIv) { for (let k = 0; k < 16; k++) a.sIv[i * 16 + k] = tr.constIv[k] || 0; }
            a.sSubs[i] = tr.subs ? tr.subs[it.si] : null;
            a.sEnc[i] = (tr.ivs || tr.constIv) ? 1 : 0;   // 普通轨道（无 senc 无 constIV）⇒ 0，applyJob 原样透传
        }
    }

    // ---------------- 重建 moov ----------------
    function wrapBox(type, payload) {
        const out = new Uint8Array(8 + payload.length);
        wU32(out, 0, out.length);
        wU32(out, 4, type);
        out.set(payload, 8);
        return out;
    }
    function cat(parts) {
        let n = 0;
        for (let i = 0; i < parts.length; i++) n += parts[i].length;
        const out = new Uint8Array(n);
        let p = 0;
        for (let i = 0; i < parts.length; i++) { out.set(parts[i], p); p += parts[i].length; }
        return out;
    }
    function emitContainer(a, buf, box, delta, ctx) {
        if (box.t === TY.moov) {
            const parts = [];
            const kids = parseBoxes(buf, box.s + box.h, box.s + box.n);
            for (let i = 0; i < kids.length; i++) { if (has(MOOV_DROP, kids[i].t)) continue; parts.push(emitContainer(a, buf, kids[i], delta, ctx)); }
            return wrapBox(box.t, cat(parts));
        }
        if (box.t === TY.trak || box.t === TY.mdia || box.t === TY.minf) {
            const parts = [];
            const isTrak = box.t === TY.trak;
            if (isTrak) ctx.stack.push(ctx.trak++);
            const kids = parseBoxes(buf, box.s + box.h, box.s + box.n);
            for (let i = 0; i < kids.length; i++) parts.push(emitContainer(a, buf, kids[i], delta, ctx));
            if (isTrak) ctx.stack.pop();
            return wrapBox(box.t, cat(parts));
        }
        if (box.t === TY.stbl) {
            const parts = [];
            const kids = parseBoxes(buf, box.s + box.h, box.s + box.n);
            for (let i = 0; i < kids.length; i++) {
                const k = kids[i];
                if (has(STBL_DROP, k.t)) continue;
                if (k.t === TY.stco || k.t === TY.co64) parts.push(emitStco(a, buf, k, delta));
                else parts.push(emitContainer(a, buf, k, delta, ctx));
            }
            return wrapBox(box.t, cat(parts));
        }
        if (box.t === TY.stsd) {
            const parts = [buf.subarray(box.s + box.h, box.s + box.h + 8)];
            const ents = parseBoxes(buf, box.s + box.h + 8, box.s + box.n);
            for (let i = 0; i < ents.length; i++) parts.push(emitEntry(a, buf, ents[i], ctx));
            return wrapBox(box.t, cat(parts));
        }
        if (box.t === TY.encv || box.t === TY.enca) return emitEntry(a, buf, box, ctx);
        return buf.slice(box.s, box.s + box.n);      // 其余原样（udta/meta/elst…）
    }
    function emitEntry(a, buf, ent, ctx) {
        if (ent.t !== TY.encv && ent.t !== TY.enca) return buf.slice(ent.s, ent.s + ent.n);
        const fixed = ENTRY_FIXED[ent.t];
        const parts = [buf.subarray(ent.s + ent.h, ent.s + ent.h + fixed)];
        const subs = parseBoxes(buf, ent.s + ent.h + fixed, ent.s + ent.n);
        for (let i = 0; i < subs.length; i++) {
            if (subs[i].t === TY.sinf) continue;      // 去掉 sinf（frma/schm/schi+tenc 全在里头）
            parts.push(buf.slice(subs[i].s, subs[i].s + subs[i].n));
        }
        const tr = a.tracks[ctx.stack[ctx.stack.length - 1]];
        const typ = (tr && tr.origType) ? tr.origType : (ent.t === TY.encv ? 0x68766331 : 0x6d703461);
        return wrapBox(typ, cat(parts));
    }
    function emitStco(a, buf, box, delta) {
        const p = box.s + box.h;
        const n = rU32(buf, p + 4);
        const mstart = a.moov.s;
        const is64 = box.t === TY.co64;
        const body = new Uint8Array(8 + (is64 ? 8 : 4) * n);
        wU32(body, 0, 0); wU32(body, 4, n);
        for (let i = 0; i < n; i++) {
            let v = is64 ? (rU32(buf, p + 8 + 8 * i) * 4294967296 + rU32(buf, p + 12 + 8 * i)) : rU32(buf, p + 8 + 4 * i);
            if (v > mstart) v += delta;              // ★ 只有 moov 之后的 chunk 才平移
            if (is64) { wU32(body, 8 + 8 * i, Math.floor(v / 4294967296)); wU32(body, 12 + 8 * i, v % 4294967296); }
            else wU32(body, 8 + 4 * i, v);
        }
        return wrapBox(box.t, body);
    }
    function rebuildMoov(a) {
        const buf = a.moovBuf;
        const mbox = { t: TY.moov, s: 0, n: buf.length, h: 8 };
        let out = emitContainer(a, buf, mbox, 0, { stack: [], trak: 0 });      // ① delta=0 先算长度
        a.delta = out.length - a.moov.n;
        out = emitContainer(a, buf, mbox, a.delta, { stack: [], trak: 0 });    // ② 带 delta 重生成
        a.newMoov = out;
    }
    function buildLayout(a) {
        const lay = [];
        let off = 0;
        for (let i = 0; i < a.top.length; i++) {
            const b = a.top[i];
            if (b.t === TY.moov) {
                lay.push({ o0: off, o1: off + a.newMoov.length, kind: 'moov' });
                off += a.newMoov.length;
            } else if (b.t === TY.mdat) {
                lay.push({ o0: off, o1: off + b.h, kind: 'copy', s: b.s, n: b.h });
                off += b.h;
                const plen = b.n - b.h;
                lay.push({ o0: off, o1: off + plen, kind: 'mdat', s: b.s + b.h });
                off += plen;
            } else {
                lay.push({ o0: off, o1: off + b.n, kind: 'copy', s: b.s, n: b.n });
                off += b.n;
            }
        }
        a.layout = lay;
        a.outSize = off;
        a.layStarts = lay.map(function (x) { return x.o0; });
    }

    // ---------------- 区间读 ----------------
    function bisectRight(arr, v) {
        let lo = 0, hi = arr.length;
        while (lo < hi) { const m = (lo + hi) >> 1; if (arr[m] <= v) lo = m + 1; else hi = m; }
        return lo;
    }
    function samplesIn(a, lo, hi) {
        let i = Math.max(0, bisectRight(a.sOff, lo) - 1);
        while (i < a.sOff.length && a.sOff[i] + a.sSize[i] <= lo) i++;
        let j = i;
        while (j < a.sOff.length && a.sOff[j] < hi) j++;
        return [i, j];
    }
    function read(a, start, end) {
        if (start < 0) start = 0;
        if (end > a.outSize) end = a.outSize;
        if (start >= end) return new Uint8Array(0);
        const out = new Uint8Array(end - start);
        const segs = [];
        let pos = start;
        while (pos < end) {
            const L = a.layout[bisectRight(a.layStarts, pos) - 1];
            const take = Math.min(end, L.o1);
            if (L.kind === 'moov') out.set(a.newMoov.subarray(pos - L.o0, take - L.o0), pos - start);
            else if (L.kind === 'copy') segs.push({ kind: 'raw', srcStart: L.s + (pos - L.o0), len: take - pos, outOff: pos - start });
            else segs.push({ kind: 'mdat', lo: L.s + (pos - L.o0), hi: L.s + (take - L.o0), outOff: pos - start });
            pos = take;
        }
        const jobs = [];
        for (let i = 0; i < segs.length; i++) {
            const sg = segs[i];
            if (sg.kind === 'raw') { jobs.push({ kind: 'raw', srcStart: sg.srcStart, srcEnd: sg.srcStart + sg.len - 1, seg: sg }); continue; }
            const ab = samplesIn(a, sg.lo, sg.hi);
            let k = ab[0];
            while (k < ab[1]) {
                const gStart = a.sOff[k];
                let gEnd = gStart, m = k;
                while (m < ab[1]) {
                    const se = a.sOff[m] + a.sSize[m];
                    if (se - gStart > (4 << 20) && m > k) break;   // 单次上游读取上限 4MB
                    if (se > gEnd) gEnd = se;
                    m++;
                }
                jobs.push({ kind: 'mdat', srcStart: gStart, srcEnd: gEnd - 1, seg: sg, k0: k, k1: m });
                k = m;
            }
        }
        const vals = [];
        let async = false;
        for (let i = 0; i < jobs.length; i++) {
            const v = jobs[i].srcEnd >= jobs[i].srcStart ? a.read(jobs[i].srcStart, jobs[i].srcEnd) : new Uint8Array(0);
            if (v && typeof v.then === 'function') async = true;
            vals.push(v);
        }
        const finish = function (vs) {
            for (let i = 0; i < jobs.length; i++) applyJob(a, jobs[i], vs[i], out);
            return out;
        };
        return async ? Promise.all(vals).then(finish) : finish(vals);
    }
    function applyJob(a, job, buf, out) {
        const sg = job.seg;
        if (job.kind === 'raw') { out.set(buf.subarray(0, sg.len), sg.outOff); return; }
        for (let q = job.k0; q < job.k1; q++) {
            const off = a.sOff[q], size = a.sSize[q];
            const x = Math.max(off, sg.lo), y = Math.min(off + size, sg.hi);
            if (x >= y) continue;
            const rel = x - job.srcStart;
            const dst = sg.outOff + (x - sg.lo);
            const n = y - x;
            // ★ 未加密 sample（无 senc IV / tenc constIV）：原样透传。防御服务端误标 keymp4 的场景——
            //   否则会给它套全零 IV 做 CTR 异或，把好片「解密」坏。
            if (!a.sEnc || !a.sEnc[q]) { out.set(buf.subarray(rel, rel + n), dst); continue; }
            const iv = a.sIv.subarray(q * 16, q * 16 + 16);
            const subs = a.sSubs[q];
            if (!subs) {
                out.set(buf.subarray(rel, rel + n), dst);
                ctrXor(a.rk, iv, x - off, out, dst, n);
            } else {
                // subsample：按段求交，protected 段的 counter 按「累计受保护字节」推进
                let p = 0, cum = 0;
                for (let s = 0; s < subs.length; s++) {
                    const clear = subs[s][0], prot = subs[s][1];
                    const pa = off + p + clear, pb = pa + prot;
                    const ix = Math.max(pa, x), iy = Math.min(pb, y);
                    if (ix < iy) {
                        const r2 = ix - job.srcStart;
                        const d2 = sg.outOff + (ix - sg.lo);
                        out.set(buf.subarray(r2, r2 + (iy - ix)), d2);
                        ctrXor(a.rk, iv, cum + (ix - pa), out, d2, iy - ix);
                    }
                    p += clear + prot;
                    cum += prot;
                }
            }
        }
    }

    // ---------------- 装配 ----------------
    function build(a) {
        return seq2(loadTop(a), function () {
            return seq2(loadMoov(a), function () {
                parseTracks(a);
                buildSamples(a);
                rebuildMoov(a);
                buildLayout(a);
                return a;
            });
        });
    }
    function newAsset(readFn, size, keyHex) {
        const key = new Uint8Array(16);
        for (let i = 0; i < 16; i++) key[i] = parseInt(keyHex.substr(i * 2, 2), 16);
        return { read: readFn, size: size || 0, rk: aesExpand(key), mdats: [], top: [] };
    }
    return { build: build, read: read, newAsset: newAsset, ctrXor: ctrXor, aesExpand: aesExpand, parseBoxes: parseBoxes, rU32: rU32 };
})();

// ---- 上游字节读取（Range + 二进制通道探测：buffer:3 最优 → 1 → 2） ----
const MC_BUF = { v: 0 };                       // 0=未探测；3=byte[] 直传；1=JS Array；2=base64
function mcBytes(r, mode) {
    const c = r && r.content;
    if (c == null) return null;
    if (mode === 2) {
        const s = typeof c === 'string' ? c : '';
        if (!s) return null;
        try { return waToU8(Crypto.enc.Base64.parse(s.replace(/[^A-Za-z0-9+/=]/g, ''))); } catch (e) { return null; }
    }
    return binToU8(c);
}
function mcHeader(r, name) {
    const h = (r && r.headers) || {};
    for (const k in h) if (String(k).toLowerCase() === name) {
        const v = h[k];
        return Array.isArray(v) ? String(v[0]) : String(v);
    }
    return '';
}
// bcRead(src, start, end) → Uint8Array（或 Promise）；同时填充 src.size
// ★ 猫影视桌面版 1.1.3 实证（2026-10-23 真机日志 + 央视片库同壳同款）：
//   · req 恒 async（返回 Promise，resolve 后 {code,headers,error,content}）；
//   · buffer:1 可用（content=ArrayBuffer），但逐字节装箱隐患在 fongmi 侧；
//   · **buffer:3 + stream:JSFile 落盘（ffm3u8 式）是该壳已实证的零 JS 内存通道** ⇒ cat 首选；
//   · 裸 buffer:3 在该壳未实证，仅作落盘失败后的次选；buffer:1 为最终兜底。
// ★ 异步分支必须挂 rejection 处理器：某一路 reject 不接住会炸整链 ⇒ proxy 500。
function bcRead(src, start, end) {
    const h = { 'User-Agent': src.ua || 'okhttp/3.12.1', 'Range': 'bytes=' + start + '-' + end };
    const len = end - start + 1;
    if (cat && typeof JSFile === 'function') {
        return bcReadFile(src, h, len, start).then(function (got) {
            if (got) { MC_BUF.v = 'file'; return got; }
            console.log('[牛牛视频] ' + '[短剧] JSFile 通道未取到字节，降级裸 buffer 探测');
            return bcReadPlain(src, h, len, start);
        });
    }
    return bcReadPlain(src, h, len, start);
}
// JSFile 落盘通道：req(buffer:3, stream:enc) 壳子直写文件（二进制不进 JS 内存）→ enc.read 读回
// ★★ 临时文件名必须每次唯一：6 路并发管道经背压/换集打乱齐步后，可能同时有两个块在途，
//    共用一个文件会互相覆盖 ⇒ 上游字节混串 ⇒ 解密出垃圾 ⇒ 花屏（真机症状：同集时好时坏）；
//    且换集后旧管道未死透时，新集的 moov 预热读也会撞车 ⇒ 索引构建失败 ⇒ 换集播放失败。
const MC_TMPSEQ = { n: 0 };
async function bcReadFile(src, h, len, start) {
    let enc = null;
    try {
        enc = new JSFile('nn_cenc_' + (++MC_TMPSEQ.n) + '.bin');
        await enc.open('w');
        let resp = null;
        try { resp = await req(src.u, { headers: h, buffer: 3, stream: enc, timeout: 20000 }); } catch (e) { resp = null; }
        await enc.close();
        if (!resp || resp.error || (resp.code && resp.code >= 300)) { try { await enc.delete(); } catch (e2) { } return null; }
        await enc.open('r');
        const sz = await enc.size();
        const bin = sz > 0 ? await enc.read(sz, 0) : null;
        await enc.close();
        try { await enc.delete(); } catch (e3) { }
        let u8 = binToU8(bin);
        if (!u8 || !u8.length) return null;
        if (!src.size) {
            const cr = mcHeader(resp, 'content-range');
            if (cr && cr.indexOf('/') > -1) src.size = parseInt(cr.split('/')[1], 10) || 0;
        }
        // 服务端忽略 Range 回 200（整文件）：切出请求区间
        if (resp.code !== 206 && len && u8.length > len) u8 = u8.subarray(start, start + len);
        return u8;
    } catch (e) {
        console.log('[牛牛视频] ' + '[短剧] bcReadFile 异常：' + (e && e.message ? e.message : e));
        try { if (enc) await enc.close(); } catch (e2) { }
        try { if (enc) await enc.delete(); } catch (e3) { }
        return null;
    }
}
// 裸通道：buffer 3→1（cat）/ 3→1→2（其余）逐级试；fongmi buffer:3=byte[] 一次深拷贝、1=逐字节装箱
function bcReadPlain(src, h, len, start) {
    let modes = cat ? [3, 1] : [3, 1, 2];
    if (typeof MC_BUF.v === 'number') modes = [MC_BUF.v].concat(modes.filter(function (x) { return x !== MC_BUF.v; }));
    let lastErr = null;
    const tryAt = function (i) {
        if (i >= modes.length) {
            console.log('[牛牛视频] ' + '[短剧] 上游字节读取全通道失败 模式=' + modes.join('/') + (lastErr ? (' 末次异常=' + lastErr) : ''));
            return null;
        }
        let r = null;
        try { r = req(src.u, { headers: h, buffer: modes[i], timeout: 20000 }); } catch (e) { lastErr = e; r = null; }
        if (r && typeof r.then === 'function') {
            return r.then(function (x) {
                const got = mcPick(src, x, modes[i], start, len);
                if (got) { if (typeof MC_BUF.v !== 'number') MC_BUF.v = modes[i]; return got; }
                return tryAt(i + 1);
            }, function (e) {                       // ★ 该路失败只降级，不炸整链
                lastErr = (e && e.message) ? e.message : e;
                return tryAt(i + 1);
            });
        }
        const got = mcPick(src, r, modes[i], start, len);
        if (got) { if (typeof MC_BUF.v !== 'number') MC_BUF.v = modes[i]; return got; }
        return tryAt(i + 1);
    };
    return tryAt(0);
}
function mcPick(src, r, mode, start, len) {
    if (!r) return null;
    const code = parseInt(r.code, 10) || 0;
    if (code >= 300 && code !== 206) return null;
    let u8 = mcBytes(r, mode);
    if (!u8 || !u8.length) return null;
    if (!src.size) {
        const cr = mcHeader(r, 'content-range');
        if (cr && cr.indexOf('/') > -1) src.size = parseInt(cr.split('/')[1], 10) || 0;
        else if (code === 200) src.size = u8.length;
    }
    // 服务端忽略 Range 回 200（整文件）：切出请求区间
    if (code === 200 && len && u8.length > len) u8 = u8.subarray(start, start + len);
    return u8;
}

// ---- 播放期响应 ----
// ★★ Range 头有三个来源（桌面版猫影视实测 argc=3、第 2 参为空头对象，Range 是否落在第 3 参待真机日志定论）：
//   ① 老数组通道（fongmi/OK影视）：`Proxy.java` 把请求头 putAll 进 params ⇒ `params.range`
//   ② proxy() 第 2 参（央视片库同款签名 proxy(params, headers)）
//   ③ proxy() 第 3 参（桌面版猫影视实际传了 3 个参数）
function mcRange(params, reqHdrs, extra) {
    const pick = function (o) {
        if (!o || typeof o !== 'object' || Array.isArray(o)) return '';
        for (const k in o) if (String(k).toLowerCase() === 'range') return String(o[k] == null ? '' : o[k]);
        return '';
    };
    let v = pick(reqHdrs);
    if (v) return v;
    v = pick(extra);
    if (v) return v;
    v = pick(params);
    if (v) return v;
    return pick(params && params.headers);
}
function mcResp(u8, s, e, tot, hasRange) {
    // ★ 只要请求带了 Range 就必须回 206 + Content-Range（哪怕区间正好是 0..tot-1）：
    //   回 200 会让 ExoPlayer/ffmpeg 认为服务端不支持分段，后续 seek 行为异常（实测 ffmpeg 会发出越界 Range 直至 416 刷屏）。
    const isRange = !!hasRange;
    const code = isRange ? 206 : 200;
    const hdrs = { 'Content-Type': 'video/mp4', 'Accept-Ranges': 'bytes', 'connection': 'close' };
    if (isRange) hdrs['Content-Range'] = 'bytes ' + s + '-' + e + '/' + tot;
    // ★ 形态按「这次走哪条通道」定（RESP.json），不能只看壳身份：
    //   猫影视也可能走老数组通道（proxy1），那时必须回数组；反过来非猫影视永远不回流对象。
    if (!RESP.json) return [code, 'video/mp4', b64FromBytes(u8), hdrs, 1];
    if (cat && typeof JSProxyStream === 'function') return mcStream(u8, code, hdrs);
    return JSON.stringify({ code: code, buffer: 2, content: b64FromBytes(u8), headers: hdrs });
}
// 猫影视的零 base64 通道（head 可自定义状态码/头，故 206 在这里也成立）
//   ★ 分块写：单次 st.write 灌 9~12MB 过大，且背压（rc=0）时要重试同一块，分块后重试代价小。
const MC_CHUNK = 512 * 1024;
function mcPut(st, chunk) {                    // 单块写入：先传 TypedArray，壳子不认再退 ArrayBuffer
    let rc;
    try { rc = st.write(chunk); } catch (e) {
        const ab = (chunk.byteOffset === 0 && chunk.byteLength === chunk.buffer.byteLength)
            ? chunk.buffer : chunk.buffer.slice(chunk.byteOffset, chunk.byteOffset + chunk.byteLength);
        rc = st.write(ab);
    }
    return (rc && typeof rc.then === 'function') ? rc : Promise.resolve(rc);
}
function mcWrite(st, u8, tag) {                // 循环灌数据（rc: 1=成功 0=背压 -1=已断开）
    let off = 0;
    const step = function () {
        (async function () {
            try {
                while (off < u8.length) {
                    const end = Math.min(off + MC_CHUNK, u8.length);
                    const chunk = (off === 0 && end === u8.length) ? u8 : u8.slice(off, end);
                    const rc = await mcPut(st, chunk);
                    if (rc === -1) return;
                    if (rc === 0) { setTimeout(step, 10); return; }
                    off = end;
                }
                await st.done();
                if (tag) console.log('[牛牛视频] ' + tag);
            } catch (we) { try { await st.error(we); } catch (e2) { } }
        })();
    };
    step();
}
function mcStream(u8, code, hdrs, tag) {
    const st = new JSProxyStream();
    st.head(code, hdrs);
    setTimeout(function () { mcWrite(st, u8, tag); }, 5);   // 先交作业，再灌数据（壳子 proxy 返回后不泵微任务）
    return { code: code, buffer: 3, content: st, headers: hdrs };
}

// Range 解析：'bytes=a-b' / 'bytes=a-' / 'bytes=-n' → {s,e}
function mcSpan(tot, rng) {
    let s = 0, e = tot - 1;
    if (rng) {
        const m = /bytes\s*=\s*(\d*)\s*-\s*(\d*)/i.exec(rng);
        if (m) {
            if (m[1] === '' && m[2] !== '') { s = Math.max(0, tot - parseInt(m[2], 10)); e = tot - 1; }
            else { s = parseInt(m[1], 10) || 0; if (m[2] !== '') e = Math.min(parseInt(m[2], 10), tot - 1); }
        }
    }
    return { s: s, e: e };
}
// ---- 解密产物块缓存（内存 Map，LRU 上限 128 块 × 1MB）----
// 桌面版猫影视实测：壳不透传 Range ⇒ 播放器每个请求都是全片，且并发 6 路同时到。
// 不做块缓存 = 同一片数据反复解密 6 遍（9MB × 6，QuickJS 纯 JS AES 0.4MB/s ⇒ 2 分钟级灾难）。
// 有块缓存 + 在途去重后：全片只解一遍，后续请求（重放/并发）直接内存命中。
const MC_BLK = 1024 * 1024;
const MC_MEM_MAX = 128;
const MC_GEN = { v: 0 };                       // 换集令牌：新 asset 一建就自增，旧集管道据此退役
function mcBlk(a, bi) {
    const s = bi * MC_BLK;
    if (s >= a.outSize) return Promise.resolve(null);
    const e = Math.min(s + MC_BLK, a.outSize);
    // ★★ 缓存必须挂在 asset（= 具体一集）上：挂全局的话，换集后未死透的旧管道会把旧集
    //    解密块按块号写进新集的 Map ⇒ 新集命中旧集数据 ⇒ 花屏/错乱。挂 asset 上天然隔离。
    const mem = a.mem || (a.mem = new Map());
    const hit = mem.get(bi);
    if (hit) return Promise.resolve(hit);
    const inflight = a.inflight || (a.inflight = {});
    if (inflight[bi]) return inflight[bi];
    const p = MP4C.read(a, s, e).then(function (u8) {
        delete inflight[bi];
        if (u8 && u8.length === e - s) {
            mem.set(bi, u8);
            if (mem.size > MC_MEM_MAX) mem.delete(mem.keys().next().value);   // LRU 淘汰最旧块
        }
        return u8;
    }, function (e2) { delete inflight[bi]; throw e2; });
    inflight[bi] = p;
    return p;
}
// 猫影视同步流式：**proxy() 一返回壳子就把响应对象取走**，流对象与 head() 必须在那之前建好，
//   否则 head 落在微任务里、壳子已经按空响应收工（症状 = 播放失败 / 空体）。
//   ⇒ 索引在 play() 阶段预热（srcDjzy 里 await mcAsset），这里只同步读缓存、同步建流，数据异步灌。
//   响应形态照央视片库同壳实证款：{ buffer:3, content:stream }；头小写 + content-length（缺它 mpv 认定不可 seek）。
function mp4Cat(a, params, rh, extra) {
    const tot = a.outSize;
    const rng = mcRange(params, rh, extra);
    const sp = mcSpan(tot, rng);
    const t0 = Date.now();
    if (sp.s >= tot) { console.log('[牛牛视频] ' + '[短剧] 416 (cat) range=' + rng + ' tot=' + tot); return respRange416(tot); }
    const code = rng ? 206 : 200;
    const hdrs = { 'connection': 'close', 'content-type': 'video/mp4', 'accept-ranges': 'bytes', 'content-length': String(sp.e - sp.s + 1) };
    if (rng) hdrs['content-range'] = 'bytes ' + sp.s + '-' + sp.e + '/' + tot;
    const st = new JSProxyStream();
    try { st.head(code, hdrs); } catch (e) { console.log('[牛牛视频] ' + '[短剧] head 异常：' + e); return respErr(500); }
    mp4Pipe(a, st, sp.s, sp.e, code, t0, tot);
    return { buffer: 3, content: st };
}
// 流水线管道：1MB 一块「解密→写流」，首块解完即出画面，不等全片（9MB 纯 JS AES ≈ 21s，整片解完再写必超时）。
// write 返回值（drpy-node/quickjs 规范，央视片库同壳实证）：1=成功 0=背压(延时重试同一块) -1=播放器已断开。
function mp4Pipe(a, st, s, e, code, t0, tot) {
    const b0 = Math.floor(s / MC_BLK), b1 = Math.floor(e / MC_BLK);
    let bi = b0;
    const step = function () {
        (async function () {
            try {
                while (bi <= b1) {
                    const cur = bi;
                    let u8 = await mcBlk(a, cur);
                    if (a.gen !== MC_GEN.v) return;      // ★ 换集：旧管道立即退役，不再写流/抢上游/CPU
                    if (!u8 || !u8.length) throw new Error('块读取失败 bi=' + cur);
                    const bs = cur * MC_BLK;
                    let off0 = 0, off1 = u8.length;
                    if (s > bs) off0 = s - bs;                       // 首块切头
                    if (e < bs + u8.length - 1) off1 = e - bs + 1;   // 末块切尾
                    if (off1 > off0) {
                        const rc = await mcPut(st, off0 === 0 && off1 === u8.length ? u8 : u8.subarray(off0, off1));
                        if (rc === -1) return;
                        if (rc === 0) { setTimeout(step, 10); return; }   // 背压：bi 未推进，重试同一块
                    }
                    bi = cur + 1;
                }
                await st.done();
                console.log('[牛牛视频] ' + '[短剧] cat ' + code + ' ' + s + '-' + e + '/' + tot + ' 灌完 ' + (Date.now() - t0) + 'ms');
            } catch (we) {
                console.log('[牛牛视频] ' + '[短剧] 管道异常：' + (we && we.message ? we.message : we));
                try { await st.error(we); } catch (e2) { }
            }
        })();
    };
    step();
}

// ★ runtime 1.0.7+ 新增 {$tvStream} 流式回传（netStreamBody/_streamBody → 壳子 proxyResponse
//   判 length==1 且含 $tvStream → invocation.takeStream → 懒加载 ProxyBody 每次拉 64KB、单块 30s 超时）。
//   fongmi 261026 实测：老数组通道必须整段解密完才回第一字节（无 Range 时整片 9MB 纯 JS AES ≈15s
//   ⇒ 播放器等不到响应头提前断开，NanoHTTPD 写响应 Broken pipe，logcat proxy owner=14863ms 实证）。
//   1.0.5 无 _streamBody（dex 字符串扫描 0 命中），typeof netStreamBody === 'function' 即能力探测。
//   注意只回 {$tvStream: token} 裸对象：带 close 等多余键会让壳子判定 length!=1 而拒走流式。
function mp4StreamGen(a, s, e, t0, tot, code) {
    const gen0 = a.gen;
    const b0 = Math.floor(s / MC_BLK), b1 = Math.floor(e / MC_BLK);
    let sent = 0;
    return (async function* () {
        try {
            for (let bi = b0; bi <= b1; bi++) {
                const u8 = await mcBlk(a, bi);
                if (a.gen !== gen0 || a.gen !== MC_GEN.v) { console.log('[牛牛视频] ' + '[短剧] stream 换集退役 ' + s + '-' + e); return; }
                if (!u8 || !u8.length) throw new Error('块读取失败 bi=' + bi);
                const bs = bi * MC_BLK;
                let off0 = 0, off1 = u8.length;
                if (s > bs) off0 = s - bs;                       // 首块切头
                if (e < bs + u8.length - 1) off1 = e - bs + 1;   // 末块切尾
                if (off1 > off0) { const c = u8.subarray(off0, off1); sent += c.length; yield c; }
            }
            console.log('[牛牛视频] ' + '[短剧] stream ' + code + ' ' + s + '-' + e + '/' + tot + ' 灌完 ' + sent + 'B ' + (Date.now() - t0) + 'ms');
        } catch (we) {
            console.log('[牛牛视频] ' + '[短剧] 流异常：' + (we && we.message ? we.message : we));
            throw we;                                            // 壳子 pull 收到异常 ⇒ 流中止，播放器自然报错
        }
    })();
}
function mp4StreamResp(a, params, rh, extra) {
    const tot = a.outSize;
    const rng = mcRange(params, rh, extra);
    const sp = mcSpan(tot, rng);
    if (sp.s >= tot) { console.log('[牛牛视频] ' + '[短剧] 416 (stream) range=' + rng + ' tot=' + tot); return respRange416(tot); }
    const code = rng ? 206 : 200;
    const hdrs = { 'content-type': 'video/mp4', 'accept-ranges': 'bytes', 'connection': 'close', 'content-length': String(sp.e - sp.s + 1) };
    if (rng) hdrs['content-range'] = 'bytes ' + sp.s + '-' + sp.e + '/' + tot;
    const body = netStreamBody(mp4StreamGen(a, sp.s, sp.e, Date.now(), tot, code));
    console.log('[牛牛视频] ' + '[短剧] stream 就绪 ' + code + ' ' + sp.s + '-' + sp.e + '/' + tot + ' 索引' + (a.buildMs || 0) + 'ms');
    return [code, 'video/mp4', { $tvStream: body.stream.$tvStream }, hdrs];
}

// 短剧加密 mp4 代理主流程：按 Range 惰性解密（不落盘、可 seek）
function handleMp4(arg, params, rh, extra) {
    const o = toJson(b64uDec(arg));
    if (!o || !o.u) { console.log('[牛牛视频] ' + '[短剧] payload 解析失败 len=' + String(arg || '').length); return respErr(500); }
    const keyHex = String(o.k || '').toLowerCase();
    if (!/^[0-9a-f]{32}$/.test(keyHex)) { console.log('[牛牛视频] ' + '[短剧] key 非法：' + String(o.k || '').slice(0, 40)); return respErr(500); }
    const t0 = Date.now();
    // 猫影视：一律 JSProxyStream 管道；未预热则代理内异步建索引（同壳央视片库实证：/jp/ 处理器会 await Promise）
    if (RESP.json && cat && typeof JSProxyStream === 'function') {
        if (MC_CACHE.a && MC_CACHE.k === keyHex) return mp4Cat(MC_CACHE.a, params, rh, extra);
        console.log('[牛牛视频] ' + '[短剧] 索引未预热，代理内异步构建（壳会 await）');
        return seq2(mcAsset(o.u, keyHex), function (a) { return mp4Cat(a, params, rh, extra); });
    }
    // ★ fongmi 261026 + runtime 1.0.7：{$tvStream} 流式通道 —— proxy() 秒回响应头，解密块按需拉取
    if (!cat && typeof netStreamBody === 'function') {
        return seq2(mcAsset(o.u, keyHex), function (a) { return mp4StreamResp(a, params, rh, extra); });
    }
    const st = mcAsset(o.u, keyHex);
    return seq2(st, function (a) {
        const tot = a.outSize;
        const rng = mcRange(params, rh, extra);
        const sp = mcSpan(tot, rng);
        let s = sp.s, e = sp.e;
        if (s >= tot) { console.log('[牛牛视频] ' + '[短剧] 416 range=' + rng + ' tot=' + tot); return respRange416(tot); }
        // ★ 老通道无流式回传（OK影视/旧fongmi）：开区间会整片解密+base64（10MB ≈10s，真机实证
        //   OK 5.1.6 本次9615ms / OK 3.0.3 本次8309ms → 播放器等不到首字节退出 → NanoHTTPD Broken pipe）。
        //   修法 = 206 合法短回按 MC_CAP 封顶：播放器拿首块即开播，后续 Range 命中已解密块缓存增量续供
        //   （解密 ~1.3MB/s ≫ 短剧码率）。封顶不依赖请求带 Range —— OK 3.0.3 老 ExoPlayer 首开不带
        //   Range 头（真机 logcat：p0 无 range 键），无 Range 大文件同样回 206 + Content-Range 总长，
        //   ExoPlayer 认 206、读完首块后自动带 Range 续拉（与 5.1.6 续供机制一致）；截断的 200 是非法
        //   响应所以改回 206，不能回 200 短体。
        let partial = !!rng;
        if (e - s + 1 > MC_CAP) {
            const e2 = Math.min(s + MC_CAP - 1, tot - 1);
            console.log('[牛牛视频] ' + '[短剧] 老通道封顶' + (rng ? '' : '(无Range→206)') + ' ' + s + '-' + e + ' → ' + s + '-' + e2 + '/' + tot + ' cap=' + MC_CAP);
            e = e2; partial = true;
        }
        return seq2(MP4C.read(a, s, e + 1), function (u8) {
            console.log('[牛牛视频] ' + '[短剧] ' + (partial ? '206' : '200') + ' ' + s + '-' + e + '/' + tot
                + ' out=' + u8.length + 'B 索引' + a.buildMs + 'ms 本次' + (Date.now() - t0) + 'ms');
            return mcResp(u8, s, e, tot, partial);
        });
    });
}
function respRange416(tot) {
    const h = { 'connection': 'close', 'content-range': 'bytes */' + tot, 'content-length': '0' };
    if (!RESP.json) return [416, 'video/mp4', '', h, 1];
    if (cat && typeof JSProxyStream === 'function') return mcStream(new Uint8Array(0), 416, h);
    return JSON.stringify({ code: 416, buffer: 2, content: '', headers: h });
}
// asset 缓存：一集一个 key，命中即复用（等价 APP 的 short-drama-cache 命中）
// ★ 并发首包（播放器会同时发多个 Range）必须复用同一个构建 Promise，否则每次都重拉 180KB moov
//   mem/inflight 不放这里：它们挂在 asset 上（a.mem/a.inflight），换集天然隔离，绝不跨集串块。
const MC_CACHE = { k: '', a: null, p: null };
// 老通道单次响应封顶：2MB（解密 ~1.5s + base64 ~0.5s；≈8-10s 短剧视频量，后续 Range 走块缓存续供）
const MC_CAP = 2 * 1024 * 1024;
function mcAsset(url, keyHex) {
    if (MC_CACHE.a && MC_CACHE.k === keyHex) return MC_CACHE.a;
    if (MC_CACHE.p && MC_CACHE.k === keyHex) return MC_CACHE.p;
    MC_CACHE.k = keyHex;
    MC_CACHE.a = null;
    const t0 = Date.now();
    const src = { u: url, ua: HDR['User-Agent'], size: 0 };
    src.read = function (s, e) { src._reqLen = e - s + 1; return bcRead(src, s, e); };
    const a = MP4C.newAsset(function (s, e) {
        return seq2(src.read(s, e), function (u8) { if (!a.size && src.size) a.size = src.size; return u8; });
    }, 0, keyHex);
    a.url = url;
    a.gen = ++MC_GEN.v;                 // 换集令牌：旧集所有管道在下一块边界自动退役
    a.mem = null; a.inflight = null;    // 解密块缓存 / 在途去重，按集隔离
    MC_CACHE.p = seq2(MP4C.build(a), function (x) {
        x.buildMs = Date.now() - t0;
        x.size = src.size;
        MC_CACHE.a = x;
        MC_CACHE.p = null;
        console.log('[牛牛视频] ' + '[短剧] 索引就绪 ' + x.buildMs + 'ms 源=' + src.size + 'B 输出=' + x.outSize
            + 'B moov ' + x.moov.n + '→' + x.newMoov.length + ' delta=' + x.delta
            + ' samples=' + x.sOff.length + ' 通道=' + MC_BUF.v);
        return x;
    });
    return MC_CACHE.p;
}
// ==== MP4CENC-END ====
function lineSrc(line) {
    if (line === 'xm3u8' || line === 'xiaocao') return 'src7';
    if (line === 'hema') return 'src2';
    return '';
}
function isPlaceholder(text) { return String(text).indexOf('ydsp.skzsz.com') > -1; }

// m3u8：在各候选 CDN 上取播放列表（replaceDomain 优先，每个域名配自己的盐），
// 取到非防盗占位的即为可用；分片改写成本地代理 URL，播放时现签。
// ★★ 必须尽量**同步返回**：OK影视 3.0.3 的 proxyLocal 直接 call 后强转 JSArray，
//    拿到 Promise 就 ClassCastException（表现为「代理全部播不了」）。真壳的 req 同步阻塞，
//    这里同步走完；只有本地 wrapper（async req）才在首个请求处降级成 Promise。
function handleM3u8(arg) {
    const o = toJson(b64uDec(arg));
    if (!o || !o.u) { console.log('[牛牛视频] ' + '[短剧] payload 解析失败 len=' + String(arg || '').length); return respErr(500); }
    const line = String(o.l || '');
    if (line === 'shizi') return handleM3u8Shizi(String(o.u));   // 臻享仅猫影视会生成，链路本身是异步的
    const srcType = lineSrc(line);
    if (!srcType) return respErr(500);
    const srcCache = C.src[srcType] || {};
    const salt0 = String(o.s || '');
    const rawUrl = String(o.u);
    const q = rawUrl.indexOf('?');
    const ck = q > -1 ? rawUrl.slice(q + 1) : '';
    const noQ = q > -1 ? rawUrl.slice(0, q) : rawUrl;
    const m = noQ.match(/^(https?:\/\/[^/]+)(\/.*)?$/i);
    const origin = m ? m[1] : '';
    const rel = m ? (m[2] || '') : '';
    const cands = cdnCandidatesSync(origin, salt0, srcCache.replaceDomain || '');
    let content = '', used = null;
    for (let i = 0; i < cands.length && !content; i++) {
        const host = cands[i].host, salt = cands[i].salt || salt0;
        for (let att = 0; att < 2 && !content; att++) {        // CDN 偶发超时/限流，重试一次
            let r = null;
            const tmp = host + rel + (ck ? '?' + ck : '');
            try { r = req(hlsSign(tmp, salt), { headers: ph(), timeout: 15000 }); } catch (e) { continue; }
            if (r && typeof r.then === 'function') {           // 异步 req（本地 wrapper）：只带这一条候选降级
                return r.then(function (x) { return finishM3u8(contentToText(x), cands[i], rel, salt0, ck); },
                    function () { return respErr(500); });
            }
            const text = contentToText(r);
            if (text && text.indexOf('#EXTM3U') > -1 && !isPlaceholder(text)) { content = text; used = cands[i]; }
        }
    }
    if (!content) { console.log('[牛牛视频] ' + '[代理] M3U8为空（全部候选 CDN 均失败或返回防盗占位）'); return respErr(500); }
    return finishM3u8(content, used, rel, salt0, ck);
}

// 分片改写：同一个 m3u8 的切片逐个生成代理地址；proxyUrl 若返回 Promise（本地 wrapper 的 js2Proxy）则整段降级
//   cand：实际取到清单的候选（分片必须回到**同一个 CDN**）；rel：原 m3u8 的路径（只有它带目录，相对分片要拼在它后面）
function finishM3u8(text, cand, rel, salt0, ck) {
    if (!text) return respErr(500);
    const mHost = String(cand.host || '').match(/^(https?:\/\/[^/]+)/i);
    const origin = mHost ? mHost[1] : '';
    const baseDir = String(rel || '').slice(0, String(rel || '').lastIndexOf('/') + 1);
    const usedSalt = cand.salt || salt0;
    const out = [], lines = String(text).split('\n');
    for (let i = 0; i < lines.length; i++) {
        const t = lines[i].trim();
        if (t && t.charAt(0) !== '#') {
            // 分片按客户端真实请求重建：丢弃播放列表里带的 m8/sz，只保留 ck 并现签
            const segPath = /^https?:\/\//i.test(t) ? pathOf(t) : (baseDir + t.split('?')[0]);
            const target = origin + segPath + (ck ? '?' + ck : '');
            out.push(proxyUrlSync('TS-' + b64uEnc(JSON.stringify({ s: usedSalt, u: target }))));
        } else {
            out.push(lines[i]);
        }
    }
    if (out.some(function (x) { return x && typeof x.then === 'function'; })) {
        return Promise.all(out).then(function (a) {
            return respText(200, a.join('\n'), 'application/vnd.apple.mpegurl');
        });
    }
    return respText(200, out.join('\n'), 'application/vnd.apple.mpegurl');
}

// ts：302 到现签地址（签名只与「盐 + 路径」有关；wsTime 有效期约 5 分钟，必须每次现签）
// 臻享分片（l='shizi'）是 PNG 内嵌 TS 的异步解密链路，单独派发
function handleTs(arg) {
    const o = toJson(b64uDec(arg));
    if (!o || !o.u) { console.log('[牛牛视频] ' + '[短剧] payload 解析失败 len=' + String(arg || '').length); return respErr(500); }
    if (o.l === 'shizi') return handleTsShizi(o);
    const loc = hlsSign(String(o.u), String(o.s || ''));
    if (!RESP.json) return [302, 'text/html; charset=utf-8', '', { 'Location': loc, 'Content-Length': '0' }, 0];
    return JSON.stringify({ code: 302, content: '', headers: { 'Location': loc } });
}

// ★★ 签名必须带第 2 参：猫影视壳调用的是 **proxy(segments, headers)** —— 第 1 参是路径段数组，
//    播放器的 `Range` 在**第 2 参数**里。只声明一个形参 ⇒ 猫影视永远读不到 Range。
// 轻量类型描述（诊断日志用，单参 console.log 走壳 stdout，零网络开销）
function nbTyp(v) {
    try {
        if (v === null || v === undefined) return String(v);
        const t = typeof v;
        if (t === 'string') return 'str#' + v.length;
        if (Array.isArray(v)) return 'arr#' + v.length;
        if (t === 'object') {
            if (typeof v.byteLength === 'number') return ((v.constructor && v.constructor.name) || 'View') + '#' + v.byteLength;
            return 'obj{' + Object.keys(v).slice(0, 12).join(',') + '}';
        }
        return t;
    } catch (e) { return '?'; }
}
function proxy(params, reqHdrs, extra) {       // 桌面版猫影视实际传 3 参（argc=3 实证）；fongmi 旧 fork 不解 Promise
    try {
        // 新版 runtime 的 proxy1 传参可能是 params 全量 JSON 字符串（央视片库同款归一）
        if (typeof params === 'string' && params.charAt(0) === '{') {
            try { params = JSON.parse(params); } catch (e1) { }
        }
        // 诊断：第 2/3 参形态决定猫影视 Range 能否透传（console.log → 壳 stdout，不占网络）
        try {
            const rv = mcRange(params, reqHdrs, extra);
            console.log('[NB] proxy argc=' + arguments.length + ' p0=' + nbTyp(params) + ' p1=' + nbTyp(reqHdrs)
                + ' p2=' + nbTyp(extra) + ' range=' + (rv || '-') + ' cat=' + cat);
        } catch (e0) { }
        RESP.json = !isProxy1(params);
        const payload = readPayload(params);
        // ★ 普通链路（m3u8 改写 / ts 302）必须同步返回，只有臻享解密链路才可能是 Promise
        if (payload.indexOf('MP4-') === 0) {          // 短剧加密 mp4：按播放器 Range 惰性解密
            return thenOf(handleMp4(payload.slice(4), params, reqHdrs, extra), function (r) { return r; },
                function (e) { console.log('[牛牛视频] ' + '[短剧] 代理异常：' + (e && e.message ? e.message : e)); return respErr(500); });
        }
        if (payload.indexOf('M3U8-') === 0) {
            return thenOf(handleM3u8(payload.slice(5)), function (r) { return r; });
        }
        if (payload.indexOf('TS-') === 0) {
            return thenOf(handleTs(payload.slice(3)), function (r) { return r; });
        }
        return respErr(500);
    } catch (e) {
        console.log('[牛牛视频] ' + 'proxy: ' + e);
        return respErr(500);
    }
}

export function __jsEvalReturn() {
    return { init, home, homeVod, category, search, detail, play, proxy };
}
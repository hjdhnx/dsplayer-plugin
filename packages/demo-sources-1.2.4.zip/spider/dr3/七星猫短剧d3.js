/*
@header({
  title: '七星七猫好看短剧',
  lang: 'dr3',
  searchable: 2, filterable: 1, quickSearch: 0,
})

【七星七猫好看短剧｜drpy3 三合一采集】
- 整合七星(app.whjzjx.cn)、七猫(api-store.qmplaylet.com)、好看(sv.baidu.com)三个短剧平台
- 七星：AES-ECB 登录获取 token，分类/列表/详情/播放全链路
- 七猫：MD5 签名 + qm-params 编码，分类/列表/详情/播放全链路
- 好看：百度公开 API，首页/分类/详情/搜索
- 一级分类混合展示，七猫支持 tag 子分类筛选
- 播放直接返回各平台直链（七星 video_url、七猫 video_url、好看 clarityUrl 优选）
*/

// ═══════════════════════════════════════
//  平台常量
// ═══════════════════════════════════════

const QX_BASE_URL = 'https://app.whjzjx.cn';
const QX_AES_KEY = 'B@ecf920Od8A4df7';

const QM_BASE_URL = 'https://api-store.qmplaylet.com';
const QM_BASE_URL2 = 'https://api-read.qmplaylet.com';
const QM_KEYS = 'd3dGiJc651gSQ8w1';

const HK_BASE_URL = 'https://sv.baidu.com';

// 七猫字符映射表
const QM_CHAR_MAP = {
    '+': 'P', '/': 'X', '0': 'M', '1': 'U', '2': 'l', '3': 'E', '4': 'r',
    '5': 'Y', '6': 'W', '7': 'b', '8': 'd', '9': 'J', 'A': '9', 'B': 's',
    'C': 'a', 'D': 'I', 'E': '0', 'F': 'o', 'G': 'y', 'H': '_', 'I': 'H',
    'J': 'G', 'K': 'i', 'L': 't', 'M': 'g', 'N': 'N', 'O': 'A', 'P': '8',
    'Q': 'F', 'R': 'k', 'S': '3', 'T': 'h', 'U': 'f', 'V': 'R', 'W': 'q',
    'X': 'C', 'Y': '4', 'Z': 'p', 'a': 'm', 'b': 'B', 'c': 'O', 'd': 'u',
    'e': 'c', 'f': '6', 'g': 'K', 'h': 'x', 'i': '5', 'j': 'T', 'k': '-',
    'l': '2', 'm': 'z', 'n': 'S', 'o': 'Z', 'p': '1', 'q': 'V', 'r': 'v',
    's': 'j', 't': 'Q', 'u': '7', 'v': 'D', 'w': 'w', 'x': 'n', 'y': 'L',
    'z': 'e'
};

// ═══════════════════════════════════════
//  工具函数
// ═══════════════════════════════════════

function _aesEncrypt(plainText, keyStr) {
    // 兼容 CryptoJS 和 Node crypto
    const keyBytes = typeof CryptoJS !== 'undefined'
        ? CryptoJS.enc.Utf8.parse(keyStr)
        : null;
    
    if (typeof CryptoJS !== 'undefined' && CryptoJS.AES) {
        const encrypted = CryptoJS.AES.encrypt(plainText, keyBytes, {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
        return encrypted.toString();
    }
    
    // Node crypto fallback (ESM via globalThis)
    if (typeof globalThis !== 'undefined' && globalThis._nodeCrypto) {
        try {
            const crypto = globalThis._nodeCrypto;
            const key = Buffer.from(keyStr, 'utf-8');
            const plain = Buffer.from(plainText, 'utf-8');
            const cipher = crypto.createCipheriv('aes-128-ecb', key, null);
            cipher.setAutoPadding(true);
            let encrypted = cipher.update(plain);
            encrypted = Buffer.concat([encrypted, cipher.final()]);
            return encrypted.toString('base64');
        } catch (e) {
            throw new Error('AES encrypt failed: ' + e.message);
        }
    }
    
    if (typeof require !== 'undefined') {
        try {
            const crypto = require('crypto');
            const key = Buffer.from(keyStr, 'utf-8');
            const plain = Buffer.from(plainText, 'utf-8');
            const cipher = crypto.createCipheriv('aes-128-ecb', key, null);
            cipher.setAutoPadding(true);
            let encrypted = cipher.update(plain);
            encrypted = Buffer.concat([encrypted, cipher.final()]);
            return encrypted.toString('base64');
        } catch (e) {
            throw new Error('AES encrypt failed: ' + e.message);
        }
    }
    
    throw new Error('No crypto library available');
}

function _md5(str) {
    if (typeof CryptoJS !== 'undefined' && CryptoJS.MD5) {
        return CryptoJS.MD5(str).toString();
    }
    if (typeof require !== 'undefined') {
        try {
            const crypto = require('crypto');
            return crypto.createHash('md5').update(str).digest('hex');
        } catch (e) {}
    }
    // Node ESM fallback: try global crypto
    if (typeof globalThis !== 'undefined' && globalThis._nodeCrypto) {
        return globalThis._nodeCrypto.createHash('md5').update(str).digest('hex');
    }
    throw new Error('No MD5 library available');
}

function _encodeQmParams(data) {
    const jsonStr = JSON.stringify(data);
    let encoded;
    if (typeof CryptoJS !== 'undefined' && CryptoJS.enc.Base64) {
        encoded = CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(jsonStr));
    } else {
        encoded = Buffer.from(jsonStr).toString('base64');
    }
    let result = '';
    for (const c of encoded) {
        result += (QM_CHAR_MAP[c] || c);
    }
    return result;
}

function _uuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
}

// ═══════════════════════════════════════
//  七星认证
// ═══════════════════════════════════════

async function _qxLogin(ctx) {
    const req = ctx.lib.net.request || ctx.lib.net.req;
    if (!req) throw new Error('No request function');
    
    const times = Date.now();
    const data = {
        device: '2a50580e69d38388c94c93605241fb306',
        package_name: 'com.jz.xydj',
        android_id: 'ec1280db12795506',
        install_first_open: true,
        first_install_time: 1752505243345,
        last_update_time: 1752505243345,
        report_link_url: '',
        authorization: '',
        timestamp: times
    };
    
    const plainText = JSON.stringify(data);
    const encrypted = _aesEncrypt(plainText, QX_AES_KEY);
    
    const res = await req('https://u.shytkjgs.com/user/v3/account/login', {
        method: 'POST',
        headers: {
            platform: '1',
            user_agent: 'Mozilla/5.0 (Linux; Android 9; V1938T Build/PQ3A.190705.08211809; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Safari/537.36',
            'content-type': 'application/json; charset=utf-8'
        },
        body: encrypted,
        timeout: 10000
    });
    
    const j = JSON.parse(res.content || '{}');
    if (j.code === 'ok' && j.data && j.data.token) {
        return j.data.token;
    }
    return null;
}

// ═══════════════════════════════════════
//  七猫认证
// ═══════════════════════════════════════

function _qmHeaders() {
    const sessionId = String(Date.now());
    const qmData = {
        'static_score': '0.8',
        'uuid': '00000000-7fc7-08dc-0000-000000000000',
        'device-id': '20250220125449b9b8cac84c2dd3d035c9052a2572f7dd0122edde3cc42a70',
        'mac': '',
        'sourceuid': 'aa7de295aad621a6',
        'refresh-type': '0',
        'model': '22021211RC',
        'wlb-imei': '',
        'client-id': 'aa7de295aad621a6',
        'brand': 'Redmi',
        'oaid': '',
        'oaid-no-cache': '',
        'sys-ver': '12',
        'trusted-id': '',
        'phone-level': 'H',
        'imei': '',
        'wlb-uid': 'aa7de295aad621a6',
        'session-id': sessionId
    };
    
    const qmParams = _encodeQmParams(qmData);
    const paramsStr = (
        'AUTHORIZATION=' +
        'app-version=10001' +
        'application-id=com.duoduo.read' +
        'channel=unknown' +
        'is-white=' +
        'net-env=5' +
        'platform=android' +
        'qm-params=' + qmParams +
        'reg=' + QM_KEYS
    );
    const sign = _md5(paramsStr);
    
    return {
        'net-env': '5',
        'reg': '',
        'channel': 'unknown',
        'is-white': '',
        'platform': 'android',
        'application-id': 'com.duoduo.read',
        'authorization': '',
        'app-version': '10001',
        'user-agent': 'webviewversion/0',
        'qm-params': qmParams,
        'sign': sign
    };
}

function _qmSign(string) {
    return _md5(string);
}

// ═══════════════════════════════════════
//  好看工具
// ═══════════════════════════════════════

const HK_ORIGINAL_URL = 'https://sv.baidu.com/appui/api?cmd=video/commonlist&log=vhk&tn=1043677m&ctn=1043677m&blur=1&mac=&imei=AL5fB&cuid=B8B02D397EF5A5D8675FF92CDEDB833B%7C0&iid=A50-GZSWENRQHEZWMLJUHFSTALJUMYZDCLLBHEYWGLLCGZTDGNZQGBRGCOJQGE-OUABVLNI&c3_aid=A00-GGDKZORUQAP5GY6JC5BBPXTPVNC74IIA-V5QNYZSV&os=android&osbranch=a0&ua=900_1600_240&ut=V1938T_9_28_vivo&uh=vivo,qcom,V1938T&apiv=7.93.0.18&appv=793001&version=7.93.0.18&life=1773081846&clife=1773081846&nlife=1773081808&hid=empty&imsi=0&user_live_rec_source=yy,baijiahao,bjh_client,pc_client,bd_client&app_cpu_abi=64&device_prefer_abi=64&is_fold_screen=0&is_tablet=0&player_params=%7B%22ps%22:-1%7D&androidId=ec1280db12795506&zid=UW60kbyg6UiIf3uhVai1IDx_sCpGqcu19NSBuVuST5hB1Ho3bCpDReYbYo3zw3ZVdgFFLm7bHyMC7Kis_fOMAnA&network=1&sids=265_2-999990_2-999991_2-999989_2-999992_2-999988_2-999993_2-999999_72-123_2&young_mode=0&oaid=&honor_oaid=&nu=1&score=0.4330356&network5g=1&mpv=1&before_agree_sids=user_growth_15&fvt=1773081342&cp_isbg=0&is_playlet=1';

// ═══════════════════════════════════════
//  主模块
// ═══════════════════════════════════════

export default {
    meta: {
        title: '七星七猫好看短剧',
        host: 'https://app.whjzjx.cn',
        searchable: 2,
        filterable: 1,
        quickSearch: 0,
        multi: 1,
    },

    rule: {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 12; Pixel 3 XL) AppleWebKit/537.36 Chrome/98.0.4758.101 Mobile Safari/537.36',
        },
        timeout: 10000,
    },

    // 缓存
    _qxToken: null,
    _qmHeaders: null,
    _qmTags: [],

    // ═══ 初始化 ═══
    async _initQx(ctx) {
        if (!this._qxToken) {
            try {
                this._qxToken = await _qxLogin(ctx);
            } catch (e) {
                this._qxToken = null;
            }
        }
        return this._qxToken;
    },

    _initQm() {
        if (!this._qmHeaders) {
            this._qmHeaders = _qmHeaders();
        }
        return this._qmHeaders;
    },

    // ═══ 首页 ═══
    async home(ctx, filter) {
        const req = ctx.lib.net.request || ctx.lib.net.req;
        if (!req) throw new Error('No request function');

        const classes = [];
        const list = [];

        // === 七星分类 ===
        const qxToken = await this._initQx(ctx);
        if (qxToken) {
            classes.push(
                { type_id: 'qx_1', type_name: '七星-剧场' },
                { type_id: 'qx_3', type_name: '七星-新剧' },
                { type_id: 'qx_2', type_name: '七星-热播' },
                { type_id: 'qx_7', type_name: '七星-星选' },
                { type_id: 'qx_5', type_name: '七星-阳光' }
            );

            // 七星首页推荐
            try {
                const res = await req(`${QX_BASE_URL}/v1/theater/home_page?theater_class_id=1&class2_id=4&page_num=1&page_size=12`, {
                    headers: {
                        authorization: qxToken,
                        platform: '1',
                        version_name: '3.8.3.1'
                    },
                    timeout: 10000
                });
                const data = JSON.parse(res.content || '{}');
                if (data.data && data.data.list) {
                    for (const vod of data.data.list) {
                        list.push({
                            vod_id: 'qx_' + vod.theater.id,
                            vod_name: vod.theater.title,
                            vod_pic: vod.theater.cover_url,
                            vod_remarks: vod.theater.play_amount_str || '七星热播'
                        });
                    }
                }
            } catch (e) {}
        }

        // === 七猫分类 ===
        const qmHeaders = this._initQm();
        try {
            const signString = 'operation=1playlet_privacy=1tag_id=0' + QM_KEYS;
            const sign = _qmSign(signString);
            const url = `${QM_BASE_URL}/api/v1/playlet/index?tag_id=0&playlet_privacy=1&operation=1&sign=${sign}`;
            const res = await req(url, { headers: qmHeaders, timeout: 10000 });
            const data = JSON.parse(res.content || '{}');

            // 收集 tag 作为子分类
            const duoxuan = ['0', '1', '2', '3', '4'];
            for (const duo of duoxuan) {
                if (parseInt(duo) < (data.data.tag_categories || []).length) {
                    const tags = data.data.tag_categories[parseInt(duo)].tags || [];
                    for (const vod of tags) {
                        if (vod.tag_name && vod.tag_name.indexOf('推荐') === -1) {
                            classes.push({
                                type_id: 'qm_' + vod.tag_id,
                                type_name: '七猫-' + vod.tag_name
                            });
                            this._qmTags.push({ id: vod.tag_id, name: vod.tag_name });
                        }
                    }
                }
            }

            // 七猫首页推荐
            if (data.data.list) {
                for (const vod of data.data.list.slice(0, 12)) {
                    list.push({
                        vod_id: 'qm_' + vod.playlet_id,
                        vod_name: vod.title,
                        vod_pic: vod.image_link,
                        vod_remarks: vod.hot_value || '七猫热播'
                    });
                }
            }
        } catch (e) {}

        // === 好看分类 ===
        try {
            const res = await req(`${HK_BASE_URL}/haokan/ui-feed/playletShelfFeed`, {
                method: 'POST',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 8.0.0; zh-cn; Mi Note 2 Build/OPR1.170623.032) AppleWebKit/537.36 Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36',
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'data=%7B%22from%22%3A%22feed%22%7D',
                timeout: 10000
            });
            const data = JSON.parse(res.content || '{}');
            if (data.data && data.data.playlet_tags) {
                for (const vod of data.data.playlet_tags) {
                    classes.push({
                        type_id: 'hk_' + vod.tag_id,
                        type_name: '好看-' + vod.name
                    });
                }
                classes.push({ type_id: 'hk_2', type_name: '好看-新剧' });
            }

            // 好看首页推荐（从 banner 取）
            if (data.data && data.data.playlet_banner) {
                for (const vod of data.data.playlet_banner.slice(0, 6)) {
                    list.push({
                        vod_id: 'hk_' + vod.playlet_id,
                        vod_name: vod.playlet_title,
                        vod_pic: vod.playlet_poster,
                        vod_remarks: vod.episodes_num_text || '好看热播'
                    });
                }
            }
        } catch (e) {}

        return {
            class: classes,
            list: list,
            page: 1,
            pagecount: 1,
            limit: list.length,
            total: list.length
        };
    },

    // ═══ 分类 ═══
    async category(ctx, tid, pg, filter, extend) {
        const req = ctx.lib.net.request || ctx.lib.net.req;
        if (!req) throw new Error('No request function');

        const page = parseInt(pg) || 1;
        const list = [];

        if (tid.startsWith('qx_')) {
            const realCid = tid.replace('qx_', '');
            const qxToken = await this._initQx(ctx);
            if (qxToken) {
                try {
                    const res = await req(`${QX_BASE_URL}/v1/theater/home_page?theater_class_id=${realCid}&page_num=${page}&page_size=24`, {
                        headers: {
                            authorization: qxToken,
                            platform: '1',
                            version_name: '3.8.3.1'
                        },
                        timeout: 10000
                    });
                    const data = JSON.parse(res.content || '{}');
                    if (data.data && data.data.list) {
                        for (const vod of data.data.list) {
                            list.push({
                                vod_id: 'qx_' + vod.theater.id,
                                vod_name: vod.theater.title,
                                vod_pic: vod.theater.cover_url,
                                vod_remarks: vod.theater.theme || '七星'
                            });
                        }
                    }
                } catch (e) {}
            }
        } else if (tid.startsWith('qm_')) {
            const realCid = tid.replace('qm_', '');
            const qmHeaders = this._initQm();
            try {
                let signString, url;
                if (page === 1) {
                    signString = `operation=1playlet_privacy=1tag_id=${realCid}${QM_KEYS}`;
                    const sign = _qmSign(signString);
                    url = `${QM_BASE_URL}/api/v1/playlet/index?tag_id=${realCid}&playlet_privacy=1&operation=1&sign=${sign}`;
                } else {
                    signString = `next_id=${page}operation=1playlet_privacy=1tag_id=${realCid}${QM_KEYS}`;
                    const sign = _qmSign(signString);
                    url = `${QM_BASE_URL}/api/v1/playlet/index?tag_id=${realCid}&next_id=${page}&playlet_privacy=1&operation=1&sign=${sign}`;
                }
                const res = await req(url, { headers: qmHeaders, timeout: 10000 });
                const data = JSON.parse(res.content || '{}');
                if (data.data && data.data.list) {
                    for (const vod of data.data.list) {
                        list.push({
                            vod_id: 'qm_' + vod.playlet_id,
                            vod_name: vod.title,
                            vod_pic: vod.image_link,
                            vod_remarks: vod.hot_value || '七猫'
                        });
                    }
                }
            } catch (e) {}
        } else if (tid.startsWith('hk_')) {
            const realCid = tid.replace('hk_', '');
            try {
                const res = await req(`${HK_BASE_URL}/haokan/ui-feed/playletTagsFeed`, {
                    method: 'POST',
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Linux; U; Android 8.0.0; zh-cn; Mi Note 2 Build/OPR1.170623.032) AppleWebKit/537.36 Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36',
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `tag_id=${realCid}&pn=${page}&rn=24`,
                    timeout: 10000
                });
                const data = JSON.parse(res.content || '{}');
                if (data.data && data.data.list) {
                    for (const vod of data.data.list) {
                        list.push({
                            vod_id: 'hk_' + vod.playlet_id,
                            vod_name: vod.playlet_title,
                            vod_pic: vod.playlet_poster,
                            vod_remarks: vod.episodes_num_text || '好看'
                        });
                    }
                }
            } catch (e) {}
        }

        return {
            list: list,
            page: page,
            pagecount: 9999,
            limit: 90,
            total: 999999
        };
    },

    // ═══ 详情 ═══
    async detail(ctx, id) {
        const req = ctx.lib.net.request || ctx.lib.net.req;
        if (!req) throw new Error('No request function');

        let vod = null;

        if (id.startsWith('qx_')) {
            const realId = id.replace('qx_', '');
            const qxToken = await this._initQx(ctx);
            if (qxToken) {
                try {
                    const res = await req(`${QX_BASE_URL}/v2/theater_parent/detail?theater_parent_id=${realId}`, {
                        headers: {
                            authorization: qxToken,
                            platform: '1',
                            version_name: '3.8.3.1'
                        },
                        timeout: 10000
                    });
                    const data = JSON.parse(res.content || '{}');
                    if (data.data) {
                        const d = data.data;
                        let bofang = '';
                        let xianlu = '七星线路';

                        if (d.theaters && d.theaters.length > 0) {
                            for (const sou of d.theaters) {
                                const vid = sou.son_video_url;
                                const name = sou.num;
                                bofang += name + '$' + vid + '#';
                            }
                            bofang = bofang.slice(0, -1);
                        } else if (d.video_url) {
                            bofang = '1$' + d.video_url;
                        }

                        vod = {
                            vod_id: realId,
                            vod_name: d.title || '未知',
                            vod_content: (d.introduction || '暂无剧情').replace(/<[^>]+>/g, ''),
                            vod_remarks: d.filing || '未知',
                            vod_area: (d.desc_tags || ['未知'])[0],
                            vod_pic: d.cover_url || '',
                            vod_play_from: xianlu,
                            vod_play_url: bofang
                        };
                    }
                } catch (e) {}
            }
        } else if (id.startsWith('qm_')) {
            const realId = id.replace('qm_', '');
            const qmHeaders = this._initQm();
            try {
                const signString = `playlet_id=${realId}${QM_KEYS}`;
                const sign = _qmSign(signString);
                const url = `${QM_BASE_URL2}/player/api/v1/playlet/info?playlet_id=${realId}&sign=${sign}`;
                const res = await req(url, { headers: qmHeaders, timeout: 10000 });
                const detailData = JSON.parse(res.content || '{}');
                if (detailData.data) {
                    const d = detailData.data;
                    let bofang = '';
                    let xianlu = '七猫线路';

                    if (d.play_list && d.play_list.length > 0) {
                        for (const sou of d.play_list) {
                            bofang += sou.sort + '$' + sou.video_url + '#';
                        }
                        bofang = bofang.slice(0, -1);
                    }

                    const jisu = d.total_episode_num || '未知';
                    const leixing = d.tags || '未知';

                    vod = {
                        vod_id: realId,
                        vod_name: d.title || '未知',
                        vod_content: (d.intro || '暂无介绍').replace(/<[^>]+>/g, ''),
                        vod_remarks: leixing + ' ' + jisu + '全集',
                        vod_pic: d.image_link || d.cover || '',
                        vod_play_from: xianlu,
                        vod_play_url: bofang
                    };
                }
            } catch (e) {}
        } else if (id.startsWith('hk_')) {
            const realId = id.replace('hk_', '');
            try {
                // 好看的详情通过 video/commonlist 获取
                const parsedUrl = new URL(HK_ORIGINAL_URL);
                const queryParams = {};
                for (const [k, v] of parsedUrl.searchParams) {
                    queryParams[k] = v;
                }
                queryParams.cuid = _uuid().replace(/-/g, '').toUpperCase().slice(0, 32) + '%7C0';
                queryParams.androidId = _uuid().replace(/-/g, '').slice(0, 16);
                queryParams.zid = _uuid().replace(/-/g, '');

                const cleanedUrl = parsedUrl.origin + parsedUrl.pathname + '?' + Object.entries(queryParams).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');

                const currentTimestamp = String(Date.now());
                const innerParams = {
                    source_from: 'kanju_shelf_playlet',
                    enable_enter_playlet: '0',
                    seek_time: '0',
                    hotspot: '0',
                    page_value: 'playlet',
                    auto_show_hot_point_panel: '0',
                    type: 'playlet',
                    commonlist_id: currentTimestamp,
                    scene: '',
                    vid: '',
                    enable_atlas: '0',
                    mark_pn: '',
                    uk: '',
                    ctime: '0',
                    from: 'playlet_talos',
                    id: realId,
                    rn: '50',
                    pn: '1',
                    direction: '3'
                };
                const payload = { 'video/commonlist': Object.entries(innerParams).map(([k, v]) => `${k}=${v}`).join('&') };

                const res = await req(cleanedUrl, {
                    method: 'POST',
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Linux; U; Android 8.0.0; zh-cn; Mi Note 2 Build/OPR1.170623.032) AppleWebKit/537.36 Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36',
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: Object.entries(payload).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&'),
                    timeout: 10000
                });
                const responseJson = JSON.parse(res.content || '{}');
                const dataSection = (responseJson['video/commonlist'] || {}).data || {};
                const episodes = dataSection.list || dataSection.results || [];

                let bofang = '';
                for (const videoData of episodes) {
                    if (videoData.content && videoData.content.title) {
                        const name = videoData.content.title;
                        const clarityUrls = videoData.content.clarityUrl || [];
                        let vid = '';
                        if (clarityUrls.length > 2) {
                            vid = clarityUrls[2].url;
                        } else if (clarityUrls.length > 1) {
                            vid = clarityUrls[1].url;
                        } else if (clarityUrls.length > 0) {
                            vid = clarityUrls[0].url;
                        }
                        if (vid) {
                            bofang += name + '$' + vid + '#';
                        }
                    }
                }
                bofang = bofang.slice(0, -1);

                vod = {
                    vod_id: realId,
                    vod_name: '好看短剧',
                    vod_content: '好看短剧',
                    vod_remarks: '好看专线',
                    vod_play_from: '好看线路',
                    vod_play_url: bofang
                };
            } catch (e) {}
        }

        return { list: vod ? [vod] : [] };
    },

    // ═══ 搜索 ═══
    async search(ctx, wd, quick, pg) {
        const req = ctx.lib.net.request || ctx.lib.net.req;
        if (!req) throw new Error('No request function');

        const list = [];
        const page = parseInt(pg) || 1;

        // 七星搜索
        const qxToken = await this._initQx(ctx);
        if (qxToken) {
            try {
                const res = await req(`${QX_BASE_URL}/v3/search`, {
                    method: 'POST',
                    headers: {
                        authorization: qxToken,
                        platform: '1',
                        version_name: '3.8.3.1',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ text: wd }),
                    timeout: 10000
                });
                const data = JSON.parse(res.content || '{}');
                if (data.data && data.data.theater && data.data.theater.search_data) {
                    for (const vod of data.data.theater.search_data) {
                        list.push({
                            vod_id: 'qx_' + vod.id,
                            vod_name: vod.title,
                            vod_pic: vod.cover_url,
                            vod_remarks: vod.score_str || '七星'
                        });
                    }
                }
            } catch (e) {}
        }

        // 七猫搜索
        const qmHeaders = this._initQm();
        try {
            const signString = `extend=page=${page}read_preference=0track_id=ec1280db127955061754851657967wd=${wd}${QM_KEYS}`;
            const sign = _qmSign(signString);
            const url = `${QM_BASE_URL}/api/v1/playlet/search?extend=&page=${page}&wd=${wd}&read_preference=0&track_id=ec1280db127955061754851657967&sign=${sign}`;
            const res = await req(url, { headers: qmHeaders, timeout: 10000 });
            const detailData = JSON.parse(res.content || '{}');
            if (detailData.data && detailData.data.list) {
                for (const vod of detailData.data.list) {
                    let name = vod.title.replace(/<[^>]+>/g, ' ');
                    name = name.replace(/\s+/g, ' ').trim();
                    list.push({
                        vod_id: 'qm_' + vod.id,
                        vod_name: name,
                        vod_pic: vod.image_link,
                        vod_remarks: vod.total_num || '七猫'
                    });
                }
            }
        } catch (e) {}

        // 好看搜索
        try {
            const res = await req(`${HK_BASE_URL}/haokan/ui-interact/playlet/search/sugs`, {
                method: 'POST',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 8.0.0; zh-cn; Mi Note 2 Build/OPR1.170623.032) AppleWebKit/537.36 Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36',
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `search_word=${encodeURIComponent(wd)}`,
                timeout: 10000
            });
            const data = JSON.parse(res.content || '{}');
            if (data.data) {
                for (const vod of data.data) {
                    list.push({
                        vod_id: 'hk_' + vod.id,
                        vod_name: vod.title,
                        vod_pic: vod.cover_url,
                        vod_remarks: '好看'
                    });
                }
            }
        } catch (e) {}

        return {
            list: list,
            page: page,
            pagecount: 9999,
            limit: 90,
            total: 999999
        };
    },

    // ═══ 播放 ═══
    async play(ctx, flag, id, flags, vipFlags) {
        return {
            parse: 0,
            playUrl: '',
            url: id,
            header: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 12; Pixel 3 XL) AppleWebKit/537.36 Chrome/98.0.4758.101 Mobile Safari/537.36'
            },
            jx: 0,
            danmaku: ' '
        };
    }
};

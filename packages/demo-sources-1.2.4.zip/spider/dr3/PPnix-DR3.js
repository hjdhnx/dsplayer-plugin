/*
 * @header({
 *   title: 'PPnix[CN]',
 *   lang: 'dr3',
 *   host: 'https://www.ppnix.com',
 *   searchable: 1, filterable: 0, quickSearch: 1,
 *   version: '4.4.4-dr3',
 * })
 *
 * ================================================================
 * PPnix drpy3 (QuickJS) 单文件源 —— v4.4.4（字幕协议化：play 返回 subs）
 * ================================================================
 *
 * 第 4.1 版关键修正（对照真实页面 HTML 校验）：
 *   1) 卡片真实结构是 <a href="..." class="thumbnail">，href 在 class 之前
 *      —— 老版本正则顺序要求 href 在 class 后，永远匹配不到，导致 home/category 全空
 *      —— 新版改用"遍历所有 <a ... class=...thumbnail...>...>...</a>" 块，
 *         再单独抽 href/title/pic，顺序无关
 *   2) vod_id 从 href 里提取真实频道（movie/tv/...），避免首页多分类混成 movie
 *   3) 保留央视频契约（位置参数签名 + ctx.req + getProxyUrl + proxy [status,ct,body,hd,flag]）
 *
 * 第 4.4.1 版关键修正（对照真实页面 HTML 校验）：
 *   1) 分类（home）：站点导航仅存在 电影/电视剧，原 cartoon/documentary/short 会 301 跳首页
 *      —— 移除三个不存在的频道，home 只返回 movie/tv
 *   2) 分类翻页（category）：原用 'all' 占位 + 错误分页位，导致列表全空；
 *      站点格式为 class-area-year-page-sort，“全部”用空串、页码 0 基
 *      —— 第1页=----.html  第2页=---1-.html，并“本页不足一页即收口”
 *   3) 选集（detail）：原只读 m3u8 数组首元素，电视剧 47 集只出 1 集；
 *      现解析 m3u8=['1'..'47'] 全量展开为 第1集$url1#第2集$url2#...
 *   4) 英文字幕端点 /info/subtitle/.../en.srt 已失效（返回首页），移除无效探测与注入
 * 第 4.4.2 版修正：
 *   5) 搜索（search）：站点为宽泛模糊匹配（搜「庆余年」返回 24 条仅 2 条相关）
 *      —— 增加标题相关性过滤：归一化（去空白/标点、转小写）后标题须包含完整关键词
 * 第 4.4.3 版修正（对照真实分片实测解密）：
 *   6) 字幕（subtitle）：详情页 sub='|en|cn|tw|'（电影可能为 ''）声明可用语言；
 *      旧版探测 en.srt 因带 /cn/ 前缀误判失效。现按 sub 字段注入多语言 HLS 字幕轨
 *      （EXT-X-MEDIA SUBTITLES 包裹成 master），中文字幕经 base64 回传绕过代理 ASCII 铁律。
 *   7) 密钥（AES-128 根因）：KEY 端点返回 32 位 ASCII 十六进制串，实测 AES-128 密钥 =
 *      该串前 16 个 ASCII 字符（原始字节）、IV=0；旧版把 32 字符当密钥直连 → 解密失败/
 *      花屏/播不出。现经代理取出前 16 字符并以 base64(flag=1) 回传正确 16 字节密钥。
 *   8) 速度/拖动：分片仍走 io.zionlin.com（支持 Range 200/206）直连，代理仅处理 m3u8/
 *      密钥/字幕并设长缓存；站点网站端靠 P2P 加速，壳子无此能力，但链路已是最优直连。
 * 第 4.4.4 版修正（字幕协议化，对照 DsPlayer SUBTITLE-DESIGN §十二）：
 *   9) 字幕下发改走 T4 同构 subs 协议：play 返回 subs 数组（cn 首位，地址经代理
 *      _type=srt 转 VTT），壳的 PlayResolver 解析后经外挂管线自动挂载出字。
 *      原 HLS rendition 注入手法（EXT-X-MEDIA SUBTITLES 包 master）在 DsPlayer
 *      任何内核都出不了字（裸 VTT 非法 media playlist + Exo/IJK 不渲染流内字幕轨），
 *      删除 proxy 3c 注入段与 play 输出的 &sub= 参数；_type=key 密钥修正分支不动。
 *
 * 参考契约：/sdcard/Download/Operit/yangshipin-dr3.js
 *
 * drpy3 钩子签名（位置参数，勿改成单个 params 对象！）：
 *   init(ctx, ext)
 *   home(ctx, filter) -> { class, filters, type_flag }
 *   homeVod(ctx) -> { list }
 *   category(ctx, tid, pg, filter, extend) -> { list, page, pagecount, limit, total }
 *   detail(ctx, id) -> { list }
 *   play(ctx, flag, id, flags) -> { parse:0, urls:['2000Proxy', URL], header, subs? }
 *   search(ctx, wd, quick) -> { list }
 *   proxy(ctx, params) -> [status, contentType, body, headers?, flag?]
 *
 * 铁律：
 *   1) iPhone UA（桌面 UA 必 403）
 *   2) proxy 返回体全 ASCII（SRT 中文 -> null -> 拒绝）
 *   3) 分片二进制透传（Uint8Array -> base64，flag=1）
 *   4) master 列表预跟随 pickVariant
 *   5) ts/KEY/MAP URI 全改绝对代理 URL
 * ================================================================
 */

'use strict';

/* ---------- 常量 ---------- */

const HOST    = 'https://www.ppnix.com';
const ROOT    = HOST + '/';

const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1';
const H  = {
  'User-Agent':      UA,
  'Accept':          '*/*',
  'Accept-Language': 'en-US,en;q=0.9'
};

const T_HTTP   = 10000;
const T_API    = 6000;
const T_FRAG   = 30000;

/* 真实分类通道：站点导航仅存在 电影 / 电视剧，其余频道会 301 跳回首页（已移除） */
const CHANNELS = {
  movie: { path: 'movie', name: '电影',   playable: true },
  tv:    { path: 'tv',    name: '电视剧', playable: true }
};

/* ================================================================
 * Utils
 * ================================================================ */

function stripTags(s) {
  if (!s) return '';
  return String(s).replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
}

function decodeHtml(s) {
  if (!s) return '';
  return String(s)
    .replace(/&nbsp;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/\u0026quot;/gi, '\u0022')
    .replace(/&#x27;/gi, "'")
    .replace(/&#0?39;/gi, "'")
    .replace(/&amp;/gi, '&');
}

function ensureDecoded(s) {
  if (!s) return '';
  s = String(s);
  let cur = s;
  for (let i = 0; i < 4; i++) {
    let d;
    try { d = decodeURIComponent(cur); }
    catch (e) { d = cur; }
    if (d === cur) break;
    cur = d;
  }
  return cur;
}

function hasNonAscii(s) {
  return /[^\x00-\x7F]/.test(s);
}

function normalizePath(u) {
  if (!u) return u;
  // 分离 scheme://host:port 与 path
  const m = u.match(/^(https?:\/\/[^\/]+)(\/.*)?$/i);
  if (!m) return u; // 不是绝对 URL，原样返回
  const origin = m[1];
  const path = m[2] || '';
  const parts = path.split('/');
  const out = [];
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (p === '' || p === '.') continue;
    if (p === '..') { out.pop(); continue; }
    out.push(p);
  }
  return origin + '/' + out.join('/');
}

function absUri(uri, base) {
  uri = (uri || '').trim();
  if (!uri) return '';
  if (uri.charAt(0) === '#') return '';
  if (uri.indexOf('http://') === 0 || uri.indexOf('https://') === 0) {
    return normalizePath(uri);
  }
  if (uri.charAt(0) === '/') return normalizePath(HOST + uri);
  if (!base) return uri;
  const bi = base.lastIndexOf('/');
  if (bi < 0) return uri;
  return normalizePath(base.substring(0, bi + 1) + uri);
}

function isIpfsUrl(u) {
  if (!u) return false;
  return /\/\/ipfs\.ppnix\.com\/ipfs\//.test(u)
    || /\/\/gw\.ipfs/.test(u)
    || /\/\/\d+\.ppnix\.com\/ipfs\//.test(u)
    || /\/\/io\.zionlin\.com\/ipfs\//.test(u);
}

/* 已实测 io.zionlin.com 直连 200/206 支持 Range；gw.ipfs-lens.dev 已 502 */
function rewriteIpfsToDirect(u) {
  if (!u) return u;
  const m = u.match(/\/ipfs\/([A-Za-z0-9]+)[^/]*/);
  if (!m) return u;
  return 'https://io.zionlin.com/ipfs/' + m[1];
}

/* ---------- m3u8 ---------- */

function pickVariant(m3u8Text, baseUrl) {
  const re = /#EXT-X-STREAM-INF:([^\n]+)\n([^\n\r]+)/g;
  let m;
  let best = { bw: -1, url: '' };
  while ((m = re.exec(m3u8Text)) !== null) {
    const attrs = m[1];
    const rel   = m[2].trim();
    if (!rel) continue;
    let bw = 0;
    const bwm = attrs.match(/BANDWIDTH=(\d+)/i);
    if (bwm) bw = parseInt(bwm[1]);
    if (bw > best.bw) best = { bw: bw, url: absUri(rel, baseUrl) };
  }
  return best.url;
}

function isSegment(url) {
  if (!url) return false;
  if (isIpfsUrl(url)) return true; // IPFS 无后缀分片，也走二进制透传
  return /\.(ts|aac|m4s|mp2t|key|init)(\?|$)/i.test(url);
}

function segmentContentType(url) {
  if (/\.(aac|mp3|m4a)(\?|$)/i.test(url)) return 'audio/mp4';
  if (/\.(m4s)(\?|$)/i.test(url)) return 'video/mp4';
  if (/\.(ts|mp2t)(\?|$)/i.test(url)) return 'video/mp2t';
  if (/\.(mp4)(\?|$)/i.test(url)) return 'video/mp4';
  if (/\.(key)(\?|$)/i.test(url)) return 'application/octet-stream';
  return 'application/octet-stream';
}

/* ---------- 字幕 ---------- */

function srtToVtt(srtText) {
  if (!srtText) return null;
  const lines = srtText.replace(/\r\n?/g, '\n').split('\n');
  const out = ['WEBVTT'];
  let i = 0;
  while (i < lines.length) {
    const ln = lines[i].trim();
    if (!ln) { i++; continue; }
    if (/^\d+$/.test(ln)) {
      i++;
      const tl = (lines[i] || '').trim();
      if (!tl) { i++; continue; }
      const parts = tl.split('-->');
      if (parts.length < 2) { i++; continue; }
      const start = parts[0].trim().replace(',', '.').replace(/[^0-9:.\-]/g, '');
      let end = parts[1].trim().split(' ')[0].replace(',', '.').replace(/[^0-9:.\-]/g, '');
      if (start.indexOf(':') < 0) {
        const parts3 = start.split('.');
        let s = parseInt(parts3[0]);
        const ms = parseInt(parts3[1] || '0');
        start = String(Math.floor(s/3600)).padStart(2,'0')
              + ':' + String(Math.floor((s%3600)/60)).padStart(2,'0')
              + ':' + String(s%60).padStart(2,'0')
              + '.' + String(ms).padStart(3,'0');
      }
      if (end.indexOf(':') < 0) {
        const parts3 = end.split('.');
        let s = parseInt(parts3[0]);
        const ms = parseInt(parts3[1] || '0');
        end = String(Math.floor(s/3600)).padStart(2,'0')
            + ':' + String(Math.floor((s%3600)/60)).padStart(2,'0')
            + ':' + String(s%60).padStart(2,'0')
            + '.' + String(ms).padStart(3,'0');
      }
      i++;
      const cue = [];
      while (i < lines.length && lines[i].trim() !== '') { cue.push(lines[i].trim()); i++; }
      out.push(start + ' --> ' + end);
      out.push(cue.join('\n') || '');
      out.push('');
    } else {
      i++;
    }
  }
  return out.join('\n');
}

/* ================================================================
 * HTML 解析（顺序无关：href 与 class 位置互不依赖）
 * ================================================================ */

/* 从任一 <a ...>...</a> 或 <a ... /> 或自闭合块里，抽第一个 href 属性 */
function extractHref(aTag) {
  const m = aTag.match(/\bhref\s*=\s*"([^"]*)"/i);
  return m ? m[1] : '';
}

/* 从 <a ...>...</a> 里，抽第一个内部文本（跳过 <img>） */
function extractTitle(aTag) {
  const inner = aTag.replace(/^<a\b[^>]*>/i, '').replace(/<\/a>\s*$/i, '');
  const noImg = inner.replace(/<img\b[^>]*\/?>/i, ' ');
  return stripTags(decodeHtml(noImg));
}

function extractAlt(aTag) {
  const img = aTag.match(/<img\b[^>]*>/i);
  if (!img) return '';
  const m = img[0].match(/\balt\s*=\s*"([^"]*)"/i);
  return m ? decodeHtml(m[1]) : '';
}

function extractSrc(aTag) {
  const img = aTag.match(/<img\b[^>]*>/i);
  if (!img) return '';
  const m = img[0].match(/\bsrc\s*=\s*"([^"]*)"/i);
  return m ? m[1] : '';
}

/* 以 <li> 为单元：内部含 <a class=thumbnail>（封面）与 <h2><a>标题</a></h2>（片名） */
function parseThumbnailCards(body) {
  const list = [];
  if (!body) return list;
  /* 遍历所有 <li>（卡片单元）；非卡片的 <li>（排行/分页）会被 thumbnail 判定跳过 */
  const re = /<li\b[^>]*>([\s\S]*?)<\/li>/gi;
  let m;
  while ((m = re.exec(body)) !== null) {
    const block = m[0];
    /* 必须含 class="...thumbnail..." 的 <a>（封面），否则不是视频卡片 */
    const thumbA = block.match(/<a\b([^>]*?)\bclass\s*=\s*"[^"]*\bthumbnail\b[^"]*"[^>]*>([\s\S]*?)<\/a>/i);
    if (!thumbA) continue;
    const href = extractHref(thumbA[0]);
    const pic  = extractSrc(thumbA[0]);
    if (!href) continue;

    /* 标题：优先同 <li> 内 <h2><a>..</a></h2>（列表页/首页均在此），其次 img alt
       注意：封面 <a> 内可能含 <div class="countrie">年份</div>，不能当作标题 */
    let title = '';
    const h2 = block.match(/<h2>\s*<a\b[^>]*>([\s\S]*?)<\/a>/i);
    if (h2) title = stripTags(decodeHtml(h2[1]));
    if (!title) title = extractAlt(thumbA[0]);
    if (!title) continue;

    /* 从 href 里推断频道（movie/tv...），比填固定值准；不在真实频道表则回退 movie */
    let channel = '';
    const cm = href.match(/\/cn\/(movie|tv|cartoon|documentary|short|anime|comic|shorts?)\/\d+\.html/i);
    if (cm) channel = cm[1].toLowerCase();
    if (!channel || !CHANNELS[channel]) channel = 'movie';

    /* 备注：取 <li> 上除 thumbnail 外的 class */
    const liCls = block.match(/<li\b[^>]*\bclass\s*=\s*"([^"]*)"/i);
    const remarks = liCls ? liCls[1].split(/\s+/).filter(function (c) {
      return c && c !== 'thumbnail';
    }).join(' ') : '';

    list.push({
      type_id:     channel,
      type_name:   (CHANNELS[channel] && CHANNELS[channel].name) || channel,
      vod_id:      absUri(href, HOST),
      vod_name:    title,
      vod_pic:     absUri(pic,  HOST),
      vod_remarks: remarks,
      vod_class:   '',
      vod_area:    '',
      vod_year:    '',
      vod_play_from: '',
      vod_play_url:  ''
    });
  }
  return list;
}

/* ---------- 详情页 ---------- */

function parseDetailPage(body) {
  const vod = {
    vod_id: '', vod_name: '', vod_pic: '', vod_remarks: '',
    vod_class: '', vod_area: '', vod_year: '',
    vod_actor: '', vod_director: '', vod_content: '',
    _vid: '', _param: '', _subLangs: []
  };
  if (!body) return vod;

  const vid  = body.match(/data-vid\s*=\s*"([^"]+)"/i);
  const prm  = body.match(/data-param\s*=\s*"([^"]+)"/i);
  if (vid) vod._vid = vid[1];
  if (prm) vod._param = prm[1];

  const titleM = body.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  if (titleM) vod.vod_name = stripTags(decodeHtml(titleM[1])).replace(/[-_|\s]*PPnix.*$/i, '').trim();

  const dContent = body.match(/class\s*=\s*"[^"]*detail-content[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
  if (dContent) vod.vod_content = stripTags(decodeHtml(dContent[1]));
  if (!vod.vod_content) {
    const desc = body.match(/property\s*=\s*"og:description"[^>]*content\s*=\s*"([^"]*)"/i);
    if (desc) vod.vod_content = stripTags(decodeHtml(desc[1]));
  }

  const pic = body.match(/property\s*=\s*"og:image"[^>]*content\s*=\s*"([^"]*)"/i)
    || body.match(/class\s*=\s*"[^"]*detail-poster[^"]*"[^>]*src\s*=\s*"([^"]*)"/i)
    || body.match(/class\s*=\s*"poster"[^>]*src\s*=\s*"([^"]*)"/i);
  if (pic) vod.vod_pic = absUri(pic[1], HOST);

  const year = body.match(/(\b(19|20)\d{2}\b)/);
  if (year) vod.vod_year = year[1];

  const actor = body.match(/class\s*=\s*"[^"]*detail-actor[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
  if (actor) vod.vod_actor = stripTags(decodeHtml(actor[1])).replace(/^[\u6F14\u51FA\s:：]+/, '').trim();
  if (!vod.vod_actor) {
    const am = body.match(/class\s*=\s*"[^"]*actor[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
    if (am) vod.vod_actor = stripTags(decodeHtml(am[1])).replace(/^[\u6F14\u51FA\s:：]+/, '').trim();
  }

  const cls = body.match(/class\s*=\s*"[^"]*detail-class[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
  if (cls) vod.vod_class = stripTags(decodeHtml(cls[1])).replace(/^[\u7C7B\u522B\s:：]+/, '').trim();

  const area = body.match(/class\s*=\s*"[^"]*detail-area[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
  if (area) vod.vod_area = stripTags(decodeHtml(area[1])).replace(/^[\u5730\u533A\s:：]+/, '').trim();

  const subList = body.match(/class\s*=\s*"[^"]*detail-subtitle[^"]*"[^>]*>([\s\S]*?)<\/div>/i)
    || body.match(/class\s*=\s*"[^"]*sub-list[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
  if (subList) {
    const langs = subList[1].match(/data-lang\s*=\s*"([^"]+)"/g)
      || subList[1].match(/href\s*=\s*"\/info\/subtitle\/[^"]*\/([a-z]+)\.(srt|ass)"/gi)
      || [];
    vod._subLangs = langs.map(function (l) {
      const m = l.match(/([a-z]{2,3})/i);
      return m ? m[1].toLowerCase() : '';
    }).filter(Boolean);
  }

  return vod;
}

/* ---------- 详情脚本变量（infoid / m3u8 选集数组） ---------- */
function parseDetailVars(body) {
  const v = { infoid: '', m3u8: [], subLangs: [] };
  if (!body) return v;
  const io = body.match(/infoid\s*=\s*(\d+)/i);
  if (io) v.infoid = io[1];
  /* 例：m3u8=['1','2','3',...,'47']（电视剧 N 集）或 m3u8=['1080P']（电影 1 集） */
  const m = body.match(/m3u8\s*=\s*\[([^\]]*)\]/i);
  if (m) {
    const arr = m[1].match(/'([^']*)'/g) || [];
    v.m3u8 = arr.map(function (s) { return s.replace(/^'|'$/g, ''); });
  }
  /* 字幕语言：详情页内联 sub='|en|cn|tw|'（电影可能为 '' 空） */
  const sm = body.match(/sub\s*=\s*'([^']*)'/i) || body.match(/sub\s*=\s*"([^"]*)"/i);
  if (sm) {
    v.subLangs = sm[1].split('|').map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean);
  }
  return v;
}

/* ---------- 二进制编码 ---------- */

function bytesToBase64(buf) {
  if (!buf) return '';
  if (typeof buf === 'string') return buf;
  try {
    if (typeof globalThis.btoa === 'function') {
      let s = '';
      const b = (buf instanceof Uint8Array) ? buf : new Uint8Array(buf);
      const CH = 0x8000;
      for (let i = 0; i < b.length; i += CH) {
        const chunk = b.subarray(i, i + CH);
        let piece = '';
        for (let j = 0; j < chunk.length; j++) piece += String.fromCharCode(chunk[j]);
        s += piece;
      }
      return globalThis.btoa(s);
    }
  } catch (e) { /* fallthrough */ }
  const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const b = (buf instanceof Uint8Array) ? buf : new Uint8Array(buf);
  let out = '';
  let i = 0;
  while (i < b.length) {
    const b0 = b[i++];
    const b1 = (i < b.length) ? b[i++] : null;
    const b2 = (i < b.length) ? b[i++] : null;
    out += CHARS.charAt(b0 >> 2);
    if (b1 === null) {
      out += CHARS.charAt((b0 & 0x03) << 4) + '==';
    } else if (b2 === null) {
      out += CHARS.charAt(((b0 & 0x03) << 4) | (b1 >> 4)) + CHARS.charAt((b1 & 0x0F) << 2) + '=';
    } else {
      out += CHARS.charAt(((b0 & 0x03) << 4) | (b1 >> 4))
           + CHARS.charAt(((b1 & 0x0F) << 2) | (b2 >> 6))
           + CHARS.charAt(b2 & 0x3F);
    }
  }
  return out;
}

/* 字符串 → UTF-8 字节（中文 srt 转 vtt 后需 base64 回传，绕过代理 ASCII 铁律） */
function strToU8(s) {
  if (typeof TextEncoder === 'function') return new TextEncoder().encode(s);
  const b = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0xff;
  return b;
}

/* ================================================================
 * Hooks
 * ================================================================ */

const _m = {

  meta: {
    title:       'PPnix[CN]',
    host:        HOST,
    searchable:  1,
    filterable:  0,
    quickSearch: 1,
    version:     '4.4.4-dr3'
  },

  /* ---------- init ---------- */
  async init(ctx, ext) {
    this.js2Base = (await ctx.getProxyUrl()) + '&url=';
    if (ctx.log) ctx.log('[PPnix] init ok js2Base=' + this.js2Base.substring(0, 40) + '...');
  },

  /* ---------- home ---------- */
  async home(ctx, filter) {
    const classes = Object.keys(CHANNELS).map(function (k) {
      return { type_id: k, type_name: CHANNELS[k].name };
    });
    return { class: classes, filters: null, type_flag: '' };
  },

  /* ---------- homeVod ---------- */
  async homeVod(ctx) {
    let html = '';
    try {
      const res = await ctx.req(HOST + '/cn/', { headers: H, timeout: T_HTTP });
      html = res.content || '';
    } catch (e) {
      if (ctx.log) ctx.log('[homeVod] err=' + (e && e.message || e));
      return { list: [] };
    }
    return { list: parseThumbnailCards(html) };
  },

  /* ---------- category ---------- */
  async category(ctx, tid, pg, filter, extend) {
    /* 只接受真实存在的频道，其它一律回退 movie（站点导航仅 movie/tv） */
    const channel = CHANNELS[tid] ? tid : 'movie';
    const page    = parseInt(pg) || 1;

    /* 筛选字段：站点用“空串”表示全部，绝不能写 'all'（会 301/返回空） */
    const classId = (filter && filter.class) || '';
    const areaId  = (filter && filter.area)  || '';
    const yearId  = (filter && filter.year)  || '';
    const sortId  = (filter && filter.sort)  || '';

    /* 分页：第 N 页 → 第 4 个字段取 N-1（0 基）。格式 class-area-year-page-sort
       例：第1页=----.html  第2页=---1-.html  第3页=---2-.html */
    const pgField = page > 1 ? String(page - 1) : '';

    const path = '/cn/' + channel + '/'
      + classId + '-' + areaId + '-' + yearId + '-' + pgField + '-' + sortId + '.html';
    const url  = ROOT + path;

    let html = '';
    try {
      const res = await ctx.req(url, { headers: H, timeout: T_HTTP });
      html = res.content || '';
    } catch (e) {
      if (ctx.log) ctx.log('[category] err=' + (e && e.message || e) + ' url=' + url);
      return { list: [], page: page, pagecount: 1, limit: 24, total: 0 };
    }

    const cards = parseThumbnailCards(html);
    if (ctx.log) ctx.log('[category] tid=' + tid + ' pg=' + page + ' url=' + url + ' cards=' + cards.length);

    /* 本页不足一页即收口：满 24 条说明还有下一页，不足则到此为止 */
    const pagecount = cards.length >= 24 ? page + 1 : page;
    return {
      page:      page,
      pagecount: pagecount,
      limit:     24,
      total:     cards.length,
      list:      cards
    };
  },

  /* ---------- detail ---------- */
  async detail(ctx, id) {
    if (!id) return { list: [] };

    let url = ensureDecoded(id);
    if (url.indexOf('http') !== 0) url = absUri(url, ROOT);

    let html = '';
    try {
      const res = await ctx.req(url, { headers: H, timeout: T_HTTP });
      html = res.content || '';
    } catch (e) {
      if (ctx.log) ctx.log('[detail] err=' + (e && e.message || e));
      return { list: [] };
    }

    const d    = parseDetailPage(html);
    const vars = parseDetailVars(html);        // infoid / m3u8[]

    /* vid：优先脚本 infoid，否则从详情 URL 抽数字 */
    let vid = vars.infoid || '';
    if (!vid) {
      const vm = String(id).match(/\/(\d+)\.html/i);
      if (vm) vid = vm[1];
    }
    if (!vid) return { list: [] };

    /* 选集：m3u8 数组每个元素即一集（电影 1 集 / 电视剧 N 集），必须全量列出 */
    const m3u8List = (vars.m3u8 && vars.m3u8.length) ? vars.m3u8 : ['1'];
    const isMulti  = m3u8List.length > 1;
    if (ctx.log) ctx.log('[detail] vid=' + vid + ' episodes=' + m3u8List.length + ' isMulti=' + isMulti);

    /* 字幕语言（来自详情页 sub 字段）；同一 vid 下所有集通用，附加到每个选集 url 末尾 @langs */
    const langStr = (vars.subLangs && vars.subLangs.length) ? vars.subLangs.join(',') : '';
    const episodes = m3u8List.map(function (p) {
      const name = isMulti ? ('第' + p + '集') : (d.vod_name || '正片');
      const u    = ROOT + 'info/m3u8/' + vid + '/' + p + '.m3u8';
      return name + '$' + u + (langStr ? '@' + langStr : '');
    });
    const playUrl = episodes.join('#');

    return {
      list: [{
        type_id:      '',
        type_name:    '',
        vod_id:       url,
        vod_name:     d.vod_name || 'PPnix',
        vod_pic:      d.vod_pic,
        vod_remarks:  isMulti ? (m3u8List.length + ' 集') : '',
        vod_year:     d.vod_year,
        vod_area:     d.vod_area,
        vod_class:    d.vod_class,
        vod_actor:    d.vod_actor,
        vod_director: '',
        vod_content:  d.vod_content,
        vod_play_from: 'PPnix',
        vod_play_url:  playUrl
      }]
    };
  },

  /* ---------- play ---------- */
  async play(ctx, flag, id, flags) {
    const raw = ensureDecoded(id || '');
    if (!raw) return { parse: 0, urls: [] };
    /* 选集 token 形如  第N集$<m3u8url>[@langs]
       '$' 分隔 集名/地址，'#' 分隔集，'@' 之后为本源附加的字幕语言（cn,en,tw…） */
    let rest = raw;
    const dollar = raw.indexOf('$');
    if (dollar >= 0) rest = raw.substring(dollar + 1);
    let playUrl = rest, subLangs = '';
    const at = rest.lastIndexOf('@');
    if (at >= 0) {
      playUrl  = rest.substring(0, at);
      subLangs = rest.substring(at + 1);
    }
    if (ctx.log) ctx.log('[play] playUrl=' + playUrl + ' sub=' + (subLangs || '-'));

    /* v4.4.4 字幕协议化（SUBTITLE-DESIGN §12.2/§12.3）：不再经 HLS rendition
       注入（DsPlayer Exo/IJK 不渲染流内字幕轨，裸 VTT URI 也不是合法 media
       playlist），改返回 T4 同构 subs 数组——壳的 PlayResolver 解析后走外挂
       管线自动挂载（subs.first 为默认语言，cn 优先）。srt 经代理 _type=srt
       分支转 VTT（base64 flag=1 绕 ASCII 铁律），壳的 SubtitleLoader 直下。 */
    let subs = [];
    if (subLangs) {
      const langsAll = subLangs.split(',').map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean);
      /* cn/zh 稳定置前（数组顺序即优先级） */
      const isCn = function (lg) { return lg === 'cn' || lg === 'zh' || lg === 'zh-cn'; };
      const langs = langsAll.filter(isCn).concat(langsAll.filter(function (lg) { return !isCn(lg); }));
      const muM = playUrl.match(/\/info\/m3u8\/(\d+)\/([^/]+?)\.m3u8/i);
      if (muM && langs.length) {
        const langNames = { cn: 'Chinese', zh: 'Chinese', en: 'English', tw: 'Chinese(Traditional)', 'zh-cn': 'Chinese' };
        /* init 未跑时兜底取代理基址（与 proxy 钩子 3b 同款），防 subs 地址拼成 undefined… */
        const js2Base = this.js2Base || ((await ctx.getProxyUrl()) + '&url=');
        subs = langs.map(function (lg) {
          const srtUrl = HOST + '/info/subtitle/' + muM[1] + '/' + muM[2] + '/' + lg + '.srt';
          return {
            name: langNames[lg] || lg,
            url:  js2Base + encodeURIComponent(srtUrl) + '&_type=srt',
            lang: lg
          };
        });
      }
    }

    const out = this.js2Base + encodeURIComponent(playUrl) + '&_type=m3u8';
    return {
      parse: 0,
      urls:  ['2000Proxy', out],
      header: { 'User-Agent': UA, 'Referer': ROOT },
      subs:  subs
    };
  },

  /* ---------- search ---------- */
  async search(ctx, wd, quick) {
    wd = ensureDecoded((wd == null ? '' : String(wd))).trim();
    if (!wd) return { list: [] };

    /* PPnix 搜索：/cn/search/{keyword}--.html（末尾双连字符），
       关键词中的 '-' 替换为空格 */
    const kw = wd.replace(/-/g, '%20');
    const url = HOST + '/cn/search/' + encodeURIComponent(kw).replace(/%20/g, '%20') + '--.html';

    let html = '';
    try {
      const res = await ctx.req(url, { headers: H, timeout: T_HTTP });
      html = res.content || '';
    } catch (e) {
      if (ctx.log) ctx.log('[search] err=' + (e && e.message || e) + ' wd=' + wd);
      return { list: [] };
    }
    if (ctx.log) ctx.log('[search] wd=' + wd + ' raw=' + parseThumbnailCards(html).length);
    /* 站点搜索是宽泛模糊匹配（如搜「庆余年」会混入大量无关片），
       这里按标题相关性过滤：标题（归一化后）须包含完整关键词。
       归一化：去空白/标点、转小写，兼容「庆余年 第一季」这类带空格标题。 */
    const norm = function (s) {
      return String(s || '').toLowerCase()
        .replace(/[\s.,!?:;"'`(){}\[\]<>~@#\$%\^&\*\+=\|\\\/\-_—–·、，。！？：；「」『』（）【】《》〈〉…]+/g, '');
    };
    const kwNorm = norm(wd);
    const all = parseThumbnailCards(html);
    const list = kwNorm ? all.filter(function (it) {
      return norm(it.vod_name).indexOf(kwNorm) >= 0;
    }) : all;
    if (ctx.log) ctx.log('[search] wd=' + wd + ' kept=' + list.length + '/' + all.length);
    return { list: list };
  },

  /* ---------- proxy ---------- */
  async proxy(ctx, params) {
    let src = (params && params.url || '').trim();
    src = ensureDecoded(src);
    if (!src) return [400, 'text/plain', 'missing url param', {}, 0];

    try {
      /* 1) 密钥：端点返回 32 位 ASCII 十六进制串；实测 AES-128 密钥 = 该串前 16 个 ASCII 字符（原始字节），
             IV=0。直连 32 字符会被播放器误当密钥→解密失败/花屏。这里取前 16 字符，base64(flag=1) 回传。 */
      if (/\/info\/m3u8\/key(\?|$)/i.test(src) || (params && params._type === 'key')) {
        const res = await ctx.req(src, { headers: H, timeout: T_API });
        const txt = (res.content || '').trim();
        let kb = null;
        if (/^[0-9a-fA-F]{32}$/.test(txt)) {
          kb = strToU8(txt.substring(0, 16));
        } else if (txt.length >= 16) {
          kb = strToU8(txt.substring(0, 16));
        } else if (res.content) {
          kb = (typeof res.content === 'string') ? strToU8(res.content) : res.content;
        }
        if (!kb) return [502, 'text/plain', 'key fetch failed', {}, 0];
        return [200, 'application/octet-stream', bytesToBase64(kb),
                { 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'public, max-age=86400' }, 1];
      }

      /* 2) 字幕源：srt → vtt，base64（flag=1）回传以绕过代理返回体全 ASCII 铁律，从而支持中文 */
      if (/\.(srt)(\?|$)/i.test(src) || (params && params._type === 'srt')) {
        const res = await ctx.req(src, { headers: H, timeout: T_API });
        const srtText = res.content || '';
        if (!srtText) return [502, 'text/plain', 'subtitle fetch failed', {}, 0];
        const vtt = srtToVtt(srtText);
        if (!vtt) return [502, 'text/plain', 'subtitle parse failed', {}, 0];
        return [200, 'text/vtt', bytesToBase64(strToU8(vtt)),
                { 'Cache-Control': 'public, max-age=3600000',
                  'Access-Control-Allow-Origin': '*' }, 1];
      }

      /* 2) 分片二进制透传 */
      if (isSegment(src)) {
        const res = await ctx.req(src, {
          method: 'GET', buffer: 1, timeout: T_FRAG,
          headers: { 'User-Agent': UA, 'Referer': ROOT }
        });
        const buf = res.content;
        if (!buf) return [502, 'text/plain', 'segment fetch failed', {}, 0];
        return [200, segmentContentType(src), bytesToBase64(buf),
                { 'Access-Control-Allow-Origin': '*',
                  'Cache-Control': 'public, max-age=604800' }, 1];
      }

      /* 3) m3u8 主/变体 */
      if (/\.(m3u8)(\?|$)/i.test(src)) {
        const res = await ctx.req(src, { headers: H, timeout: T_API });
        let m3u8 = res.content || '';
        if (!m3u8) return [502, 'application/x-mpegurl', 'upstream m3u8 failed', {}, 0];

        /* 3a) master 预跟随 */
        let baseUrl = src;
        let hops = 0;
        while (m3u8.indexOf('#EXT-X-STREAM-INF') >= 0 && hops < 3) {
          const absBase = absUri(baseUrl, '');
          const variantUrl = pickVariant(m3u8, absBase);
          if (!variantUrl) break;
          const vResp = await ctx.req(variantUrl, { headers: H, timeout: T_API });
          const vText = vResp.content || '';
          if (!vText) break;
          m3u8 = vText;
          baseUrl = variantUrl;
          hops++;
        }

        /* 3b) KEY URI 直连跳过代理（ctx.req 会 UTF-8 化二进制，KEY 32B 会变 24B，AES 必挂） */
        const absBase = absUri(baseUrl, '');
        const js2Base = this.js2Base || ((await ctx.getProxyUrl()) + '&url=');
        const outLines = m3u8.split('\n').map(function (line) {
          if (!line.trim()) return line;
          if (line.charAt(0) === '#') {
            return line.replace(/URI="([^"]+)"/g, function (_, u) {
              const abs = absUri(u, absBase);
              if (isIpfsUrl(abs)) return 'URI="' + rewriteIpfsToDirect(abs) + '"';
              /* KEY：改走代理并 hex/截断处理（见分支 1），否则 32 字符密钥无法被 AES-128 使用 */
              if (/\/info\/m3u8\/key(\?|$)/i.test(abs)) {
                return 'URI="' + js2Base + encodeURIComponent(abs) + '&_type=key"';
              }
              return 'URI="' + abs + '"';
            });
          }
          const absLine = absUri(line.trim(), absBase);
          if (isIpfsUrl(absLine)) return rewriteIpfsToDirect(absLine);
          return js2Base + encodeURIComponent(absLine) + '&_type=m3u8';
        });
        let out = outLines.join('\n');

        /* v4.4.4：原 3c 字幕轨注入段（master 包裹 + EXT-X-MEDIA SUBTITLES）已删除——
           裸 VTT 非法 media playlist + DsPlayer Exo/IJK 不渲染流内字幕轨，
           字幕下发改走 play 的 subs 协议（见 play 钩子）。_type=key 密钥修正分支保留。 */

        if (hasNonAscii(out)) {
          return [500, 'text/plain', 'non-ascii in output', {}, 0];
        }
        return [200, 'application/vnd.apple.mpegurl', out,
                { 'Access-Control-Allow-Origin': '*',
                  'Cache-Control': 'no-cache' }, 0];
      }

      /* 4) 其它（透传） */
      const other = await ctx.req(src, { headers: H, timeout: T_HTTP });
      if (!other.content) return [502, 'text/plain', 'upstream failed', {}, 0];
      return [200, 'application/octet-stream', other.content, {}, 0];

    } catch (e) {
      if (ctx.log) ctx.log('[proxy] fatal err=' + (e && e.message || e));
      return [500, 'text/plain', 'proxy error', {}, 0];
    }
  }
};

export default _m;

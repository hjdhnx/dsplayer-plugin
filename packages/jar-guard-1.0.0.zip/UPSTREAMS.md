# UPSTREAMS — jar-guard 包内第三方件归属与许可

本包（jar-guard）内含来自下列上游的第三方制品。本包与 DsPlayer 主程序构成聚合分发；
主程序源码不包含这些内容。改动或再分发本包时须保留本文件与 `licenses/` 目录。

| 件 | 来源 | 许可 |
|---|---|---|
| `unidbg-android-0.9.9.jar` `unidbg-api-0.9.9.jar` `unidbg-unicorn2-0.9.9.jar` `unidbg-dynarmic-0.9.9.jar` | [unidbg](https://github.com/zhkl0228/unidbg) 0.9.9（Maven Central，`com.github.zhkl0228`） | Apache-2.0 |
| `unicorn-1.0.15.jar` `capstone-3.1.8.jar` `keystone-0.9.7.jar` `demumble-1.0.4.jar` | 同上（zhkl0228 发布的引擎组件） | Apache-2.0 / BSD（各上游引擎） |
| `commons-codec-1.21.0.jar` `commons-collections4-4.5.0.jar` `commons-io-2.21.0.jar` | Apache Commons | Apache-2.0 |
| `fastjson-1.2.83.jar` | Alibaba（Maven Central） | Apache-2.0 |
| `apk-parser-2.6.10.jar` | dongliu（Maven Central） | Apache-2.0 |
| `jna-5.10.0.jar` | JNA（Maven Central） | 双许可 Apache-2.0 / LGPL-2.1 |
| `native-lib-loader-2.3.5.jar` | SciJava（Maven Central） | BSD 简化许可 |
| `slf4j-api-2.0.16.jar` `slf4j-simple-2.0.16.jar` | SLF4J（Maven Central） | MIT |
| `asm-9.7.jar` | OW2 ASM | BSD-3-Clause |
| `assets/AwInit.class` | DsPlayer 自研互操作垫片（`src/AwInit.java`，构建期 javac 编译） | 本仓同许可 |

钉版说明：unidbg 0.9.9 依赖树经 MisaTV（GPL-3.0，@ `f91cc41`）的
`arm_bridge_runtime.dart` 清单核对（18 件精确版本），构建脚本只从 Maven
镜像取件拼装，不改内容。

包内**不含**任何壳的真实实现/解包产物（shell-real）——加固壳一律按
unidbg 首次解包路径运行。

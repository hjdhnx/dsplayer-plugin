Edge 朗读 TTS 服务（ms-ra-forwarder 核心单文件版）
=====================================================

端口：38080（写死；直跑可用 PORT env 覆盖，服务包形态无 env 通道）
鉴权：默认关闭；需启用时在服务配置 env 加 MS_RA_FORWARDER_TOKEN=<值>，
      请求头带 Authorization: Bearer <值>

端点：
  GET /                          health JSON（服务页探活也用它）
  GET /api/voices                318 个微软音色列表
  GET /api/text-to-speech?voice=zh-CN-XiaoxiaoNeural&text=你好
                                 &rate=0&volume=100&pitch=0（±100 偏移）
  GET /api/ra?voiceName=…&text=… 旧版 ms-ra-forwarder 兼容（容忍 +10% 形态）

DsPlayer 接入：阅读 → 设置 → 朗读引擎切「网络」→ 导入音色包：
  [{"name":"晓晓(本地TTS)","contentType":"audio/mpeg",
    "url":"http://127.0.0.1:38080/api/text-to-speech?voice=zh-CN-XiaoxiaoNeural&rate={{speakSpeedPct}}&volume=100&pitch=0&text={{speakText}}"}]

换音色：把 voice= 换成 /api/voices 里任意 ShortName（如 YunyangNeural）。
仅供学习参考，请勿商用。
